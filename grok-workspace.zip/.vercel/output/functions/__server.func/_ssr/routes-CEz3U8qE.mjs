import { o as __toESM, r as __exportAll } from "../_runtime.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, o as require_react, r as QueryClientProvider, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { v as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as createServerFn } from "./ssr.mjs";
import { i as signOut, t as authClient } from "./client-B40BzJxt.mjs";
import { a as hasGateSessionMarker } from "./server-CZEeSYPY.mjs";
import { t as cn } from "./utils-CJQCePbV.mjs";
import { a as dict, n as VeltoMark, o as isRtl, r as VeltoWordmark, t as LANGS } from "./i18n-CBDR4ZJe.mjs";
import { C as ChevronLeft, D as Bell, E as Bookmark, S as Download, T as CheckCheck, _ as Lock, a as Star, b as Gem, c as Shield, d as Search, f as Plus, g as MessageCircle, h as Mic, l as Settings, m as Paperclip, n as Video, o as Sparkles, p as Phone, r as Users, s as Smile, t as Wallet, u as Send, v as Globe, w as Check, x as EllipsisVertical, y as Gift } from "../_libs/lucide-react.mjs";
import { n as createSsrRpc } from "./router-Bv-7WNrK.mjs";
import { t as authMiddleware } from "./middleware-CKN9QaD2.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CEz3U8qE.js
var routes_CEz3U8qE_exports = /* @__PURE__ */ __exportAll({
	A: () => reactMessage,
	C: () => listStoriesFeed,
	D: () => ownerStats,
	E: () => ownerModerate,
	F: () => updateProfile,
	I: () => viewStory,
	M: () => sendStars,
	N: () => setTyping,
	O: () => pinChat,
	P: () => startCall,
	S: () => listNotifications,
	T: () => ownerCommand,
	_: () => listCatalog,
	a: () => buyPremium,
	b: () => listMessages,
	c: () => createDm,
	component: () => Home,
	d: () => deleteMessage,
	f: () => editMessage,
	g: () => heartbeat,
	h: () => globalSearch,
	i: () => buyGift,
	j: () => sendMessage,
	k: () => pinMessage,
	l: () => createGroup,
	m: () => getWallet,
	n: () => blockUser,
	o: () => claimDaily,
	p: () => getPublicProfile,
	r: () => bootstrapSession,
	s: () => convertGiftNft,
	t: () => addContact,
	u: () => createStory,
	v: () => listChats,
	w: () => markNotificationsRead,
	x: () => listMyInventory,
	y: () => listContacts
});
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var bootstrapSession = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("776dfa5c7387785fa70f6138ff58f12e1c740dbed2bf630a9d0424b54a077ee2"));
var heartbeat = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("f31dcdd355b699aa12d270df5a65dd32bf1599f2d1ed5f581ee19b13a50c50ed"));
var updateProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("c27e58038eae7b6192a606724aadcf0b606d78636816bd022ce95b40356b56cb"));
var getPublicProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("b29933b08bc9b62bbd35e1db12bfbbf33a286df9b2af0d8c829cac5d61a16d74"));
var listChats = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("ca634e8dc4b0b23f2716f10efd6e4e057c80809e65e2278f0221d3550fe551fb"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("e73f73617fc03127ea42d07d9fe4f60abc810ab2ccce0e37b02e201a2767d25a"));
var listMessages = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("d581c073bb25d3af3c50a8a16651a948c58d0422ed467234e214335a5dae369a"));
var sendMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("09403bee605f58b7c0670bcd4cf21fa3d8acaadb0289f80322c4b9ef11a8e1a5"));
var editMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("52da37d9556e77bf94b0984d39e4d244d68d8ae34c1e08ffdd400ca754591745"));
var deleteMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("e163921ac0e1a1c43b449a17541e71046a6fbba6bc31183cb19f631d4c33c5cd"));
var reactMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("10a35fa3df8e9c69c4d0fad0ec6082683040ac953132199f801dc24e374ac0c0"));
var pinMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("b068800439788125096d9ede2806b10e48ff6f15a3a228344ce420fcb4a2c27b"));
var setTyping = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("e8d7339c846af0d1c12b86497daced3a831bf18ef9b0863ba7378116120afb5f"));
var createDm = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("a29d75febdf6d472d77d809a4dafa1d4567a9c8b8fb9a713deec8cd5c3592c3c"));
var createGroup = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("49489a7869597041179918643538a0f4bde8f985acfc3478cf90451231067bb3"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("d6b9a26dcc727fbecef678a264f89c90c2305c68903ae39b0457affec888c3c7"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("b1c195fa86eb69323503a925377af134ec126f5ca7f4d34ea0af478b40269409"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("56d6f1341883c96556a34e04bc959da6bc79c1401da0ffb3aa0bfe581149d704"));
var pinChat = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("ddde220917780ae2645652449dd449a7e0ff648b2c1abc27c9214df023125cbe"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("dbca90505ee01ac70caa4004d449b82f8b0e1d1fc70c547cac497689573c4f6f"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("94a2c49e852beb03f8e4b42c7849d54ed070c9ac06f82d809fe35b9cd4f639d8"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("c121524adf391bca3660cdf8a232ea10b5dc0cd6192edbc9fc4b7633bf0c7b1b"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("b939d4d09b3f01997722c2d6fa2c1ff2b7c9eab96f962c8462bc02697322a722"));
var globalSearch = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("3c0495a616c93a2415c95cf1966f61b9b0b2f2352d9901c4658eeb2b1640dee4"));
var listContacts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("c1549bcd768bd92f92a2bc0ae436226a35e4275c9a1fa7f8612db1301fe98cc7"));
var addContact = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("b378161b555f137bd33653c0dd3f0919c22d956afc95fa27c62744fb86666bf5"));
var blockUser = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("7e744e614b87f3a206d7bb4f36cfdb60282e1daa52898ad5e1235ee056b46c35"));
var listStoriesFeed = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("bf0533bda0585df46fbacac66d8949dfd4056314e4bfa66635dbd2db45fbd7a6"));
var createStory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("3fedb0e49b7f1fa89d20cfa8b03f4eb064f1b11a53ead3a4bd45bbe4c0beb417"));
var viewStory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("f5eaf15faa91056dfb3ad7485a54b7d6a7a713f619c514f967e92991389a31d0"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("f4dcc6daa19739972ae45c9eedcadda07cf6f6abda95367d98aea359e74993e9"));
var getWallet = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("52e0a1f00885539e886b67ca22d1edc7fae383f61ec15765cc0a6b101075c9b3"));
var sendStars = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("c0e47347a234aa8a7d9c9530afff3849dcaac4af5a8319b981f74a7bb060482c"));
var claimDaily = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("5e9cdc01f0c6ee26d712c144aafdbd66641fb330bc5e060cc73d7552838e6412"));
var listCatalog = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("ea19e80b6a57d6681b9b8fa739955f37c35501d715f36c4113a14374ce819d4a"));
var buyGift = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("d56dbc54ddb5d6e72b8ee69b4c584b9b653876c377ce87ce09469072f4308ff8"));
var convertGiftNft = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("f9475011c0477e3be8e7735fb4fcb09e7682c9c0321d218e80be6af1978714b1"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("e20e54405190d407f9dc28a40348ecf00da59db904bd10bdc2c9afaedfdf1087"));
var buyPremium = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("674a1c6fed968d5cedcc21e0e75331ae8ab32064989b6185c56884ca5faf7ff2"));
var listNotifications = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("8b6e6d618fc1143b96fe3f3df5c5e0f85169035b20391fe7d106a4cf58a70106"));
var markNotificationsRead = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("ab59f02c5f614ea0e63ac87365d79d4d91fbf6d969a6d085175d1c48377d85ee"));
var startCall = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("35a8224a861b98cf5e42344af0e55b2631ab87ebd7bfcebc6a53241b95be49e6"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("66d416df6e32f507f9c09a74496c2ff938cce98377b3972be25e947f6243561b"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("c0534d80483160bb2782feb3502f7e4e102ee853bf4dc6f815551b6908759f01"));
var listMyInventory = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("531c57d16804291ae04072f65f84ea0245f8f97ccd379ca6b36279994d1121c3"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("e327f046ef0e78431a2d8730de1aeab8f9eb3914275f2762bcb631c29a878e05"));
var ownerStats = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("787ff7f7c72616000994a849da5b941927af238b5c48ebe87e47d25e640d6ec3"));
var ownerCommand = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("e318f5bbe8938e2aa4de5f9102d7c9af4a227f7637f426d03d6f3a157b372d68"));
var ownerModerate = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("2e487fc2979c39f92c05302b214431d296ce835085d672e30362f0b946606d97"));
createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("5b3d8f9be519ad33ed8951faf4805388863ec9e46f287fb6243fb8ab3c993c70"));
var rarityTone = {
	common: "from-zinc-400/30 to-zinc-600/10",
	rare: "from-teal-300/40 to-cyan-700/20",
	epic: "from-sky-300/40 to-indigo-800/20",
	legendary: "from-amber-200/50 to-orange-800/20",
	mythic: "from-rose-300/45 to-red-900/25"
};
function GiftArt({ imageKey, rarity, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative aspect-square overflow-hidden rounded-[22px] bg-linear-to-br", rarityTone[rarity], className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 opacity-40",
			style: { background: "radial-gradient(circle at 30% 20%, white, transparent 45%)" }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 80 80",
			className: "relative size-full p-3",
			children: [
				imageKey === "spark" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M40 8 L46 32 L70 40 L46 48 L40 72 L34 48 L10 40 L34 32 Z",
					fill: "#e8c36a"
				}),
				imageKey === "orb" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "40",
					cy: "40",
					r: "22",
					fill: "none",
					stroke: "#7ee7d4",
					strokeWidth: "3"
				}),
				imageKey === "comet" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M12 62 L48 26",
					stroke: "#7ee7d4",
					strokeWidth: "3",
					strokeLinecap: "round"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "54",
					cy: "20",
					r: "8",
					fill: "#2dd4bf"
				})] }),
				imageKey === "lynx" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M22 58 L28 28 L40 36 L52 28 L58 58 Z",
					fill: "none",
					stroke: "#9bb0ac",
					strokeWidth: "3"
				}),
				imageKey === "aurora" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M10 50 C25 20, 55 20, 70 50",
					fill: "none",
					stroke: "#5ee1b0",
					strokeWidth: "4"
				}),
				imageKey === "cube" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M40 14 L66 28 L40 42 L14 28 Z M14 28 L14 52 L40 66 L40 42 M66 28 L66 52 L40 66",
					fill: "none",
					stroke: "#7dd3fc",
					strokeWidth: "2.5"
				}),
				imageKey === "phoenix" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M40 66 C20 40, 24 18, 40 28 C56 18, 60 40, 40 66",
					fill: "#fb7185",
					opacity: "0.9"
				}),
				imageKey === "crown" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M16 50 L20 24 L32 40 L40 18 L48 40 L60 24 L64 50 Z",
					fill: "#e8c36a"
				}),
				imageKey === "origin" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "40",
					cy: "40",
					r: "18",
					fill: "none",
					stroke: "#e8c36a",
					strokeWidth: "2"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "40",
					cy: "40",
					r: "6",
					fill: "#2dd4bf"
				})] }),
				imageKey === "eclipse" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "40",
					cy: "40",
					r: "20",
					fill: "#2dd4bf"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "48",
					cy: "36",
					r: "16",
					fill: "#0b0d12"
				})] }),
				![
					"spark",
					"orb",
					"comet",
					"lynx",
					"aurora",
					"cube",
					"phoenix",
					"crown",
					"origin",
					"eclipse"
				].includes(imageKey) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "40",
					cy: "40",
					r: "16",
					fill: "#2dd4bf"
				})
			]
		})]
	});
}
function NftArt({ imageKey, rarity, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("relative overflow-hidden rounded-[24px] bg-linear-to-br p-4", rarityTone[rarity], className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 100 100",
			className: "size-full",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "8",
					y: "8",
					width: "84",
					height: "84",
					rx: "18",
					fill: "none",
					stroke: "currentColor",
					strokeOpacity: "0.35"
				}),
				imageKey === "pulse-v" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M30 28 L50 78 L70 28",
					fill: "none",
					stroke: "#2dd4bf",
					strokeWidth: "6",
					strokeLinecap: "round"
				}),
				imageKey === "relay" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "50",
					r: "22",
					fill: "none",
					stroke: "#7ee7d4",
					strokeWidth: "4"
				}),
				imageKey === "seed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "50",
					r: "10",
					fill: "#e8c36a"
				}),
				imageKey === "lens" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "50",
					cy: "50",
					rx: "28",
					ry: "16",
					fill: "none",
					stroke: "#7dd3fc",
					strokeWidth: "4"
				}),
				imageKey === "tide" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M16 60 C36 40, 64 80, 84 50",
					fill: "none",
					stroke: "#2dd4bf",
					strokeWidth: "5"
				}),
				imageKey === "vein" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M20 80 L50 20 L80 80",
					fill: "none",
					stroke: "#e8c36a",
					strokeWidth: "4"
				}),
				imageKey === "nlynx" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M30 70 L38 34 L50 46 L62 34 L70 70 Z",
					fill: "none",
					stroke: "#fb7185",
					strokeWidth: "4"
				}),
				imageKey === "moth" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M50 78 L50 30 M50 44 C20 20, 20 70, 50 58 C80 70, 80 20, 50 44",
					fill: "none",
					stroke: "#e8c36a",
					strokeWidth: "3"
				})
			]
		})
	});
}
function StickerArt({ imageKey }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className: "size-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "28",
				fill: "color-mix(in oklab, var(--vg-accent) 18%, transparent)"
			}),
			imageKey.includes("hello") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M20 38 Q32 48 44 38",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "3"
			}),
			imageKey.includes("ok") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M22 34 L30 42 L44 24",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "3"
			}),
			imageKey.includes("love") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M32 44 C18 34 20 22 32 28 C44 22 46 34 32 44",
				fill: "var(--vg-accent)"
			}),
			imageKey.includes("wow") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "38",
				r: "6",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "3"
			}),
			imageKey.includes("sad") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M22 42 Q32 32 42 42",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "3"
			}),
			imageKey.includes("cool") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 30 H28 M36 30 H46",
				stroke: "currentColor",
				strokeWidth: "3"
			}),
			imageKey.includes("fire") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M32 48 C22 36 28 22 32 18 C36 22 42 36 32 48",
				fill: "#fb7185"
			}),
			imageKey.includes("night") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "34",
				cy: "28",
				r: "10",
				fill: "#e8c36a"
			}),
			imageKey.includes("ion") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M22 20 L32 48 L42 20",
				fill: "none",
				stroke: "#2dd4bf",
				strokeWidth: "3"
			}),
			imageKey.includes("crown") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 40 L20 22 L32 34 L44 22 L48 40 Z",
				fill: "#e8c36a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "22",
				cy: "26",
				r: "3",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "42",
				cy: "26",
				r: "3",
				fill: "currentColor"
			})
		]
	});
}
function Avatar({ name, url, color, frame, size = 44, online }) {
	const letter = (name || "?").charAt(0).toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative shrink-0",
		style: {
			width: size,
			height: size
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("grid size-full place-items-center overflow-hidden rounded-full font-display font-semibold", frame === "orbit" && "ring-2 ring-accent ring-offset-2 ring-offset-bg", frame === "crown" && "ring-2 ring-star ring-offset-2 ring-offset-bg"),
			style: {
				background: url ? void 0 : color || "#2DD4BF",
				color: "#04221c",
				fontSize: size * .38
			},
			children: url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: url,
				alt: "",
				className: "size-full object-cover"
			}) : letter
		}), online && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-0 bottom-0 size-2.5 rounded-full bg-success ring-2 ring-bg" })]
	});
}
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
async function fileToDataUrl(file, maxEdge = 960) {
	if (file.type.startsWith("image/") && !file.type.includes("gif")) {
		const bitmap = await createImageBitmap(file);
		const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
		const canvas = document.createElement("canvas");
		canvas.width = Math.max(1, Math.round(bitmap.width * scale));
		canvas.height = Math.max(1, Math.round(bitmap.height * scale));
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Canvas");
		ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
		return canvas.toDataURL("image/jpeg", .82);
	}
	return await new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result));
		reader.onerror = () => reject(/* @__PURE__ */ new Error("Read failed"));
		reader.readAsDataURL(file);
	});
}
function formatTime(isoStr, lang) {
	if (!isoStr) return "";
	const d = new Date(isoStr);
	if (Number.isNaN(d.getTime())) return "";
	const diff = Date.now() - d.getTime();
	if (diff < 45e3) return lang === "ru" ? "сейчас" : "now";
	if (diff < 36e5) return `${Math.max(1, Math.round(diff / 6e4))}m`;
	if (diff < 864e5) return d.toLocaleTimeString(lang, {
		hour: "2-digit",
		minute: "2-digit"
	});
	return d.toLocaleDateString(lang, {
		month: "short",
		day: "numeric"
	});
}
function lastSeenLabel(isoStr, online, lang, onlineWord, lastWord) {
	if (online) return onlineWord;
	return `${lastWord} ${formatTime(isoStr, lang)}`;
}
var useNav = create((set, get) => ({
	screen: "chats",
	storyIndex: 0,
	call: null,
	go: (patch) => set({
		...get(),
		...patch
	}),
	back: () => {
		const s = get().screen;
		if (s === "chat" || s === "user" || s === "create" || s === "search") set({
			screen: "chats",
			chatId: void 0
		});
		else if (s === "owner" || s === "install" || s === "info" || s === "notifications" || s === "settings") set({ screen: "profile" });
		else if (s === "shop" || s === "nft") set({ screen: "stars" });
		else set({ screen: "chats" });
	}
}));
function newKey() {
	return crypto.randomUUID();
}
function IconBtn({ children, onClick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: "glass-btn grid size-11 place-items-center rounded-full text-fg",
		children
	});
}
function ScreenHeader({ title, onBack }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "glass sticky top-0 z-20 flex items-center gap-3 px-3 py-3",
		children: [onBack && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onBack,
			className: "grid size-11 place-items-center rounded-full",
			"aria-label": "Back",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-lg font-semibold tracking-tight",
			children: title
		})]
	});
}
function SearchScreen({ lang }) {
	const d = dict(lang);
	const nav = useNav();
	const [q, setQ] = (0, import_react.useState)("");
	const { data } = useQuery({
		queryKey: ["search", q],
		queryFn: () => globalSearch({ data: { q } }),
		enabled: q.trim().length > 0
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
				title: d.search,
				onBack: () => nav.back()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass flex h-12 items-center gap-2 rounded-full px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						autoFocus: true,
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: d.search,
						className: "h-full flex-1 bg-transparent outline-none"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 overflow-y-auto px-3 pb-24",
				children: [!data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-2 py-6 text-sm text-muted",
					children: d.noResults
				}), data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-5",
					children: [
						data.users.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-2 px-1 text-xs font-medium tracking-wide text-subtle uppercase",
							children: d.users
						}), data.users.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full items-center gap-3 rounded-[18px] px-2 py-2 hover:bg-fg/5",
							onClick: () => nav.go({
								screen: "user",
								userId: u.userId
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
								name: u.firstName || u.username,
								url: u.avatarUrl,
								color: u.profileColor,
								online: u.isOnline
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-medium",
									children: [
										u.firstName,
										" ",
										u.lastName
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted",
									children: ["@", u.username]
								})]
							})]
						}, u.userId))] }),
						data.chats.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-2 px-1 text-xs font-medium tracking-wide text-subtle uppercase",
							children: d.chats
						}), data.chats.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "px-2 py-2 text-sm",
							children: [
								String(c.title),
								" ",
								c.username ? `@${String(c.username)}` : ""
							]
						}, String(c.id)))] }),
						data.gifts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
							className: "grid grid-cols-3 gap-2",
							children: data.gifts.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GiftArt, {
								imageKey: g.imageKey,
								rarity: g.rarity
							}, g.id))
						})
					]
				})]
			})
		]
	});
}
function ContactsScreen({ lang }) {
	const d = dict(lang);
	const nav = useNav();
	const qc = useQueryClient();
	const { data } = useQuery({
		queryKey: ["contacts"],
		queryFn: () => listContacts()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "px-5 pt-6 pb-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold tracking-tight",
				children: d.contacts
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1 overflow-y-auto px-3 pb-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-2 pt-2 pb-1 text-xs tracking-wide text-subtle uppercase",
					children: d.suggested
				}),
				(data?.suggested ?? []).map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonRow, {
					u,
					onOpen: () => nav.go({
						screen: "user",
						userId: u.userId
					})
				}, u.userId)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-2 pt-4 pb-1 text-xs tracking-wide text-subtle uppercase",
					children: d.contacts
				}),
				(data?.contacts ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-2 py-4 text-sm text-muted",
					children: d.emptyContacts
				}),
				(data?.contacts ?? []).map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonRow, {
					u,
					onOpen: () => nav.go({
						screen: "user",
						userId: u.userId
					}),
					onAdd: async () => {
						await addContact({ data: { userId: u.userId } });
						qc.invalidateQueries({ queryKey: ["contacts"] });
					}
				}, u.userId))
			]
		})]
	});
}
function PersonRow({ u, onOpen, onAdd }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 rounded-[18px] px-2 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "flex min-w-0 flex-1 items-center gap-3",
			onClick: onOpen,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
				name: u.firstName || u.username,
				url: u.avatarUrl,
				color: u.profileColor,
				frame: u.avatarFrame,
				online: u.isOnline
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "truncate font-medium",
					children: [
						u.firstName,
						" ",
						u.lastName,
						" ",
						u.isVerified && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-accent",
							children: "✓"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "truncate text-sm text-muted",
					children: ["@", u.username]
				})]
			})]
		}), onAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onAdd,
			className: "glass-btn rounded-full px-3 py-2 text-xs",
			children: "+"
		})]
	});
}
function UserScreen({ lang, me }) {
	const d = dict(lang);
	const nav = useNav();
	const userId = nav.userId ?? "";
	const qc = useQueryClient();
	const { data } = useQuery({
		queryKey: ["user", userId],
		queryFn: () => getPublicProfile({ data: { userId } }),
		enabled: Boolean(userId)
	});
	const [tab, setTab] = (0, import_react.useState)("gifts");
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-8 text-sm text-muted",
		children: "…"
	});
	const p = data.profile;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col overflow-y-auto pb-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
				title: p.username,
				onBack: () => nav.back()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-4 mt-2 overflow-hidden rounded-[28px] p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 opacity-80",
					style: { background: p.profileBg === "ink" ? "radial-gradient(circle at 20% 0%, #134e4a, #07080c 70%)" : "radial-gradient(circle at 20% 0%, color-mix(in oklab, var(--vg-accent) 45%, transparent), var(--vg-bg-elevated) 70%)" }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex flex-col items-center gap-3 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
							name: p.firstName || p.username,
							url: p.avatarUrl,
							color: p.profileColor,
							frame: p.avatarFrame,
							size: 92,
							online: p.isOnline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: cn("font-display text-2xl font-semibold", p.nameStyle === "wide" && "tracking-[0.18em]"),
							children: [
								p.firstName,
								" ",
								p.lastName
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								"@",
								p.username,
								" ",
								p.isVerified ? "· verified" : "",
								" ",
								p.isPremium ? "· Premium" : ""
							]
						})] }),
						p.bio && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-sm text-sm text-fg/80",
							children: p.bio
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-subtle",
							children: [
								d.level,
								" ",
								p.accountLevel,
								" · ",
								p.xp,
								" XP"
							]
						}),
						!data.isMe && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap justify-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "accent-btn rounded-full px-4 py-2 text-sm font-medium",
									onClick: () => nav.go({
										screen: "chat",
										chatId: void 0,
										userId: p.userId
									}),
									children: d.write
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
									label: d.call,
									onClick: async () => {
										const c = await startCall({ data: {
											calleeId: p.userId,
											kind: "audio"
										} });
										nav.go({
											screen: "call",
											call: {
												id: c.callId,
												kind: "audio",
												peerName: p.firstName,
												peerId: p.userId
											}
										});
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
									label: d.videoCall,
									onClick: async () => {
										const c = await startCall({ data: {
											calleeId: p.userId,
											kind: "video"
										} });
										nav.go({
											screen: "call",
											call: {
												id: c.callId,
												kind: "video",
												peerName: p.firstName,
												peerId: p.userId
											}
										});
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "glass-btn rounded-full px-4 py-2 text-sm",
									onClick: () => addContact({ data: { userId: p.userId } }),
									children: d.addContact
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 mt-4 flex gap-1 rounded-[16px] bg-fg/5 p-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("flex-1 rounded-[12px] py-2 text-sm", tab === "gifts" && "accent-btn"),
					onClick: () => setTab("gifts"),
					children: d.gifts
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("flex-1 rounded-[12px] py-2 text-sm", tab === "nft" && "accent-btn"),
					onClick: () => setTab("nft"),
					children: d.nft
				})]
			}),
			tab === "gifts" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-3 gap-2 px-4",
				children: data.gifts.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GiftArt, {
					imageKey: g.gift.imageKey,
					rarity: g.gift.rarity
				}, g.id))
			}),
			tab === "nft" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-2 gap-3 px-4",
				children: data.nfts.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NftArt, {
					imageKey: n.imageKey,
					rarity: n.rarity,
					className: "h-36"
				}, n.id))
			}),
			!data.isMe && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mx-4 mt-6 text-sm text-danger",
				onClick: async () => {
					await blockUser({ data: {
						userId: p.userId,
						block: true
					} });
					qc.invalidateQueries({ queryKey: ["chats"] });
					nav.go({ screen: "chats" });
				},
				children: d.blocked
			}),
			me.isOwner && !data.isMe && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mx-4 mt-2 text-sm text-accent",
				onClick: () => ownerModerate({ data: {
					userId: p.userId,
					action: "verify"
				} }),
				children: "Verify"
			})
		]
	});
}
function StoriesScreen({ lang, me }) {
	const d = dict(lang);
	const { data, refetch } = useQuery({
		queryKey: ["stories"],
		queryFn: () => listStoriesFeed(),
		refetchInterval: 8e3
	});
	const [viewer, setViewer] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)("");
	const all = [...data?.mine ?? [], ...data?.others ?? []];
	const grouped = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const s of all) {
			const arr = map.get(s.userId) ?? [];
			arr.push(s);
			map.set(s.userId, arr);
		}
		return [...map.entries()];
	}, [all]);
	const current = viewer ? all.find((s) => s.id === viewer.ids[viewer.i]) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "px-5 pt-6 pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold",
					children: d.stories
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3 overflow-x-auto px-4 pb-3 no-scrollbar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-16 shrink-0 flex-col items-center gap-1",
					onClick: async () => {
						await createStory({ data: {
							type: "text",
							body: draft || "Hello from VeltoGram"
						} });
						setDraft("");
						refetch();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-16 place-items-center rounded-full border border-dashed border-accent text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-muted",
						children: d.createStory
					})]
				}), grouped.map(([uid, items]) => {
					const first = items[0];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-16 shrink-0 flex-col items-center gap-1",
						onClick: () => setViewer({
							ids: items.map((x) => x.id),
							i: 0
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("rounded-full p-0.5", items.every((x) => x.viewed) ? "bg-fg/15" : "bg-linear-to-br from-accent to-star"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
								name: first.profile.firstName || first.profile.username,
								url: first.profile.avatarUrl,
								color: first.profile.profileColor,
								size: 60
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-full truncate text-[11px] text-muted",
							children: uid === me.profile.userId ? "You" : first.profile.firstName
						})]
					}, uid);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: draft,
					onChange: (e) => setDraft(e.target.value),
					placeholder: d.textStory,
					className: "glass h-24 w-full resize-none rounded-[20px] p-3 outline-none"
				})
			}),
			current && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 flex flex-col bg-black/90",
				onClick: () => setViewer(null),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-1 w-full bg-white/20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-accent",
							style: { width: `${(viewer.i + 1) / viewer.ids.length * 100}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-1 flex-col items-center justify-center p-6 text-center",
						children: [current.mediaUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: current.mediaUrl,
							alt: "",
							className: "max-h-[70vh] rounded-[24px]"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl font-semibold text-white",
							children: current.body
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-white/70",
							children: current.profile.firstName
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-center gap-3 p-4",
						children: [
							"✦",
							"♡",
							"★"
						].map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "glass-btn rounded-full px-4 py-2 text-white",
							onClick: async (ev) => {
								ev.stopPropagation();
								await viewStory({ data: {
									id: current.id,
									reaction: e
								} });
							},
							children: e
						}, e))
					})
				]
			})
		]
	});
}
function StarsScreen({ lang }) {
	const d = dict(lang);
	useNav();
	const qc = useQueryClient();
	const { data } = useQuery({
		queryKey: ["wallet"],
		queryFn: () => getWallet(),
		refetchInterval: 6e3
	});
	const { data: catalog } = useQuery({
		queryKey: ["catalog"],
		queryFn: () => listCatalog()
	});
	const { data: inv } = useQuery({
		queryKey: ["inventory"],
		queryFn: () => listMyInventory()
	});
	const [tab, setTab] = (0, import_react.useState)("wallet");
	const claim = useMutation({
		mutationFn: () => claimDaily(),
		onSuccess: () => qc.invalidateQueries({ queryKey: ["wallet"] })
	});
	const premium = useMutation({
		mutationFn: () => buyPremium({ data: { idempotencyKey: newKey() } }),
		onSuccess: () => {
			qc.invalidateQueries({ queryKey: ["wallet"] });
			qc.invalidateQueries({ queryKey: ["session"] });
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col overflow-y-auto pb-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "px-5 pt-6 pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold",
					children: d.wallet
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 glass-strong rounded-[28px] p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: d.balance
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-4xl font-semibold tracking-tight text-star",
						children: data?.wallet.balance ?? 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-subtle",
						children: "Velto Stars"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: data?.wallet.dailyClaimed || claim.isPending,
							onClick: () => claim.mutate(),
							className: "accent-btn flex-1 rounded-full py-2.5 text-sm font-medium disabled:opacity-40",
							children: data?.wallet.dailyClaimed ? d.claimed : d.claimDaily
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => premium.mutate(),
							className: "glass-btn flex-1 rounded-full py-2.5 text-sm",
							children: d.buyPremium
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-4 mt-4 flex gap-1 rounded-[16px] bg-fg/5 p-1",
				children: [
					"wallet",
					"gifts",
					"nft"
				].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("flex-1 rounded-[12px] py-2 text-sm", tab === k && "accent-btn"),
					onClick: () => setTab(k),
					children: k === "wallet" ? d.history : k === "gifts" ? d.gifts : d.nft
				}, k))
			}),
			tab === "wallet" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-1 px-4",
				children: (data?.txs ?? []).map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between rounded-[16px] px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: tx.kind
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-subtle",
						children: [
							formatTime(tx.createdAt, lang),
							" · ",
							tx.id.slice(0, 14)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-star",
						children: tx.amount
					})]
				}, tx.id))
			}),
			tab === "gifts" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-2 gap-3 px-4",
				children: (catalog?.gifts ?? []).map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass rounded-[24px] p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GiftArt, {
							imageKey: g.imageKey,
							rarity: g.rarity
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-medium",
							children: g.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								d[g.rarity] ?? g.rarity,
								" · ",
								g.cost,
								" ★"
							]
						})
					]
				}, g.id))
			}),
			tab === "nft" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-2 gap-3 px-4",
				children: (catalog?.nfts ?? []).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass rounded-[24px] p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NftArt, {
							imageKey: n.imageKey,
							rarity: n.rarity,
							className: "h-32"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm font-medium",
							children: n.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-subtle",
							children: n.id
						})
					]
				}, n.id))
			}),
			(inv?.gifts.length ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm text-muted",
					children: d.collection
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto no-scrollbar",
					children: inv.gifts.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "w-20 shrink-0",
						onClick: () => g.gift.convertibleToNft && convertGiftNft({ data: { instanceId: g.id } }).then(() => qc.invalidateQueries({ queryKey: ["inventory"] })),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GiftArt, {
							imageKey: g.gift.imageKey,
							rarity: g.gift.rarity
						})
					}, g.id))
				})]
			})
		]
	});
}
function ProfileScreen({ lang, session, setLang }) {
	const d = dict(lang);
	const nav = useNav();
	const p = session.profile;
	const qc = useQueryClient();
	const { data: notes } = useQuery({
		queryKey: ["notes"],
		queryFn: () => listNotifications(),
		refetchInterval: 8e3
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col overflow-y-auto pb-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-5 pt-6 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold",
					children: d.profile
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
					label: d.settings,
					onClick: () => nav.go({ screen: "settings" }),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "mx-4 glass flex items-center gap-4 rounded-[24px] p-4 text-left",
				onClick: () => nav.go({
					screen: "user",
					userId: p.userId
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
					name: p.firstName || p.username,
					url: p.avatarUrl,
					color: p.profileColor,
					frame: p.avatarFrame,
					size: 64
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-lg font-semibold",
							children: [
								p.firstName,
								" ",
								p.lastName
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: ["@", p.username]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-subtle",
							children: [
								d.level,
								" ",
								p.accountLevel,
								" ",
								p.isPremium ? "· Premium" : "",
								" ",
								session.isOwner ? "· Owner" : ""
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-2 px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickTile, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4" }),
						label: d.wallet,
						onClick: () => nav.go({ screen: "stars" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickTile, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "size-4" }),
						label: d.gifts,
						onClick: () => nav.go({ screen: "stars" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickTile, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "size-4" }),
						label: d.nft,
						onClick: () => nav.go({ screen: "stars" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickTile, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }),
						label: d.notifications,
						onClick: () => {
							markNotificationsRead();
							nav.go({ screen: "notifications" });
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickTile, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }),
						label: d.install,
						onClick: () => nav.go({ screen: "install" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickTile, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-4" }),
						label: d.language,
						onClick: () => nav.go({ screen: "settings" })
					}),
					session.isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickTile, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4" }),
						label: d.ownerPanel,
						onClick: () => nav.go({ screen: "owner" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickTile, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }),
						label: d.about,
						onClick: () => nav.go({ screen: "info" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs tracking-wide text-subtle uppercase",
					children: d.language
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: LANGS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setLang(l.id);
							updateProfile({ data: { language: l.id } }).then(() => qc.invalidateQueries({ queryKey: ["session"] }));
						},
						className: cn("rounded-full px-3 py-1.5 text-xs", lang === l.id ? "accent-btn" : "glass-btn"),
						children: l.label
					}, l.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}), (notes ?? []).filter((n) => !n.read).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs text-accent",
					children: [(notes ?? []).filter((n) => !n.read).length, " new"]
				})]
			})
		]
	});
}
function QuickTile({ icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "glass flex items-center gap-2 rounded-[20px] px-3 py-3 text-left text-sm",
		children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
	});
}
function SettingsScreen({ lang, session }) {
	const d = dict(lang);
	const nav = useNav();
	const qc = useQueryClient();
	const p = session.profile;
	const [form, setForm] = (0, import_react.useState)({
		firstName: p.firstName,
		lastName: p.lastName,
		username: p.username,
		bio: p.bio,
		phone: p.phone ?? "",
		statusText: p.statusText ?? ""
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col overflow-y-auto pb-28",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: d.settings,
			onBack: () => nav.back()
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-3 px-4 pt-3",
			onSubmit: async (e) => {
				e.preventDefault();
				await updateProfile({ data: form });
				qc.invalidateQueries({ queryKey: ["session"] });
				nav.go({ screen: "profile" });
			},
			children: [
				[
					"firstName",
					"lastName",
					"username",
					"phone",
					"bio",
					"statusText"
				].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-xs text-muted",
					children: [d[k] ?? k, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: form[k],
						onChange: (e) => setForm({
							...form,
							[k]: e.target.value
						}),
						className: "glass mt-1 h-12 w-full rounded-[16px] px-3 text-sm text-fg outline-none"
					})]
				}, k)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-wide text-subtle uppercase",
					children: d.theme
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2",
					children: [
						"dark",
						"light",
						"amoled"
					].map((th) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn("glass-btn flex-1 rounded-full py-2 text-sm", p.theme === th && "accent-btn"),
						onClick: () => updateProfile({ data: { theme: th } }).then(() => qc.invalidateQueries({ queryKey: ["session"] })),
						children: d[th]
					}, th))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-wide text-subtle uppercase",
					children: d.accent
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2",
					children: [
						"teal",
						"ice",
						"sand",
						"rose"
					].map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn("h-10 flex-1 rounded-full", p.accent === a ? "ring-2 ring-fg" : ""),
						style: { background: a === "teal" ? "#2dd4bf" : a === "ice" ? "#7dd3fc" : a === "sand" ? "#e8c36a" : "#fb7185" },
						onClick: () => updateProfile({ data: { accent: a } }).then(() => qc.invalidateQueries({ queryKey: ["session"] }))
					}, a))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "accent-btn mt-2 h-12 rounded-[16px] font-medium",
					children: d.save
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-12 text-sm text-danger",
					onClick: () => signOut("/login"),
					children: d.signOut
				})
			]
		})]
	});
}
function OwnerScreen({ lang }) {
	const d = dict(lang);
	const nav = useNav();
	const { data, refetch } = useQuery({
		queryKey: ["owner"],
		queryFn: () => ownerStats()
	});
	const [cmd, setCmd] = (0, import_react.useState)("/stats");
	const [out, setOut] = (0, import_react.useState)("");
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-6 text-sm text-muted",
		children: "…"
	});
	const cards = [
		[d.users, data.users],
		[d.online, data.online],
		[d.chats, data.messages],
		[d.groups, data.groups],
		[d.channels, data.channels],
		[d.stories, data.stories],
		[d.stars, data.starsCirculating],
		[d.gifts, data.gifts],
		[d.nft, data.nfts],
		[d.premium, data.premium]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col overflow-y-auto pb-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
				title: d.ownerPanel,
				onBack: () => nav.back()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 px-4 pt-2",
				children: cards.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass rounded-[20px] p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl font-semibold",
						children: v
					})]
				}, String(k)))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 flex gap-2 px-4",
				onSubmit: async (e) => {
					e.preventDefault();
					const r = await ownerCommand({ data: { command: cmd } });
					setOut(r.reply);
					refetch();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: cmd,
					onChange: (e) => setCmd(e.target.value),
					className: "glass h-11 flex-1 rounded-full px-4 text-sm outline-none"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "accent-btn rounded-full px-4 text-sm",
					children: d.grant
				})]
			}),
			out && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mx-4 mt-3 whitespace-pre-wrap rounded-[16px] bg-fg/5 p-3 text-xs",
				children: out
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 px-4",
				children: data.people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "text-left",
						onClick: () => nav.go({
							screen: "user",
							userId: p.userId
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-medium",
							children: [
								p.firstName,
								" @",
								p.username
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-subtle",
							children: p.userId.slice(0, 16)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-xs text-accent",
						onClick: () => ownerModerate({ data: {
							userId: p.userId,
							action: "verify"
						} }),
						children: d.verified
					})]
				}, p.userId))
			})
		]
	});
}
function CreateScreen({ lang }) {
	const d = dict(lang);
	const nav = useNav();
	const qc = useQueryClient();
	const [mode, setMode] = (0, import_react.useState)("group");
	const [title, setTitle] = (0, import_react.useState)("");
	const [username, setUsername] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [isPublic, setIsPublic] = (0, import_react.useState)(true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
				title: mode === "group" ? d.newGroup : d.newChannel,
				onBack: () => nav.back()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 mt-2 flex gap-1 rounded-[16px] bg-fg/5 p-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("flex-1 rounded-[12px] py-2 text-sm", mode === "group" && "accent-btn"),
					onClick: () => setMode("group"),
					children: d.newGroup
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("flex-1 rounded-[12px] py-2 text-sm", mode === "channel" && "accent-btn"),
					onClick: () => setMode("channel"),
					children: d.newChannel
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3 p-4",
				onSubmit: async (e) => {
					e.preventDefault();
					const r = await createGroup({ data: {
						title,
						username: username || void 0,
						description,
						isChannel: mode === "channel",
						isPublic
					} });
					qc.invalidateQueries({ queryKey: ["chats"] });
					nav.go({
						screen: "chat",
						chatId: r.chatId
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: title,
						onChange: (e) => setTitle(e.target.value),
						placeholder: d.firstName,
						className: "glass h-12 rounded-[16px] px-4 outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: username,
						onChange: (e) => setUsername(e.target.value),
						placeholder: d.username,
						className: "glass h-12 rounded-[16px] px-4 outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: description,
						onChange: (e) => setDescription(e.target.value),
						placeholder: d.description,
						className: "glass h-24 rounded-[16px] p-4 outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: isPublic,
							onChange: (e) => setIsPublic(e.target.checked)
						}), d.publicCh]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "accent-btn h-12 rounded-[16px] font-medium",
						children: d.create
					})
				]
			})
		]
	});
}
function InstallScreen({ lang }) {
	const d = dict(lang);
	const nav = useNav();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col overflow-y-auto pb-28",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: d.install,
			onBack: () => nav.back()
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-4 mt-4 glass-strong rounded-[28px] p-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VeltoMark, { className: "mx-auto size-16" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-2xl font-semibold",
					children: "VeltoGram"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: d.installHint
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/downloads/veltogram.apk",
					download: true,
					className: "accent-btn mt-5 inline-flex h-12 items-center justify-center rounded-full px-6 font-medium",
					children: d.downloadApk
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-xs text-subtle",
					children: [d.addToHome, ": Chrome → menu → Add to Home screen"]
				})
			]
		})]
	});
}
function InfoScreen({ lang }) {
	const d = dict(lang);
	const nav = useNav();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col overflow-y-auto px-5 pb-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
				title: d.about,
				onBack: () => nav.back()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VeltoMark, { className: "mt-4 size-14" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 font-display text-2xl font-semibold",
				children: "VeltoGram 1.0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: "Fast messenger with chats, groups, channels, Stories, Velto Stars, gifts, NFT collectibles, Premium, and a locked Owner Bot. Liquid Glass interface. Not affiliated with Telegram or Apple."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-6 font-medium",
				children: d.whatsNew
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-2 list-disc space-y-1 pl-5 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Realtime-style messaging with delivery states" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stars wallet with idempotent ledger" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Owner Panel + Owner Bot (OWNER_ID server check)" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Fifteen languages, AMOLED, custom accents" })
				]
			})
		]
	});
}
function NotificationsScreen({ lang }) {
	const d = dict(lang);
	const nav = useNav();
	const { data } = useQuery({
		queryKey: ["notes"],
		queryFn: () => listNotifications()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: d.notifications,
			onBack: () => nav.back()
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex-1 overflow-y-auto px-4 pb-24",
			children: (data ?? []).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border-b border-border py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: n.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: n.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-subtle",
						children: formatTime(n.createdAt, lang)
					})
				]
			}, n.id))
		})]
	});
}
function CallScreen() {
	const nav = useNav();
	const call = nav.call;
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [cam, setCam] = (0, import_react.useState)(call?.kind !== "audio");
	const [stream, setStream] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!call || call.kind === "audio") return;
		let local = null;
		navigator.mediaDevices?.getUserMedia({
			video: true,
			audio: true
		}).then((s) => {
			local = s;
			setStream(s);
		}).catch(() => void 0);
		return () => local?.getTracks().forEach((t) => t.stop());
	}, [call?.id, call?.kind]);
	if (!call) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex flex-col bg-[#05070a] text-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				autoPlay: true,
				muted: true,
				ref: (el) => {
					if (el && stream) el.srcObject = stream;
				},
				className: cn("absolute inset-0 size-full object-cover", cam ? "opacity-80" : "opacity-0")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 flex flex-1 flex-col items-center justify-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						name: call.peerName,
						size: 96
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl",
						children: call.peerName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-white/60",
						children: call.kind === "video" ? "Video" : "Voice"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 flex justify-center gap-4 pb-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "glass-btn size-14 rounded-full",
						onClick: () => setMuted((m) => !m),
						children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "mx-auto size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "mx-auto size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "glass-btn size-14 rounded-full",
						onClick: () => setCam((c) => !c),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "mx-auto size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "size-16 rounded-full bg-danger text-white",
						onClick: () => {
							stream?.getTracks().forEach((t) => t.stop());
							nav.go({
								screen: "chats",
								call: null
							});
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "mx-auto size-6 rotate-135" })
					})
				]
			})
		]
	});
}
function GiftPicker({ toUserId, onClose }) {
	const { data } = useQuery({
		queryKey: ["catalog"],
		queryFn: () => listCatalog()
	});
	const qc = useQueryClient();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-x-0 bottom-0 z-30 glass-strong max-h-[55%] overflow-y-auto rounded-t-[28px] p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "Gifts"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onClose,
				children: "Close"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-3 gap-2",
			children: (data?.gifts ?? []).map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "text-left",
				onClick: async () => {
					await buyGift({ data: {
						giftId: g.id,
						toUserId,
						idempotencyKey: newKey()
					} });
					qc.invalidateQueries({ queryKey: ["wallet"] });
					qc.invalidateQueries({ queryKey: ["messages"] });
					onClose();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GiftArt, {
						imageKey: g.imageKey,
						rarity: g.rarity
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 truncate text-xs",
						children: g.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-star",
						children: [g.cost, " ★"]
					})
				]
			}, g.id))
		})]
	});
}
function Onboarding({ session }) {
	const qc = useQueryClient();
	const [form, setForm] = (0, import_react.useState)({
		firstName: session.profile.firstName === "Traveler" ? "" : session.profile.firstName,
		lastName: session.profile.lastName,
		username: session.profile.username.startsWith("velto_") ? "" : session.profile.username
	});
	const [err, setErr] = (0, import_react.useState)(null);
	const d = dict(session.profile.language);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 grid place-items-center bg-black/50 p-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "glass-strong w-full max-w-md rounded-[28px] p-6",
			onSubmit: async (e) => {
				e.preventDefault();
				setErr(null);
				try {
					await updateProfile({ data: form });
					qc.invalidateQueries({ queryKey: ["session"] });
				} catch (ex) {
					setErr(ex instanceof Error ? ex.message : "Error");
				}
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold",
					children: d.onboardingTitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: d.onboardingHint
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "glass mt-4 h-12 w-full rounded-[16px] px-4",
					placeholder: d.firstName,
					value: form.firstName,
					onChange: (e) => setForm({
						...form,
						firstName: e.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "glass mt-2 h-12 w-full rounded-[16px] px-4",
					placeholder: d.lastName,
					value: form.lastName,
					onChange: (e) => setForm({
						...form,
						lastName: e.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "glass mt-2 h-12 w-full rounded-[16px] px-4",
					placeholder: d.username,
					value: form.username,
					onChange: (e) => setForm({
						...form,
						username: e.target.value
					})
				}),
				err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-danger",
					children: err
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "accent-btn mt-4 h-12 w-full rounded-[16px] font-medium",
					children: d.continue
				})
			]
		})
	});
}
function StarsSendSheet({ toUserId, onClose }) {
	const [amount, setAmount] = (0, import_react.useState)("50");
	const qc = useQueryClient();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-x-0 bottom-0 z-30 glass-strong rounded-t-[28px] p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "Send Stars"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: amount,
				onChange: (e) => setAmount(e.target.value),
				type: "number",
				className: "glass mt-3 h-12 w-full rounded-[16px] px-4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "accent-btn mt-3 h-12 w-full rounded-[16px]",
				onClick: async () => {
					await sendStars({ data: {
						toUserId,
						amount: Number(amount),
						idempotencyKey: newKey()
					} });
					qc.invalidateQueries({ queryKey: ["wallet"] });
					qc.invalidateQueries({ queryKey: ["messages"] });
					onClose();
				},
				children: "Send"
			})
		]
	});
}
var queryClient = new QueryClient({ defaultOptions: { queries: {
	retry: 1,
	refetchOnWindowFocus: true
} } });
function VeltoApp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
			theme: "dark",
			position: "top-center"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gate, {})]
	});
}
function Gate() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Boot, {});
}
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 w-40 animate-pulse rounded-[28px] bg-fg/10" })
	});
}
function Boot() {
	const { data, isPending, error } = useQuery({
		queryKey: ["session"],
		queryFn: () => bootstrapSession(),
		retry: 1
	});
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (error || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { session: data });
}
function Shell({ session }) {
	const lang = session.profile.language || "en";
	const nav = useNav();
	const qc = useQueryClient();
	const [langOverride, setLangOverride] = (0, import_react.useState)(null);
	const effectiveLang = langOverride ?? lang;
	(0, import_react.useEffect)(() => {
		document.documentElement.dataset.theme = session.profile.theme;
		document.documentElement.dataset.accent = session.profile.accent;
		document.documentElement.lang = effectiveLang;
		document.documentElement.dir = isRtl(effectiveLang) ? "rtl" : "ltr";
	}, [
		session.profile.theme,
		session.profile.accent,
		effectiveLang
	]);
	(0, import_react.useEffect)(() => {
		const t = window.setInterval(() => {
			heartbeat().catch(() => void 0);
		}, 2e4);
		heartbeat().catch(() => void 0);
		return () => window.clearInterval(t);
	}, []);
	const { data: chats } = useQuery({
		queryKey: ["chats"],
		queryFn: () => listChats(),
		refetchInterval: 3e3
	});
	(0, import_react.useEffect)(() => {
		if (nav.screen === "chat" && !nav.chatId && nav.userId) createDm({ data: { userId: nav.userId } }).then((r) => {
			nav.go({
				screen: "chat",
				chatId: r.chatId
			});
			qc.invalidateQueries({ queryKey: ["chats"] });
		});
	}, [
		nav.screen,
		nav.chatId,
		nav.userId
	]);
	const d = dict(effectiveLang);
	const tabs = [
		{
			id: "chats",
			label: d.chats,
			icon: MessageCircle
		},
		{
			id: "stories",
			label: d.stories,
			icon: Sparkles
		},
		{
			id: "contacts",
			label: d.contacts,
			icon: Users
		},
		{
			id: "stars",
			label: d.stars,
			icon: Star
		},
		{
			id: "profile",
			label: d.profile,
			icon: Bookmark
		}
	];
	const showNav = [
		"chats",
		"stories",
		"contacts",
		"stars",
		"profile"
	].includes(nav.screen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto flex h-dvh max-w-6xl overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: cn("hidden h-full w-[380px] shrink-0 border-r border-border md:flex md:flex-col", nav.screen === "chat" && "md:flex"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatList, {
					chats: chats ?? [],
					lang: effectiveLang
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-0 flex-1 flex-col",
					children: [
						nav.screen === "chats" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "md:hidden h-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatList, {
								chats: chats ?? [],
								lang: effectiveLang
							})
						}),
						nav.screen === "chats" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden h-full md:grid place-items-center text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VeltoWordmark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm",
									children: d.emptyChats
								})]
							})
						}),
						nav.screen === "chat" && nav.chatId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatThread, {
							session,
							chatId: nav.chatId,
							chats: chats ?? [],
							lang: effectiveLang
						}),
						nav.screen === "stories" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoriesScreen, {
							lang: effectiveLang,
							me: session
						}),
						nav.screen === "contacts" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactsScreen, { lang: effectiveLang }),
						nav.screen === "stars" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarsScreen, { lang: effectiveLang }),
						nav.screen === "profile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileScreen, {
							lang: effectiveLang,
							session,
							setLang: setLangOverride
						}),
						nav.screen === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsScreen, {
							lang: effectiveLang,
							session
						}),
						nav.screen === "owner" && session.isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OwnerScreen, { lang: effectiveLang }),
						nav.screen === "search" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchScreen, { lang: effectiveLang }),
						nav.screen === "create" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateScreen, { lang: effectiveLang }),
						nav.screen === "user" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserScreen, {
							lang: effectiveLang,
							me: session
						}),
						nav.screen === "install" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallScreen, { lang: effectiveLang }),
						nav.screen === "info" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoScreen, { lang: effectiveLang }),
						nav.screen === "notifications" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationsScreen, { lang: effectiveLang })
					]
				}), showNav && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "glass absolute inset-x-3 bottom-3 z-20 flex h-16 items-center justify-around rounded-full px-2 md:left-auto md:right-6 md:w-[380px]",
					children: tabs.map((tab) => {
						const active = nav.screen === tab.id;
						const Icon = tab.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => nav.go({
								screen: tab.id,
								chatId: void 0
							}),
							className: cn("flex h-12 min-w-12 flex-col items-center justify-center rounded-full px-3 text-[10px] transition-transform duration-150", active ? "text-accent" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: cn("size-5", active && "fill-accent/20") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 font-medium",
								children: tab.label
							})]
						}, tab.id);
					})
				})]
			}),
			nav.call && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallScreen, {}),
			session.needsOnboarding && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboarding, { session })
		]
	});
}
function ChatList({ chats, lang }) {
	const d = dict(lang);
	const nav = useNav();
	const [q, setQ] = (0, import_react.useState)("");
	const filtered = chats.filter((c) => c.title.toLowerCase().includes(q.toLowerCase()) || (c.username ?? "").includes(q.toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-2 px-4 pt-5 pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VeltoWordmark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": d.search,
						className: "glass-btn grid size-11 place-items-center rounded-full",
						onClick: () => nav.go({ screen: "search" }),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": d.newChat,
						className: "accent-btn grid size-11 place-items-center rounded-full",
						onClick: () => nav.go({ screen: "create" }),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoriesStrip, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 pb-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass flex h-11 items-center gap-2 rounded-full px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: d.search,
						className: "h-full flex-1 bg-transparent text-sm outline-none"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 overflow-y-auto px-2 pb-28",
				children: [filtered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 py-8 text-sm text-muted",
					children: d.emptyChats
				}), filtered.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => nav.go({
						screen: "chat",
						chatId: c.id
					}),
					onContextMenu: (e) => {
						e.preventDefault();
						pinChat({ data: {
							chatId: c.id,
							pinned: !c.pinned
						} });
					},
					className: "flex w-full items-center gap-3 rounded-[20px] px-2 py-2.5 text-left hover:bg-fg/5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						name: c.title,
						url: c.avatarUrl,
						color: c.peer?.profileColor,
						frame: c.peer?.avatarFrame,
						online: c.peer?.isOnline
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate font-medium",
								children: [
									c.pinned ? "· " : "",
									c.title,
									c.peer?.isVerified || c.type === "channel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-1 text-accent",
										children: "✓"
									}) : null
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-subtle",
								children: formatTime(c.lastAt, lang)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm text-muted",
								children: preview(c, d.typeMessage)
							}), c.unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid min-w-5 place-items-center rounded-full bg-accent px-1.5 text-[11px] font-semibold text-accent-fg",
								children: c.unread
							})]
						})]
					})]
				}, c.id))]
			})
		]
	});
}
function StoriesStrip() {
	const { data } = useQuery({
		queryKey: ["stories"],
		queryFn: () => import("./server-CnIqMpdJ.mjs").then((m) => m.listStoriesFeed()),
		refetchInterval: 1e4
	});
	const nav = useNav();
	const others = data?.others ?? [];
	const seen = /* @__PURE__ */ new Set();
	const unique = others.filter((s) => seen.has(s.userId) ? false : (seen.add(s.userId), true));
	if (unique.length === 0 && (data?.mine.length ?? 0) === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-3 overflow-x-auto px-4 py-2 no-scrollbar",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "flex w-14 shrink-0 flex-col items-center",
			onClick: () => nav.go({ screen: "stories" }),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-12 place-items-center rounded-full bg-accent/20 text-accent",
				children: "+"
			})
		}), unique.slice(0, 12).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "flex w-14 shrink-0 flex-col items-center",
			onClick: () => nav.go({ screen: "stories" }),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-full bg-linear-to-br from-accent to-star p-0.5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
					name: s.profile.firstName,
					url: s.profile.avatarUrl,
					color: s.profile.profileColor,
					size: 44
				})
			})
		}, s.userId))]
	});
}
function preview(c, fallback) {
	if (c.lastType === "gift") return "Gift";
	if (c.lastType === "stars") return "Stars";
	if (c.lastType === "voice") return "Voice";
	if (c.lastType === "sticker") return "Sticker";
	if (c.lastType === "photo") return "Photo";
	return c.lastText || fallback;
}
function ChatThread({ session, chatId, chats, lang }) {
	const d = dict(lang);
	const nav = useNav();
	const qc = useQueryClient();
	const chat = chats.find((c) => c.id === chatId);
	const { data } = useQuery({
		queryKey: ["messages", chatId],
		queryFn: () => listMessages({ data: { chatId } }),
		refetchInterval: 2e3
	});
	const scroller = (0, import_react.useRef)(null);
	const [text, setText] = (0, import_react.useState)("");
	const [menu, setMenu] = (0, import_react.useState)(null);
	const [gifts, setGifts] = (0, import_react.useState)(false);
	const [stars, setStars] = (0, import_react.useState)(false);
	const [stickers, setStickers] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const fileRef = (0, import_react.useRef)(null);
	const { data: catalog } = useQuery({
		queryKey: ["catalog"],
		queryFn: () => listCatalog()
	});
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (el) el.scrollTop = el.scrollHeight;
	}, [data?.messages.length]);
	const send = useMutation({
		mutationFn: (payload) => sendMessage({ data: payload }),
		onSuccess: () => {
			setText("");
			setEditing(null);
			qc.invalidateQueries({ queryKey: ["messages", chatId] });
			qc.invalidateQueries({ queryKey: ["chats"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const peerId = chat?.peer?.userId;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "glass flex items-center gap-2 px-2 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center md:hidden",
						onClick: () => nav.go({ screen: "chats" }),
						children: "‹"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex min-w-0 flex-1 items-center gap-3 px-1",
						onClick: () => peerId && nav.go({
							screen: "user",
							userId: peerId
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
							name: chat?.title ?? "Chat",
							url: chat?.avatarUrl,
							color: chat?.peer?.profileColor,
							online: chat?.peer?.isOnline
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-medium",
								children: chat?.title ?? "Chat"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted",
								children: data?.typing[0] ? d.typing : chat?.peer ? lastSeenLabel(chat.peer.lastSeen, chat.peer.isOnline, lang, d.online, d.lastSeen) : chat?.type === "channel" ? `${chat.memberCount} ${d.subscribers}` : `${chat?.memberCount ?? 0} ${d.members}`
							})]
						})]
					}),
					peerId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center",
							onClick: async () => {
								const c = await startCall({ data: {
									calleeId: peerId,
									chatId,
									kind: "audio"
								} });
								nav.go({ call: {
									id: c.callId,
									kind: "audio",
									peerName: chat?.title ?? "",
									peerId
								} });
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center",
							onClick: async () => {
								const c = await startCall({ data: {
									calleeId: peerId,
									chatId,
									kind: "video"
								} });
								nav.go({ call: {
									id: c.callId,
									kind: "video",
									peerName: chat?.title ?? "",
									peerId
								} });
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center",
						onClick: () => pinChat({ data: {
							chatId,
							pinned: !chat?.pinned
						} }).then(() => qc.invalidateQueries({ queryKey: ["chats"] })),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EllipsisVertical, { className: "size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: scroller,
				className: "flex-1 space-y-1 overflow-y-auto px-3 py-3",
				children: (data?.messages ?? []).map((m) => {
					const mine = m.senderId === session.profile.userId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
						onDoubleClick: () => reactMessage({ data: {
							id: m.id,
							emoji: "♡"
						} }).then(() => qc.invalidateQueries({ queryKey: ["messages", chatId] })),
						onContextMenu: (e) => {
							e.preventDefault();
							setMenu(m);
						},
						className: cn("flex", mine ? "justify-end" : "justify-start"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("max-w-[80%] rounded-[22px] px-3.5 py-2.5 text-sm leading-relaxed", mine ? "rounded-br-md" : "rounded-bl-md"),
							style: { background: mine ? "var(--vg-bubble-out)" : "var(--vg-bubble-in)" },
							children: [
								!mine && chat?.type !== "dm" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-0.5 text-xs font-medium text-accent",
									children: m.sender?.firstName ?? m.senderId
								}),
								m.replyToId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-1 border-l-2 border-accent/50 pl-2 text-xs text-muted",
									children: "reply"
								}),
								m.type === "photo" && m.mediaUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: m.mediaUrl,
									alt: "",
									className: "mb-1 max-h-64 rounded-[16px]"
								}),
								m.type === "sticker" && m.mediaMeta && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickerArt, { imageKey: String(m.mediaMeta.imageKey ?? "face-hello") }),
								m.type === "gift" && m.mediaMeta && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-28",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GiftArt, {
										imageKey: String(m.mediaMeta.imageKey ?? "spark"),
										rarity: m.mediaMeta.rarity ?? "common"
									})
								}),
								m.type === "voice" && m.mediaUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
									controls: true,
									src: m.mediaUrl,
									className: "max-w-full"
								}),
								m.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Formatted, {
									text: m.body,
									spoiler: m.isSpoiler
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex items-center justify-end gap-1 text-[10px] text-subtle",
									children: [
										m.isEdited && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: d.edited }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatTime(m.createdAt, lang) }),
										mine && (m.status === "read" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "size-3 text-accent" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }))
									]
								}),
								m.reactions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 flex gap-1",
									children: m.reactions.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded-full bg-fg/10 px-1.5 text-[11px]",
										children: [
											r.emoji,
											" ",
											r.count
										]
									}, r.emoji))
								})
							]
						})
					}, m.id);
				})
			}),
			menu && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-strong absolute bottom-24 left-4 right-4 z-20 rounded-[24px] p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						"♡",
						"✦",
						"★",
						"✓"
					].map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "glass-btn rounded-full px-3 py-2",
						onClick: () => {
							reactMessage({ data: {
								id: menu.id,
								emoji: e
							} }).then(() => qc.invalidateQueries({ queryKey: ["messages", chatId] }));
							setMenu(null);
						},
						children: e
					}, e))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid grid-cols-2 gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								navigator.clipboard.writeText(menu.body ?? "");
								setMenu(null);
							},
							children: d.copy
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setEditing(menu);
								setText(menu.body ?? "");
								setMenu(null);
							},
							children: d.edit
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => pinMessage({ data: {
								id: menu.id,
								chatId,
								pinned: true
							} }).then(() => setMenu(null)),
							children: d.pin
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-danger",
							onClick: () => deleteMessage({ data: {
								id: menu.id,
								chatId
							} }).then(() => {
								qc.invalidateQueries({ queryKey: ["messages", chatId] });
								setMenu(null);
							}),
							children: d.delete
						})
					]
				})]
			}),
			gifts && peerId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GiftPicker, {
				toUserId: peerId,
				onClose: () => setGifts(false)
			}),
			stars && peerId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarsSendSheet, {
				toUserId: peerId,
				onClose: () => setStars(false)
			}),
			stickers && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-x-0 bottom-20 z-20 glass-strong max-h-56 overflow-y-auto rounded-t-[24px] p-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: (catalog?.stickers ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							send.mutate({
								chatId,
								type: "sticker",
								body: s.emoji,
								mediaMeta: { imageKey: s.image_key }
							});
							setStickers(false);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickerArt, { imageKey: s.image_key })
					}, s.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "glass m-3 flex items-end gap-2 rounded-full p-1.5",
				onSubmit: (e) => {
					e.preventDefault();
					if (editing) {
						editMessage({ data: {
							id: editing.id,
							body: text
						} }).then(() => {
							setEditing(null);
							setText("");
							qc.invalidateQueries({ queryKey: ["messages", chatId] });
						});
						return;
					}
					if (!text.trim()) return;
					send.mutate({
						chatId,
						body: text,
						type: "text"
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "image/*,audio/*,application/pdf",
						className: "hidden",
						onChange: async (e) => {
							const f = e.target.files?.[0];
							if (!f) return;
							const url = await fileToDataUrl(f);
							const type = f.type.startsWith("audio") ? "voice" : f.type.startsWith("image") ? "photo" : "file";
							send.mutate({
								chatId,
								type,
								mediaUrl: url,
								body: f.name
							});
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center",
						onClick: () => fileRef.current?.click(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center",
						onClick: () => setStickers((s) => !s),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smile, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 1,
						value: text,
						onChange: (e) => {
							setText(e.target.value);
							setTyping({ data: { chatId } }).catch(() => void 0);
						},
						placeholder: d.typeMessage,
						className: "max-h-28 min-h-10 flex-1 resize-none bg-transparent py-2.5 text-sm outline-none"
					}),
					peerId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center text-star",
						onClick: () => setGifts(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" })
					}),
					text.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "accent-btn grid size-10 place-items-center rounded-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoiceBtn, { onSend: (url) => send.mutate({
						chatId,
						type: "voice",
						mediaUrl: url
					}) })
				]
			})
		]
	});
}
function VoiceBtn({ onSend }) {
	const rec = (0, import_react.useRef)(null);
	const [on, setOn] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: cn("grid size-10 place-items-center rounded-full", on && "bg-danger text-white"),
		onClick: async () => {
			if (on) {
				rec.current?.stop();
				setOn(false);
				return;
			}
			const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			const mr = new MediaRecorder(stream);
			const chunks = [];
			mr.ondataavailable = (e) => chunks.push(e.data);
			mr.onstop = async () => {
				stream.getTracks().forEach((t) => t.stop());
				const blob = new Blob(chunks, { type: "audio/webm" });
				const reader = new FileReader();
				reader.onload = () => onSend(String(reader.result));
				reader.readAsDataURL(blob);
			};
			rec.current = mr;
			mr.start();
			setOn(true);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" })
	});
}
function Formatted({ text, spoiler }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	if (spoiler && !open) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "rounded bg-fg/20 px-1",
		onClick: () => setOpen(true),
		children: "Hidden"
	});
	const parts = text.split(/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\|\|[^|]+\|\|)/g);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "whitespace-pre-wrap break-words",
		children: parts.map((p, i) => {
			if (p.startsWith("**") && p.endsWith("**")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: p.slice(2, -2) }, i);
			if (p.startsWith("*") && p.endsWith("*")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: p.slice(1, -1) }, i);
			if (p.startsWith("`") && p.endsWith("`")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: p.slice(1, -1) }, i);
			if (p.startsWith("||") && p.endsWith("||")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spoiler, { text: p.slice(2, -2) }, i);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p }, i);
		})
	});
}
function Spoiler({ text }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: cn(!open && "rounded bg-fg/30 text-transparent"),
		onClick: () => setOpen(true),
		children: text
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VeltoApp, {});
}
//#endregion
export { reactMessage as A, listStoriesFeed as C, ownerStats as D, ownerModerate as E, updateProfile as F, viewStory as I, routes_CEz3U8qE_exports as L, sendStars as M, setTyping as N, pinChat as O, startCall as P, listNotifications as S, ownerCommand as T, listCatalog as _, buyPremium as a, listMessages as b, createDm as c, Home as component, deleteMessage as d, editMessage as f, heartbeat as g, globalSearch as h, buyGift as i, sendMessage as j, pinMessage as k, createGroup as l, getWallet as m, blockUser as n, claimDaily as o, getPublicProfile as p, bootstrapSession as r, convertGiftNft as s, addContact as t, createStory as u, listChats as v, markNotificationsRead as w, listMyInventory as x, listContacts as y };
