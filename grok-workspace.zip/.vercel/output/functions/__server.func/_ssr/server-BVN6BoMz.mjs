import { r as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { r as getSql } from "./db-D7VUei-2.mjs";
import { i as slugify, n as iso, r as num } from "./utils-CJQCePbV.mjs";
import { t as authMiddleware } from "./middleware-CKN9QaD2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-BVN6BoMz.js
var OWNER_ID_KEY = "OWNER_ID";
var GUIDE_ID = "sys-velto";
var OWNER_BOT_ID = "sys-owner-bot";
var NEWS_CHAT = "chat-velto-news";
var LOUNGE_CHAT = "chat-velto-lounge";
var buckets = /* @__PURE__ */ new Map();
function rateLimit(key, max = 40, windowMs = 1e4) {
	const now = Date.now();
	const cur = buckets.get(key);
	if (!cur || now - cur.t > windowMs) {
		buckets.set(key, {
			n: 1,
			t: now
		});
		return;
	}
	cur.n += 1;
	if (cur.n > max) throw new Error("Too many requests. Slow down.");
}
function newId(prefix = "vg") {
	return `${prefix}_${crypto.randomUUID().replace(/-/g, "").slice(0, 22)}`;
}
function asBool(v) {
	return v === true || v === "t" || v === "true";
}
function parseJson(v, fallback) {
	if (v && typeof v === "object") return v;
	if (typeof v === "string") try {
		return JSON.parse(v);
	} catch {
		return fallback;
	}
	return fallback;
}
function mapProfile(row, now = Date.now()) {
	const lastSeen = iso(row.last_seen);
	const lastMs = Date.parse(lastSeen);
	return {
		userId: String(row.user_id),
		username: String(row.username),
		firstName: String(row.first_name ?? ""),
		lastName: String(row.last_name ?? ""),
		phone: row.phone ? String(row.phone) : null,
		bio: String(row.bio ?? ""),
		avatarUrl: row.avatar_url ? String(row.avatar_url) : null,
		avatarFrame: String(row.avatar_frame ?? "none"),
		profileColor: String(row.profile_color ?? "#2DD4BF"),
		profileBg: String(row.profile_bg ?? "aurora"),
		nameStyle: String(row.name_style ?? "default"),
		emojiStatus: row.emoji_status ? String(row.emoji_status) : null,
		statusText: row.status_text ? String(row.status_text) : null,
		isBot: asBool(row.is_bot),
		isVerified: asBool(row.is_verified),
		isPremium: asBool(row.is_premium),
		premiumUntil: row.premium_until ? iso(row.premium_until) : null,
		isOwner: asBool(row.is_owner),
		accountLevel: num(row.account_level) || 1,
		xp: num(row.xp),
		lastSeen,
		isOnline: Number.isFinite(lastMs) ? now - lastMs < 45e3 : false,
		language: String(row.language ?? "en"),
		theme: row.theme || "dark",
		accent: row.accent || "teal",
		createdAt: iso(row.created_at)
	};
}
function displayName(p) {
	return `${p.firstName} ${p.lastName}`.trim() || p.username;
}
function mapGift(row) {
	return {
		id: String(row.id),
		name: String(row.name),
		description: String(row.description),
		imageKey: String(row.image_key),
		cost: num(row.cost),
		rarity: String(row.rarity),
		convertibleToNft: asBool(row.convertible_to_nft),
		premiumOnly: asBool(row.premium_only)
	};
}
function mapNft(row) {
	return {
		id: String(row.id),
		collectionId: String(row.collection_id),
		collectionName: String(row.collection_name ?? ""),
		name: String(row.name),
		description: String(row.description),
		imageKey: String(row.image_key),
		rarity: String(row.rarity),
		traits: parseJson(row.traits, {}),
		price: row.price == null ? null : num(row.price),
		ownerId: row.owner_id ? String(row.owner_id) : null
	};
}
function mapMessage(row, sender, reactions) {
	return {
		id: String(row.id),
		chatId: String(row.chat_id),
		senderId: String(row.sender_id),
		type: String(row.type),
		body: row.body ? String(row.body) : null,
		mediaUrl: row.media_url ? String(row.media_url) : null,
		mediaMeta: parseJson(row.media_meta, null),
		replyToId: row.reply_to_id ? String(row.reply_to_id) : null,
		forwardedFrom: row.forwarded_from ? String(row.forwarded_from) : null,
		isEdited: asBool(row.is_edited),
		isPinned: asBool(row.is_pinned),
		isSpoiler: asBool(row.is_spoiler),
		views: num(row.views),
		status: String(row.status ?? "sent"),
		createdAt: iso(row.created_at),
		sender,
		reactions
	};
}
async function readOwnerId(sql) {
	return (await sql`select value from app_settings where key = ${"OWNER_ID"}`)[0]?.value ?? null;
}
async function requireOwner(sql, userId) {
	const owner = await readOwnerId(sql);
	if (!owner || owner !== userId) throw new Error("Forbidden");
}
async function loadProfile(sql, userId) {
	const rows = await sql`select * from profiles where user_id = ${userId}`;
	return rows[0] ? mapProfile(rows[0]) : null;
}
async function uniqueUsername(sql, raw) {
	const base = slugify(raw);
	for (let i = 0; i < 30; i++) {
		const tryName = i === 0 ? base : `${base}${i + 1}`;
		if (!(await sql`select 1 from profiles where username = ${tryName} limit 1`).length) return tryName;
	}
	return `${base}_${newId("u").slice(-6)}`;
}
async function notify(sql, userId, type, title, body, data = {}) {
	if (userId.startsWith("sys-")) return;
	await sql`insert into notifications (id, user_id, type, title, body, data)
    values (${newId("nt")}, ${userId}, ${type}, ${title}, ${body}, ${JSON.stringify(data)}::jsonb)`;
}
async function grantAchievement(sql, userId, key) {
	await sql`insert into achievements (user_id, key) values (${userId}, ${key}) on conflict do nothing`;
}
async function addXp(sql, userId, amount) {
	await sql`update profiles set xp = xp + ${amount},
    account_level = greatest(1, least(99, 1 + ((xp + ${amount}) / 120)::int)),
    updated_at = now()
    where user_id = ${userId}`;
}
async function creditStars(sql, toUser, amount, kind, memo, idempotencyKey, fromUser = null) {
	if (amount <= 0) throw new Error("Invalid amount");
	const existing = await sql`select id from star_transactions where idempotency_key = ${idempotencyKey}`;
	if (existing.length) return {
		duplicate: true,
		id: String(existing[0].id)
	};
	const id = newId("vtx");
	await sql`insert into star_transactions (id, from_user, to_user, amount, kind, memo, idempotency_key)
    values (${id}, ${fromUser}, ${toUser}, ${amount}, ${kind}, ${memo}, ${idempotencyKey})`;
	await sql`insert into stars_wallets (user_id, balance) values (${toUser}, ${amount})
    on conflict (user_id) do update set balance = stars_wallets.balance + ${amount}, updated_at = now()`;
	return {
		duplicate: false,
		id
	};
}
async function debitStars(sql, fromUser, amount, kind, memo, idempotencyKey, toUser = null) {
	if (amount <= 0) throw new Error("Invalid amount");
	const existing = await sql`select id from star_transactions where idempotency_key = ${idempotencyKey}`;
	if (existing.length) return {
		duplicate: true,
		id: String(existing[0].id)
	};
	if (!(await sql`
    update stars_wallets set balance = balance - ${amount}, updated_at = now()
    where user_id = ${fromUser} and balance >= ${amount}
    returning balance`).length) throw new Error("Not enough Stars");
	const id = newId("vtx");
	await sql`insert into star_transactions (id, from_user, to_user, amount, kind, memo, idempotency_key)
    values (${id}, ${fromUser}, ${toUser}, ${amount}, ${kind}, ${memo}, ${idempotencyKey})`;
	if (toUser) await sql`insert into stars_wallets (user_id, balance) values (${toUser}, ${amount})
      on conflict (user_id) do update set balance = stars_wallets.balance + ${amount}, updated_at = now()`;
	return {
		duplicate: false,
		id
	};
}
async function requireMember(sql, chatId, userId) {
	const rows = await sql`
    select role, unread_count from chat_members where chat_id = ${chatId} and user_id = ${userId}`;
	if (!rows.length) throw new Error("Not a member");
	return rows[0];
}
async function findOrCreateDm(sql, a, b) {
	const [x, y] = a < b ? [a, b] : [b, a];
	const id = `dm_${x}_${y}`;
	if (!(await sql`select id from chats where id = ${id}`).length) {
		await sql`insert into chats (id, type, owner_id, is_public) values (${id}, ${(await loadProfile(sql, b))?.isBot ? "bot" : "dm"}, ${a}, false)`;
		await sql`insert into chat_members (chat_id, user_id, role) values (${id}, ${a}, 'member') on conflict do nothing`;
		await sql`insert into chat_members (chat_id, user_id, role) values (${id}, ${b}, 'member') on conflict do nothing`;
	} else {
		await sql`insert into chat_members (chat_id, user_id, role) values (${id}, ${a}, 'member') on conflict do nothing`;
		await sql`insert into chat_members (chat_id, user_id, role) values (${id}, ${b}, 'member') on conflict do nothing`;
	}
	return id;
}
function mapChatRow(row, peer, memberCount) {
	const type = String(row.type);
	const title = type === "dm" || type === "bot" ? peer ? displayName(peer) : "Chat" : String(row.title ?? "Chat");
	return {
		id: String(row.id),
		type,
		title,
		username: row.username ? String(row.username) : peer?.username ?? null,
		description: row.description ? String(row.description) : null,
		avatarUrl: row.avatar_url ? String(row.avatar_url) : peer?.avatarUrl ?? null,
		isPublic: asBool(row.is_public),
		role: String(row.role ?? "member"),
		pinned: asBool(row.pinned),
		muted: asBool(row.muted),
		unread: num(row.unread_count),
		lastText: row.last_text ? String(row.last_text) : null,
		lastType: row.last_type ? String(row.last_type) : null,
		lastAt: row.last_at ? iso(row.last_at) : null,
		lastSenderId: row.last_sender_id ? String(row.last_sender_id) : null,
		peer,
		memberCount,
		isOwnerBot: type === "bot" && String(row.id).includes("sys-owner-bot")
	};
}
function validateMedia(dataUrl, max = 7e5) {
	if (!dataUrl) return null;
	if (dataUrl.length > max) throw new Error("File too large");
	if (!dataUrl.startsWith("data:")) throw new Error("Invalid file");
	const mime = dataUrl.slice(5, dataUrl.indexOf(";"));
	if (![
		"image/jpeg",
		"image/png",
		"image/webp",
		"image/gif",
		"audio/webm",
		"audio/mp4",
		"audio/ogg",
		"video/mp4",
		"video/webm",
		"application/pdf",
		"text/plain"
	].includes(mime)) throw new Error("File type not allowed");
	return dataUrl;
}
function asUser(ctx) {
	return ctx.userId;
}
var bootstrapSession_createServerFn_handler = createServerRpc({
	id: "776dfa5c7387785fa70f6138ff58f12e1c740dbed2bf630a9d0424b54a077ee2",
	name: "bootstrapSession",
	filename: "src/lib/velto/server.ts"
}, (opts) => bootstrapSession.__executeServer(opts));
var bootstrapSession = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(bootstrapSession_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const userId = asUser(context);
	rateLimit(`boot:${userId}`, 20, 1e4);
	let profile = await loadProfile(sql, userId);
	if (!profile) {
		const isFirst = !await readOwnerId(sql);
		await sql`insert into profiles (user_id, username, first_name, is_owner, is_verified)
        values (${userId}, ${await uniqueUsername(sql, `velto_${userId.slice(-6)}`)}, ${"Traveler"}, ${isFirst}, ${isFirst})`;
		if (isFirst) await sql`insert into app_settings (key, value) values (${OWNER_ID_KEY}, ${userId})
          on conflict (key) do nothing`;
		await sql`insert into stars_wallets (user_id, balance) values (${userId}, 0) on conflict do nothing`;
		await creditStars(sql, userId, 80, "grant", "Welcome bonus", `welcome:${userId}`);
		await grantAchievement(sql, userId, "joined");
		profile = await loadProfile(sql, userId);
	}
	const isOwner = await readOwnerId(sql) === userId;
	if (profile && profile.isOwner !== isOwner) {
		await sql`update profiles set is_owner = ${isOwner} where user_id = ${userId}`;
		profile = {
			...profile,
			isOwner
		};
	}
	await sql`insert into chat_members (chat_id, user_id, role)
      values (${NEWS_CHAT}, ${userId}, ${"subscriber"}) on conflict do nothing`;
	await sql`insert into chat_members (chat_id, user_id, role)
      values (${LOUNGE_CHAT}, ${userId}, ${"member"}) on conflict do nothing`;
	const guideChat = await findOrCreateDm(sql, userId, GUIDE_ID);
	if (!(await sql`select 1 from messages where chat_id = ${guideChat} limit 1`).length) await sql`insert into messages (id, chat_id, sender_id, type, body, status)
        values (${newId("msg")}, ${guideChat}, ${GUIDE_ID}, ${"text"},
        ${"Welcome to VeltoGram. Chats, Stories, Stars, gifts, and NFTs live here. Open Contacts to find people, or send a gift from the Stars tab."}, ${"read"})`;
	if (isOwner) {
		const botChat = await findOrCreateDm(sql, userId, OWNER_BOT_ID);
		if (!(await sql`select 1 from messages where chat_id = ${botChat} limit 1`).length) await sql`insert into messages (id, chat_id, sender_id, type, body, status)
          values (${newId("msg")}, ${botChat}, ${OWNER_BOT_ID}, ${"text"},
          ${"Owner Bot online. Restricted to OWNER_ID. Try /help"}, ${"read"})`;
	}
	await sql`update profiles set last_seen = now(), updated_at = now() where user_id = ${userId}`;
	profile = await loadProfile(sql, userId);
	const walletRows = await sql`select balance from stars_wallets where user_id = ${userId}`;
	const claimed = await sql`select 1 from daily_bonuses where user_id = ${userId} and day = ${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}::date`;
	return {
		profile,
		isOwner,
		wallet: {
			balance: num(walletRows[0]?.balance),
			dailyClaimed: claimed.length > 0
		},
		needsOnboarding: profile.firstName === "Traveler" || profile.username.startsWith("velto_")
	};
});
var heartbeat_createServerFn_handler = createServerRpc({
	id: "f31dcdd355b699aa12d270df5a65dd32bf1599f2d1ed5f581ee19b13a50c50ed",
	name: "heartbeat",
	filename: "src/lib/velto/server.ts"
}, (opts) => heartbeat.__executeServer(opts));
var heartbeat = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(heartbeat_createServerFn_handler, async ({ context }) => {
	await (await getSql())`update profiles set last_seen = now() where user_id = ${context.userId}`;
	return { ok: true };
});
var updateProfile_createServerFn_handler = createServerRpc({
	id: "c27e58038eae7b6192a606724aadcf0b606d78636816bd022ce95b40356b56cb",
	name: "updateProfile",
	filename: "src/lib/velto/server.ts"
}, (opts) => updateProfile.__executeServer(opts));
var updateProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(updateProfile_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const userId = context.userId;
	rateLimit(`prof:${userId}`, 20, 1e4);
	const cur = await loadProfile(sql, userId);
	if (!cur) throw new Error("No profile");
	let username = cur.username;
	if (typeof data.username === "string") {
		const next = data.username.trim().toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 24);
		if (next.length < 3) throw new Error("Username too short");
		if (next !== cur.username) {
			if ((await sql`select 1 from profiles where username = ${next} and user_id <> ${userId}`).length) throw new Error("Username is taken");
			username = next;
		}
	}
	const firstName = typeof data.firstName === "string" ? data.firstName.trim().slice(0, 40) : cur.firstName;
	const lastName = typeof data.lastName === "string" ? data.lastName.trim().slice(0, 40) : cur.lastName;
	const bio = typeof data.bio === "string" ? data.bio.trim().slice(0, 180) : cur.bio;
	const phone = typeof data.phone === "string" ? data.phone.trim().slice(0, 24) : cur.phone;
	const avatarUrl = typeof data.avatarUrl === "string" ? validateMedia(data.avatarUrl, 5e5) : cur.avatarUrl;
	const avatarFrame = typeof data.avatarFrame === "string" ? data.avatarFrame : cur.avatarFrame;
	const profileColor = typeof data.profileColor === "string" ? data.profileColor : cur.profileColor;
	const profileBg = typeof data.profileBg === "string" ? data.profileBg : cur.profileBg;
	const nameStyle = typeof data.nameStyle === "string" ? data.nameStyle : cur.nameStyle;
	const emojiStatus = typeof data.emojiStatus === "string" ? data.emojiStatus.slice(0, 8) : cur.emojiStatus;
	const statusText = typeof data.statusText === "string" ? data.statusText.slice(0, 40) : cur.statusText;
	const language = typeof data.language === "string" ? data.language : cur.language;
	const theme = typeof data.theme === "string" ? data.theme : cur.theme;
	const accent = typeof data.accent === "string" ? data.accent : cur.accent;
	await sql`update profiles set
      username = ${username}, first_name = ${firstName}, last_name = ${lastName}, bio = ${bio},
      phone = ${phone}, avatar_url = ${avatarUrl}, avatar_frame = ${avatarFrame},
      profile_color = ${profileColor}, profile_bg = ${profileBg}, name_style = ${nameStyle},
      emoji_status = ${emojiStatus}, status_text = ${statusText}, language = ${language},
      theme = ${theme}, accent = ${accent}, updated_at = now()
      where user_id = ${userId}`;
	return loadProfile(sql, userId);
});
var getPublicProfile_createServerFn_handler = createServerRpc({
	id: "b29933b08bc9b62bbd35e1db12bfbbf33a286df9b2af0d8c829cac5d61a16d74",
	name: "getPublicProfile",
	filename: "src/lib/velto/server.ts"
}, (opts) => getPublicProfile.__executeServer(opts));
var getPublicProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(getPublicProfile_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const rows = data.userId ? await sql`select * from profiles where user_id = ${data.userId}` : await sql`select * from profiles where username = ${data.username ?? ""}`;
	if (!rows[0]) throw new Error("User not found");
	const profile = mapProfile(rows[0]);
	if ((await sql`select 1 from blocks where user_id = ${profile.userId} and blocked_id = ${context.userId}`).length) throw new Error("User not found");
	const gifts = await sql`
      select ug.*, g.name, g.description, g.image_key, g.cost, g.rarity, g.convertible_to_nft, g.premium_only, g.id as gift_def_id
      from user_gifts ug join gifts g on g.id = ug.gift_id
      where ug.owner_id = ${profile.userId} and ug.displayed = true
      order by ug.created_at desc limit 24`;
	const nfts = await sql`
      select n.*, c.name as collection_name, o.owner_id
      from nft_ownership o join nfts n on n.id = o.nft_id
      join nft_collections c on c.id = n.collection_id
      where o.owner_id = ${profile.userId}`;
	const isContact = await sql`select 1 from contacts where user_id = ${context.userId} and contact_id = ${profile.userId}`;
	return {
		profile,
		gifts: gifts.map((r) => ({
			id: String(r.id),
			gift: mapGift({
				...r,
				id: r.gift_def_id
			}),
			fromId: r.from_id ? String(r.from_id) : null,
			displayed: true,
			createdAt: iso(r.created_at)
		})),
		nfts: nfts.map(mapNft),
		isContact: isContact.length > 0,
		isMe: profile.userId === context.userId
	};
});
var listChats_createServerFn_handler = createServerRpc({
	id: "ca634e8dc4b0b23f2716f10efd6e4e057c80809e65e2278f0221d3550fe551fb",
	name: "listChats",
	filename: "src/lib/velto/server.ts"
}, (opts) => listChats.__executeServer(opts));
var listChats = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listChats_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const ownerId = await readOwnerId(sql);
	const rows = await sql`
      select c.*, cm.role, cm.pinned, cm.muted, cm.unread_count,
        m.body as last_text, m.type as last_type, m.created_at as last_at, m.sender_id as last_sender_id
      from chat_members cm
      join chats c on c.id = cm.chat_id
      left join lateral (
        select body, type, created_at, sender_id from messages
        where chat_id = c.id and (scheduled_at is null or scheduled_at <= now())
        order by created_at desc limit 1
      ) m on true
      where cm.user_id = ${context.userId}
      order by cm.pinned desc, coalesce(m.created_at, c.created_at) desc`;
	const out = [];
	for (const row of rows) {
		const type = String(row.type);
		if (type === "bot" && String(row.id).includes("sys-owner-bot") && ownerId !== context.userId) continue;
		let peer = null;
		if (type === "dm" || type === "bot") {
			const other = (await sql`select user_id from chat_members where chat_id = ${String(row.id)}`).find((m) => m.user_id !== context.userId)?.user_id;
			if (other) peer = await loadProfile(sql, other);
		}
		const countRows = await sql`select count(*)::int as n from chat_members where chat_id = ${String(row.id)}`;
		out.push(mapChatRow(row, peer, num(countRows[0]?.n)));
	}
	return out;
});
var getChat_createServerFn_handler = createServerRpc({
	id: "e73f73617fc03127ea42d07d9fe4f60abc810ab2ccce0e37b02e201a2767d25a",
	name: "getChat",
	filename: "src/lib/velto/server.ts"
}, (opts) => getChat.__executeServer(opts));
var getChat = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(getChat_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await requireMember(sql, data.chatId, context.userId);
	const rows = await sql`select * from chats where id = ${data.chatId}`;
	if (!rows[0]) throw new Error("Chat not found");
	const members = await sql`
      select user_id, role from chat_members where chat_id = ${data.chatId}`;
	const profiles = [];
	for (const m of members) {
		const p = await loadProfile(sql, m.user_id);
		if (p) profiles.push(p);
	}
	const pinned = await sql`
      select * from messages where chat_id = ${data.chatId} and is_pinned = true order by created_at desc limit 8`;
	return {
		chat: rows[0],
		members: profiles.map((p) => ({
			...p,
			role: members.find((m) => m.user_id === p.userId)?.role ?? "member"
		})),
		pinned: pinned.map((r) => mapMessage(r, null, []))
	};
});
async function attachReactions(sql, msgs, me) {
	if (!msgs.length) return [];
	const ids = msgs.map((m) => String(m.id));
	const placeholders = ids.map((_, i) => `$${i + 1}`).join(",");
	const reacts = await sql.query(`select message_id, emoji, user_id from message_reactions where message_id in (${placeholders})`, ids);
	const byMsg = /* @__PURE__ */ new Map();
	for (const r of reacts) {
		const list = byMsg.get(r.message_id) ?? [];
		const existing = list.find((x) => x.emoji === r.emoji);
		if (existing) {
			existing.count += 1;
			existing.mine = existing.mine || r.user_id === me;
		} else list.push({
			emoji: r.emoji,
			count: 1,
			mine: r.user_id === me
		});
		byMsg.set(r.message_id, list);
	}
	const senders = /* @__PURE__ */ new Map();
	const out = [];
	for (const row of msgs) {
		const sid = String(row.sender_id);
		if (!senders.has(sid)) {
			const p = await loadProfile(sql, sid);
			if (p) senders.set(sid, p);
		}
		out.push(mapMessage(row, senders.get(sid) ?? null, byMsg.get(String(row.id)) ?? []));
	}
	return out;
}
var listMessages_createServerFn_handler = createServerRpc({
	id: "d581c073bb25d3af3c50a8a16651a948c58d0422ed467234e214335a5dae369a",
	name: "listMessages",
	filename: "src/lib/velto/server.ts"
}, (opts) => listMessages.__executeServer(opts));
var listMessages = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(listMessages_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await requireMember(sql, data.chatId, context.userId);
	const rows = data.before ? await sql`
          select * from messages where chat_id = ${data.chatId}
            and created_at < ${data.before}::timestamptz
            and (scheduled_at is null or scheduled_at <= now() or sender_id = ${context.userId})
          order by created_at desc limit 40` : await sql`
          select * from messages where chat_id = ${data.chatId}
            and (scheduled_at is null or scheduled_at <= now() or sender_id = ${context.userId})
          order by created_at desc limit 40`;
	await sql`update chat_members set unread_count = 0, last_read_at = now()
      where chat_id = ${data.chatId} and user_id = ${context.userId}`;
	await sql`update messages set status = 'read'
      where chat_id = ${data.chatId} and sender_id <> ${context.userId} and status <> 'read'`;
	if ((await sql`select type from chats where id = ${data.chatId}`)[0]?.type === "channel") {
		const ids = rows.map((r) => String(r.id));
		if (ids.length) await sql.query(`update messages set views = views + 1 where id in (${ids.map((_, i) => `$${i + 1}`).join(",")})`, ids);
	}
	const messages = (await attachReactions(sql, rows, context.userId)).reverse();
	const typing = await sql`
      select user_id from typing where chat_id = ${data.chatId}
        and user_id <> ${context.userId} and updated_at > now() - interval '4 seconds'`;
	const typingProfiles = [];
	for (const t of typing) {
		const p = await loadProfile(sql, t.user_id);
		if (p) typingProfiles.push(p);
	}
	return {
		messages,
		typing: typingProfiles
	};
});
async function runOwnerCommand(sql, userId, text) {
	await requireOwner(sql, userId);
	const parts = text.trim().split(/\s+/);
	const cmd = (parts[0] ?? "").toLowerCase();
	const arg = parts.slice(1).join(" ");
	await sql`insert into owner_actions (id, actor_id, command, payload)
    values (${newId("oa")}, ${userId}, ${cmd}, ${JSON.stringify({ arg })}::jsonb)`;
	if (cmd === "/help") return "Commands:\n/stars N\n/gift common|rare|epic|legendary|mythic\n/nft random\n/premium\n/balance\n/inventory\n/stats";
	if (cmd === "/stars") {
		const n = Math.max(1, Math.min(1e6, Number(arg) || 0));
		await creditStars(sql, userId, n, "owner", "Owner Bot grant", newId("idm"), OWNER_BOT_ID);
		return `Granted ${n} Stars.`;
	}
	if (cmd === "/gift") {
		const rarity = (arg || "rare").toLowerCase();
		const gift = await sql`select * from gifts where rarity = ${rarity} order by random() limit 1`;
		if (!gift[0]) return "No gift of that rarity.";
		await sql`insert into user_gifts (id, gift_id, owner_id, from_id) values (${newId("ug")}, ${String(gift[0].id)}, ${userId}, ${OWNER_BOT_ID})`;
		return `Granted ${String(gift[0].name)} (${rarity}).`;
	}
	if (cmd === "/nft") {
		const free = await sql`
      select n.* from nfts n left join nft_ownership o on o.nft_id = n.id
      where o.nft_id is null order by random() limit 1`;
		if (!free[0]) return "No unowned NFT left in the catalog.";
		const nftId = String(free[0].id);
		await sql`insert into nft_ownership (nft_id, owner_id) values (${nftId}, ${userId})`;
		await sql`insert into nft_history (id, nft_id, from_id, to_id) values (${newId("nh")}, ${nftId}, ${OWNER_BOT_ID}, ${userId})`;
		return `Transferred ${String(free[0].name)} (${nftId}).`;
	}
	if (cmd === "/premium") {
		await sql`update profiles set is_premium = true, premium_until = now() + interval '30 days' where user_id = ${userId}`;
		return "Velto Premium activated for 30 days.";
	}
	if (cmd === "/balance") {
		const w = await sql`select balance from stars_wallets where user_id = ${userId}`;
		return `Balance: ${num(w[0]?.balance)} Stars.`;
	}
	if (cmd === "/inventory") {
		const g = await sql`select count(*)::int as n from user_gifts where owner_id = ${userId}`;
		const n = await sql`select count(*)::int as n from nft_ownership where owner_id = ${userId}`;
		return `Gifts: ${num(g[0]?.n)} · NFT: ${num(n[0]?.n)}`;
	}
	if (cmd === "/stats") {
		const users = await sql`select count(*)::int as n from profiles where is_bot = false`;
		const msgs = await sql`select count(*)::int as n from messages`;
		const stars = await sql`select coalesce(sum(balance),0) as n from stars_wallets`;
		return `Users ${num(users[0]?.n)} · Messages ${num(msgs[0]?.n)} · Stars in wallets ${num(stars[0]?.n)}`;
	}
	return "Unknown command. /help";
}
var sendMessage_createServerFn_handler = createServerRpc({
	id: "09403bee605f58b7c0670bcd4cf21fa3d8acaadb0289f80322c4b9ef11a8e1a5",
	name: "sendMessage",
	filename: "src/lib/velto/server.ts"
}, (opts) => sendMessage.__executeServer(opts));
var sendMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(sendMessage_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const userId = context.userId;
	rateLimit(`msg:${userId}`, 50, 1e4);
	const member = await requireMember(sql, data.chatId, userId);
	const chat = (await sql`select type, owner_id from chats where id = ${data.chatId}`)[0];
	if (!chat) throw new Error("Chat not found");
	if (chat.type === "channel" && member.role !== "owner" && member.role !== "admin") throw new Error("Only admins can post in this channel");
	const mediaUrl = validateMedia(data.mediaUrl ?? null);
	const body = (data.body ?? "").slice(0, 4e3);
	const type = data.type ?? (mediaUrl ? "photo" : "text");
	if (!body && !mediaUrl && type === "text") throw new Error("Empty message");
	if (chat.type === "bot" && data.chatId.includes("sys-owner-bot") && body.startsWith("/")) {
		await requireOwner(sql, userId);
		const id = newId("msg");
		await sql`insert into messages (id, chat_id, sender_id, type, body, status)
        values (${id}, ${data.chatId}, ${userId}, ${"text"}, ${body}, ${"read"})`;
		const reply = await runOwnerCommand(sql, userId, body);
		await sql`insert into messages (id, chat_id, sender_id, type, body, status)
        values (${newId("msg")}, ${data.chatId}, ${OWNER_BOT_ID}, ${"text"}, ${reply}, ${"read"})`;
		return {
			ok: true,
			id
		};
	}
	const id = newId("msg");
	const expires = data.expiresInSec ? new Date(Date.now() + data.expiresInSec * 1e3).toISOString() : null;
	await sql`insert into messages (id, chat_id, sender_id, type, body, media_url, media_meta, reply_to_id, is_spoiler, scheduled_at, expires_at, status)
      values (${id}, ${data.chatId}, ${userId}, ${type}, ${body || null}, ${mediaUrl},
        ${JSON.stringify(data.mediaMeta ?? {})}::jsonb, ${data.replyToId ?? null}, ${Boolean(data.spoiler)},
        ${data.scheduledAt ?? null}, ${expires}, ${"sent"})`;
	if (type === "poll" && data.mediaMeta) await sql`insert into polls (id, message_id, question, options, quiz, correct_index)
        values (${newId("poll")}, ${id}, ${String(data.mediaMeta.question ?? "")},
          ${JSON.stringify(data.mediaMeta.options ?? [])}::jsonb, ${Boolean(data.mediaMeta.quiz)},
          ${typeof data.mediaMeta.correctIndex === "number" ? data.mediaMeta.correctIndex : null})`;
	await sql`update chat_members set unread_count = unread_count + 1
      where chat_id = ${data.chatId} and user_id <> ${userId}`;
	await addXp(sql, userId, 1);
	const others = await sql`select user_id from chat_members where chat_id = ${data.chatId} and user_id <> ${userId}`;
	const me = await loadProfile(sql, userId);
	for (const o of others) {
		if (o.user_id.startsWith("sys-")) continue;
		await notify(sql, o.user_id, "message", displayName(me), body || type, { chatId: data.chatId });
	}
	return {
		ok: true,
		id
	};
});
var editMessage_createServerFn_handler = createServerRpc({
	id: "52da37d9556e77bf94b0984d39e4d244d68d8ae34c1e08ffdd400ca754591745",
	name: "editMessage",
	filename: "src/lib/velto/server.ts"
}, (opts) => editMessage.__executeServer(opts));
var editMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(editMessage_createServerFn_handler, async ({ context, data }) => {
	if (!(await (await getSql())`update messages set body = ${data.body.slice(0, 4e3)}, is_edited = true, edited_at = now()
      where id = ${data.id} and sender_id = ${context.userId} returning id`).length) throw new Error("Cannot edit");
	return { ok: true };
});
var deleteMessage_createServerFn_handler = createServerRpc({
	id: "e163921ac0e1a1c43b449a17541e71046a6fbba6bc31183cb19f631d4c33c5cd",
	name: "deleteMessage",
	filename: "src/lib/velto/server.ts"
}, (opts) => deleteMessage.__executeServer(opts));
var deleteMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(deleteMessage_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const member = await requireMember(sql, data.chatId, context.userId);
	if (member.role === "owner" || member.role === "admin") await sql`delete from messages where id = ${data.id} and chat_id = ${data.chatId}`;
	else await sql`delete from messages where id = ${data.id} and chat_id = ${data.chatId} and sender_id = ${context.userId}`;
	return { ok: true };
});
var reactMessage_createServerFn_handler = createServerRpc({
	id: "10a35fa3df8e9c69c4d0fad0ec6082683040ac953132199f801dc24e374ac0c0",
	name: "reactMessage",
	filename: "src/lib/velto/server.ts"
}, (opts) => reactMessage.__executeServer(opts));
var reactMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(reactMessage_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const emoji = data.emoji.slice(0, 8);
	if ((await sql`
      select emoji from message_reactions where message_id = ${data.id} and user_id = ${context.userId}`)[0]?.emoji === emoji) await sql`delete from message_reactions where message_id = ${data.id} and user_id = ${context.userId}`;
	else {
		await sql`delete from message_reactions where message_id = ${data.id} and user_id = ${context.userId}`;
		await sql`insert into message_reactions (message_id, user_id, emoji) values (${data.id}, ${context.userId}, ${emoji})`;
	}
	return { ok: true };
});
var pinMessage_createServerFn_handler = createServerRpc({
	id: "b068800439788125096d9ede2806b10e48ff6f15a3a228344ce420fcb4a2c27b",
	name: "pinMessage",
	filename: "src/lib/velto/server.ts"
}, (opts) => pinMessage.__executeServer(opts));
var pinMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(pinMessage_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const member = await requireMember(sql, data.chatId, context.userId);
	if (member.role !== "owner" && member.role !== "admin" && member.role !== "member") throw new Error("Cannot pin");
	await sql`update messages set is_pinned = ${data.pinned} where id = ${data.id} and chat_id = ${data.chatId}`;
	return { ok: true };
});
var setTyping_createServerFn_handler = createServerRpc({
	id: "e8d7339c846af0d1c12b86497daced3a831bf18ef9b0863ba7378116120afb5f",
	name: "setTyping",
	filename: "src/lib/velto/server.ts"
}, (opts) => setTyping.__executeServer(opts));
var setTyping = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(setTyping_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`insert into typing (chat_id, user_id, updated_at) values (${data.chatId}, ${context.userId}, now())
      on conflict (chat_id, user_id) do update set updated_at = now()`;
	return { ok: true };
});
var createDm_createServerFn_handler = createServerRpc({
	id: "a29d75febdf6d472d77d809a4dafa1d4567a9c8b8fb9a713deec8cd5c3592c3c",
	name: "createDm",
	filename: "src/lib/velto/server.ts"
}, (opts) => createDm.__executeServer(opts));
var createDm = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createDm_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (data.userId === context.userId) throw new Error("Cannot chat with yourself");
	if (data.userId === "sys-owner-bot") await requireOwner(sql, context.userId);
	if ((await sql`select 1 from blocks where (user_id = ${data.userId} and blocked_id = ${context.userId})
      or (user_id = ${context.userId} and blocked_id = ${data.userId})`).length) throw new Error("Unavailable");
	const id = await findOrCreateDm(sql, context.userId, data.userId);
	await sql`insert into contacts (user_id, contact_id) values (${context.userId}, ${data.userId}) on conflict do nothing`;
	return { chatId: id };
});
var createGroup_createServerFn_handler = createServerRpc({
	id: "49489a7869597041179918643538a0f4bde8f985acfc3478cf90451231067bb3",
	name: "createGroup",
	filename: "src/lib/velto/server.ts"
}, (opts) => createGroup.__executeServer(opts));
var createGroup = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createGroup_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const title = data.title.trim().slice(0, 60);
	if (title.length < 2) throw new Error("Name required");
	const id = newId("chat");
	const type = data.isChannel ? "channel" : "group";
	let username = null;
	if (data.username) {
		username = data.username.toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 24);
		if ((await sql`select 1 from chats where username = ${username}`).length) throw new Error("Username taken");
	}
	await sql`insert into chats (id, type, title, username, description, owner_id, is_public, invite_code)
      values (${id}, ${type}, ${title}, ${username}, ${(data.description ?? "").slice(0, 300)},
        ${context.userId}, ${data.isPublic !== false}, ${newId("inv").slice(-10)})`;
	await sql`insert into chat_members (chat_id, user_id, role) values (${id}, ${context.userId}, ${"owner"})`;
	for (const mid of data.memberIds ?? []) {
		if (mid === context.userId) continue;
		await sql`insert into chat_members (chat_id, user_id, role) values (${id}, ${mid}, ${data.isChannel ? "subscriber" : "member"}) on conflict do nothing`;
		await notify(sql, mid, "invite", title, `You were added to ${title}`, { chatId: id });
	}
	await sql`insert into messages (id, chat_id, sender_id, type, body, status)
      values (${newId("msg")}, ${id}, ${context.userId}, ${"system"}, ${`${title} created`}, ${"read"})`;
	return { chatId: id };
});
var updateChat_createServerFn_handler = createServerRpc({
	id: "d6b9a26dcc727fbecef678a264f89c90c2305c68903ae39b0457affec888c3c7",
	name: "updateChat",
	filename: "src/lib/velto/server.ts"
}, (opts) => updateChat.__executeServer(opts));
var updateChat = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(updateChat_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const member = await requireMember(sql, data.chatId, context.userId);
	if (member.role !== "owner" && member.role !== "admin") throw new Error("Forbidden");
	const avatar = typeof data.avatarUrl === "string" ? validateMedia(data.avatarUrl, 4e5) : void 0;
	await sql`update chats set
      title = coalesce(${data.title ?? null}, title),
      description = coalesce(${data.description ?? null}, description),
      is_public = coalesce(${data.isPublic ?? null}, is_public),
      avatar_url = coalesce(${avatar ?? null}, avatar_url)
      where id = ${data.chatId}`;
	return { ok: true };
});
var setMemberRole_createServerFn_handler = createServerRpc({
	id: "b1c195fa86eb69323503a925377af134ec126f5ca7f4d34ea0af478b40269409",
	name: "setMemberRole",
	filename: "src/lib/velto/server.ts"
}, (opts) => setMemberRole.__executeServer(opts));
var setMemberRole = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(setMemberRole_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const me = await requireMember(sql, data.chatId, context.userId);
	if (me.role !== "owner" && me.role !== "admin") throw new Error("Forbidden");
	if (data.role === "owner") throw new Error("Cannot transfer this way");
	await sql`update chat_members set role = ${data.role} where chat_id = ${data.chatId} and user_id = ${data.userId}`;
	return { ok: true };
});
var kickMember_createServerFn_handler = createServerRpc({
	id: "56d6f1341883c96556a34e04bc959da6bc79c1401da0ffb3aa0bfe581149d704",
	name: "kickMember",
	filename: "src/lib/velto/server.ts"
}, (opts) => kickMember.__executeServer(opts));
var kickMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(kickMember_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const me = await requireMember(sql, data.chatId, context.userId);
	if (me.role !== "owner" && me.role !== "admin") throw new Error("Forbidden");
	await sql`delete from chat_members where chat_id = ${data.chatId} and user_id = ${data.userId} and role <> 'owner'`;
	return { ok: true };
});
var pinChat_createServerFn_handler = createServerRpc({
	id: "ddde220917780ae2645652449dd449a7e0ff648b2c1abc27c9214df023125cbe",
	name: "pinChat",
	filename: "src/lib/velto/server.ts"
}, (opts) => pinChat.__executeServer(opts));
var pinChat = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(pinChat_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`update chat_members set pinned = ${data.pinned} where chat_id = ${data.chatId} and user_id = ${context.userId}`;
	return { ok: true };
});
var muteChat_createServerFn_handler = createServerRpc({
	id: "dbca90505ee01ac70caa4004d449b82f8b0e1d1fc70c547cac497689573c4f6f",
	name: "muteChat",
	filename: "src/lib/velto/server.ts"
}, (opts) => muteChat.__executeServer(opts));
var muteChat = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(muteChat_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`update chat_members set muted = ${data.muted} where chat_id = ${data.chatId} and user_id = ${context.userId}`;
	return { ok: true };
});
var markUnread_createServerFn_handler = createServerRpc({
	id: "94a2c49e852beb03f8e4b42c7849d54ed070c9ac06f82d809fe35b9cd4f639d8",
	name: "markUnread",
	filename: "src/lib/velto/server.ts"
}, (opts) => markUnread.__executeServer(opts));
var markUnread = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(markUnread_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`update chat_members set unread_count = greatest(unread_count, 1)
      where chat_id = ${data.chatId} and user_id = ${context.userId}`;
	return { ok: true };
});
var deleteHistory_createServerFn_handler = createServerRpc({
	id: "c121524adf391bca3660cdf8a232ea10b5dc0cd6192edbc9fc4b7633bf0c7b1b",
	name: "deleteHistory",
	filename: "src/lib/velto/server.ts"
}, (opts) => deleteHistory.__executeServer(opts));
var deleteHistory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(deleteHistory_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if ((await requireMember(sql, data.chatId, context.userId)).role === "owner") await sql`delete from messages where chat_id = ${data.chatId}`;
	else await sql`delete from messages where chat_id = ${data.chatId} and sender_id = ${context.userId}`;
	return { ok: true };
});
var joinByUsername_createServerFn_handler = createServerRpc({
	id: "b939d4d09b3f01997722c2d6fa2c1ff2b7c9eab96f962c8462bc02697322a722",
	name: "joinByUsername",
	filename: "src/lib/velto/server.ts"
}, (opts) => joinByUsername.__executeServer(opts));
var joinByUsername = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(joinByUsername_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const chat = await sql`
      select id, type, is_public from chats where username = ${data.username.replace(/^@/, "")}`;
	if (!chat[0] || !chat[0].is_public) throw new Error("Not found");
	const role = chat[0].type === "channel" ? "subscriber" : "member";
	await sql`insert into chat_members (chat_id, user_id, role) values (${chat[0].id}, ${context.userId}, ${role}) on conflict do nothing`;
	return { chatId: chat[0].id };
});
var globalSearch_createServerFn_handler = createServerRpc({
	id: "3c0495a616c93a2415c95cf1966f61b9b0b2f2352d9901c4658eeb2b1640dee4",
	name: "globalSearch",
	filename: "src/lib/velto/server.ts"
}, (opts) => globalSearch.__executeServer(opts));
var globalSearch = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(globalSearch_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const q = `%${data.q.trim().slice(0, 40)}%`;
	if (data.q.trim().length < 1) return {
		users: [],
		chats: [],
		gifts: [],
		nfts: [],
		messages: []
	};
	const users = await sql`
      select * from profiles
      where (username ilike ${q} or first_name ilike ${q} or last_name ilike ${q})
        and user_id <> ${context.userId}
      order by is_verified desc, username asc limit 12`;
	const chats = await sql`
      select * from chats where is_public = true and (title ilike ${q} or username ilike ${q}) limit 8`;
	const gifts = await sql`select * from gifts where name ilike ${q} limit 8`;
	const nfts = await sql`
      select n.*, c.name as collection_name, o.owner_id from nfts n
      join nft_collections c on c.id = n.collection_id
      left join nft_ownership o on o.nft_id = n.id
      where n.name ilike ${q} or n.id ilike ${q} limit 8`;
	const messages = await sql`
      select m.id, m.body, m.chat_id, m.created_at from messages m
      join chat_members cm on cm.chat_id = m.chat_id and cm.user_id = ${context.userId}
      where m.body ilike ${q} order by m.created_at desc limit 8`;
	return {
		users: users.map((r) => mapProfile(r)),
		chats,
		gifts: gifts.map(mapGift),
		nfts: nfts.map(mapNft),
		messages: messages.map((m) => ({
			id: String(m.id),
			body: String(m.body ?? ""),
			chatId: String(m.chat_id),
			createdAt: iso(m.created_at)
		}))
	};
});
var listContacts_createServerFn_handler = createServerRpc({
	id: "c1549bcd768bd92f92a2bc0ae436226a35e4275c9a1fa7f8612db1301fe98cc7",
	name: "listContacts",
	filename: "src/lib/velto/server.ts"
}, (opts) => listContacts.__executeServer(opts));
var listContacts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listContacts_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const rows = await sql`select contact_id from contacts where user_id = ${context.userId}`;
	const people = [];
	for (const r of rows) {
		const p = await loadProfile(sql, r.contact_id);
		if (p) people.push(p);
	}
	return {
		contacts: people,
		suggested: (await sql`
      select * from profiles
      where is_bot = false and user_id <> ${context.userId}
        and user_id not in (select contact_id from contacts where user_id = ${context.userId})
      order by last_seen desc limit 8`).map((r) => mapProfile(r))
	};
});
var addContact_createServerFn_handler = createServerRpc({
	id: "b378161b555f137bd33653c0dd3f0919c22d956afc95fa27c62744fb86666bf5",
	name: "addContact",
	filename: "src/lib/velto/server.ts"
}, (opts) => addContact.__executeServer(opts));
var addContact = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(addContact_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`insert into contacts (user_id, contact_id) values (${context.userId}, ${data.userId}) on conflict do nothing`;
	return { ok: true };
});
var blockUser_createServerFn_handler = createServerRpc({
	id: "7e744e614b87f3a206d7bb4f36cfdb60282e1daa52898ad5e1235ee056b46c35",
	name: "blockUser",
	filename: "src/lib/velto/server.ts"
}, (opts) => blockUser.__executeServer(opts));
var blockUser = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(blockUser_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (data.block) {
		await sql`insert into blocks (user_id, blocked_id) values (${context.userId}, ${data.userId}) on conflict do nothing`;
		await sql`delete from contacts where user_id = ${context.userId} and contact_id = ${data.userId}`;
	} else await sql`delete from blocks where user_id = ${context.userId} and blocked_id = ${data.userId}`;
	return { ok: true };
});
var listStoriesFeed_createServerFn_handler = createServerRpc({
	id: "bf0533bda0585df46fbacac66d8949dfd4056314e4bfa66635dbd2db45fbd7a6",
	name: "listStoriesFeed",
	filename: "src/lib/velto/server.ts"
}, (opts) => listStoriesFeed.__executeServer(opts));
var listStoriesFeed = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listStoriesFeed_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const mine = await sql`
      select * from stories where user_id = ${context.userId} and archived = false
        and expires_at > now() order by created_at desc`;
	const others = await sql`
      select s.* from stories s
      where s.user_id <> ${context.userId} and s.archived = false and s.expires_at > now()
        and s.user_id not in (select blocked_id from blocks where user_id = ${context.userId})
      order by s.created_at desc limit 40`;
	async function toItem(row) {
		const profile = await loadProfile(sql, String(row.user_id));
		if (!profile) return null;
		const viewed = await sql`select 1 from story_views where story_id = ${String(row.id)} and viewer_id = ${context.userId}`;
		const vc = await sql`select count(*)::int as n from story_views where story_id = ${String(row.id)}`;
		return {
			id: String(row.id),
			userId: String(row.user_id),
			type: String(row.type),
			mediaUrl: row.media_url ? String(row.media_url) : null,
			body: row.body ? String(row.body) : null,
			music: row.music ? String(row.music) : null,
			createdAt: iso(row.created_at),
			expiresAt: iso(row.expires_at),
			viewed: viewed.length > 0,
			viewCount: num(vc[0]?.n),
			profile
		};
	}
	return {
		mine: (await Promise.all(mine.map(toItem))).filter(Boolean),
		others: (await Promise.all(others.map(toItem))).filter(Boolean)
	};
});
var createStory_createServerFn_handler = createServerRpc({
	id: "3fedb0e49b7f1fa89d20cfa8b03f4eb064f1b11a53ead3a4bd45bbe4c0beb417",
	name: "createStory",
	filename: "src/lib/velto/server.ts"
}, (opts) => createStory.__executeServer(opts));
var createStory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createStory_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	rateLimit(`story:${context.userId}`, 8, 6e4);
	const media = validateMedia(data.mediaUrl ?? null, 7e5);
	const id = newId("st");
	await sql`insert into stories (id, user_id, type, media_url, body, music, privacy, expires_at)
      values (${id}, ${context.userId}, ${data.type}, ${media}, ${(data.body ?? "").slice(0, 200)},
        ${data.music ?? null}, ${data.privacy ?? "all"}, now() + interval '24 hours')`;
	await grantAchievement(sql, context.userId, "story");
	return { id };
});
var viewStory_createServerFn_handler = createServerRpc({
	id: "f5eaf15faa91056dfb3ad7485a54b7d6a7a713f619c514f967e92991389a31d0",
	name: "viewStory",
	filename: "src/lib/velto/server.ts"
}, (opts) => viewStory.__executeServer(opts));
var viewStory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(viewStory_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`insert into story_views (story_id, viewer_id, reaction)
      values (${data.id}, ${context.userId}, ${data.reaction ?? null})
      on conflict (story_id, viewer_id) do update set reaction = coalesce(${data.reaction ?? null}, story_views.reaction)`;
	return { ok: true };
});
var storyViewers_createServerFn_handler = createServerRpc({
	id: "f4dcc6daa19739972ae45c9eedcadda07cf6f6abda95367d98aea359e74993e9",
	name: "storyViewers",
	filename: "src/lib/velto/server.ts"
}, (opts) => storyViewers.__executeServer(opts));
var storyViewers = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(storyViewers_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const st = await sql`select user_id from stories where id = ${data.id}`;
	if (!st[0] || st[0].user_id !== context.userId) throw new Error("Forbidden");
	const rows = await sql`
      select viewer_id, reaction from story_views where story_id = ${data.id}`;
	const people = [];
	for (const r of rows) {
		const p = await loadProfile(sql, r.viewer_id);
		if (p) people.push({
			profile: p,
			reaction: r.reaction
		});
	}
	return people;
});
var getWallet_createServerFn_handler = createServerRpc({
	id: "52e0a1f00885539e886b67ca22d1edc7fae383f61ec15765cc0a6b101075c9b3",
	name: "getWallet",
	filename: "src/lib/velto/server.ts"
}, (opts) => getWallet.__executeServer(opts));
var getWallet = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getWallet_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const w = await sql`select balance from stars_wallets where user_id = ${context.userId}`;
	const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	const claimed = await sql`select 1 from daily_bonuses where user_id = ${context.userId} and day = ${today}::date`;
	const txs = await sql`
      select * from star_transactions
      where from_user = ${context.userId} or to_user = ${context.userId}
      order by created_at desc limit 40`;
	return {
		wallet: {
			balance: num(w[0]?.balance),
			dailyClaimed: claimed.length > 0
		},
		txs: txs.map((t) => ({
			id: String(t.id),
			fromUser: t.from_user ? String(t.from_user) : null,
			toUser: t.to_user ? String(t.to_user) : null,
			amount: num(t.amount),
			kind: String(t.kind),
			memo: t.memo ? String(t.memo) : null,
			createdAt: iso(t.created_at)
		}))
	};
});
var sendStars_createServerFn_handler = createServerRpc({
	id: "c0e47347a234aa8a7d9c9530afff3849dcaac4af5a8319b981f74a7bb060482c",
	name: "sendStars",
	filename: "src/lib/velto/server.ts"
}, (opts) => sendStars.__executeServer(opts));
var sendStars = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(sendStars_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	rateLimit(`stars:${context.userId}`, 15, 1e4);
	const amount = Math.floor(Number(data.amount));
	if (!Number.isFinite(amount) || amount <= 0) throw new Error("Invalid amount");
	if (data.toUserId === context.userId) throw new Error("Cannot send to yourself");
	const tx = await debitStars(sql, context.userId, amount, "send", (data.memo ?? "Stars").slice(0, 80), data.idempotencyKey.slice(0, 80), data.toUserId);
	if (!tx.duplicate) {
		const me = await loadProfile(sql, context.userId);
		await notify(sql, data.toUserId, "stars", "Stars received", `${displayName(me)} sent you ${amount} Stars`, { txId: tx.id });
		const chatId = await findOrCreateDm(sql, context.userId, data.toUserId);
		await sql`insert into messages (id, chat_id, sender_id, type, body, media_meta, status)
        values (${newId("msg")}, ${chatId}, ${context.userId}, ${"stars"}, ${`${amount} Stars`},
          ${JSON.stringify({
			amount,
			txId: tx.id
		})}::jsonb, ${"sent"})`;
	}
	return tx;
});
var claimDaily_createServerFn_handler = createServerRpc({
	id: "5e9cdc01f0c6ee26d712c144aafdbd66641fb330bc5e060cc73d7552838e6412",
	name: "claimDaily",
	filename: "src/lib/velto/server.ts"
}, (opts) => claimDaily.__executeServer(opts));
var claimDaily = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(claimDaily_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	if ((await sql`select 1 from daily_bonuses where user_id = ${context.userId} and day = ${today}::date`).length) throw new Error("Already claimed");
	await sql`insert into daily_bonuses (user_id, day, amount) values (${context.userId}, ${today}::date, 15)`;
	await creditStars(sql, context.userId, 15, "bonus", "Daily bonus", `daily:${context.userId}:${today}`);
	return { amount: 15 };
});
var listCatalog_createServerFn_handler = createServerRpc({
	id: "ea19e80b6a57d6681b9b8fa739955f37c35501d715f36c4113a14374ce819d4a",
	name: "listCatalog",
	filename: "src/lib/velto/server.ts"
}, (opts) => listCatalog.__executeServer(opts));
var listCatalog = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listCatalog_createServerFn_handler, async () => {
	const sql = await getSql();
	const gifts = await sql`select * from gifts order by cost asc`;
	const nfts = await sql`
      select n.*, c.name as collection_name, o.owner_id from nfts n
      join nft_collections c on c.id = n.collection_id
      left join nft_ownership o on o.nft_id = n.id`;
	const collections = await sql`
      select id, name, description, limited from nft_collections`;
	const packs = await sql`select id, name, premium from sticker_packs`;
	const stickers = await sql`
      select id, pack_id, emoji, image_key from stickers`;
	return {
		gifts: gifts.map(mapGift),
		nfts: nfts.map(mapNft),
		collections,
		packs,
		stickers
	};
});
var buyGift_createServerFn_handler = createServerRpc({
	id: "d56dbc54ddb5d6e72b8ee69b4c584b9b653876c377ce87ce09469072f4308ff8",
	name: "buyGift",
	filename: "src/lib/velto/server.ts"
}, (opts) => buyGift.__executeServer(opts));
var buyGift = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(buyGift_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	rateLimit(`gift:${context.userId}`, 20, 1e4);
	const gift = (await sql`select * from gifts where id = ${data.giftId}`)[0];
	if (!gift) throw new Error("Gift not found");
	const g = mapGift(gift);
	const me = await loadProfile(sql, context.userId);
	if (g.premiumOnly && !me?.isPremium) throw new Error("Premium required");
	const tx = await debitStars(sql, context.userId, g.cost, "gift", g.name, data.idempotencyKey, null);
	if (tx.duplicate) return tx;
	const inst = newId("ug");
	await sql`insert into user_gifts (id, gift_id, owner_id, from_id)
      values (${inst}, ${g.id}, ${data.toUserId}, ${context.userId})`;
	const chatId = await findOrCreateDm(sql, context.userId, data.toUserId);
	await sql`insert into messages (id, chat_id, sender_id, type, body, media_meta, status)
      values (${newId("msg")}, ${chatId}, ${context.userId}, ${"gift"}, ${g.name},
        ${JSON.stringify({
		giftId: g.id,
		imageKey: g.imageKey,
		rarity: g.rarity,
		inst
	})}::jsonb, ${"sent"})`;
	await notify(sql, data.toUserId, "gift", "New gift", `${displayName(me)} sent ${g.name}`, { inst });
	await grantAchievement(sql, context.userId, "gifter");
	return {
		...tx,
		instanceId: inst
	};
});
var convertGiftNft_createServerFn_handler = createServerRpc({
	id: "f9475011c0477e3be8e7735fb4fcb09e7682c9c0321d218e80be6af1978714b1",
	name: "convertGiftNft",
	filename: "src/lib/velto/server.ts"
}, (opts) => convertGiftNft.__executeServer(opts));
var convertGiftNft = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(convertGiftNft_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const row = (await sql`
      select ug.*, g.convertible_to_nft, g.name, g.image_key, g.rarity
      from user_gifts ug join gifts g on g.id = ug.gift_id
      where ug.id = ${data.instanceId} and ug.owner_id = ${context.userId}`)[0];
	if (!row) throw new Error("Gift not found");
	if (!row.convertible_to_nft) throw new Error("This gift cannot become an NFT");
	if (row.converted_nft_id) throw new Error("Already converted");
	const nftId = `VG-GIFT-${data.instanceId.slice(-8).toUpperCase()}`;
	await sql`insert into nfts (id, collection_id, name, description, image_key, rarity, traits)
      values (${nftId}, ${"col-glass"}, ${String(row.name)}, ${"Converted gift NFT"}, ${String(row.image_key)},
        ${String(row.rarity)}, ${JSON.stringify({ from: "gift" })}::jsonb)`;
	await sql`insert into nft_ownership (nft_id, owner_id) values (${nftId}, ${context.userId})`;
	await sql`insert into nft_history (id, nft_id, from_id, to_id) values (${newId("nh")}, ${nftId}, ${null}, ${context.userId})`;
	await sql`update user_gifts set converted_nft_id = ${nftId} where id = ${data.instanceId}`;
	return { nftId };
});
var transferNft_createServerFn_handler = createServerRpc({
	id: "e20e54405190d407f9dc28a40348ecf00da59db904bd10bdc2c9afaedfdf1087",
	name: "transferNft",
	filename: "src/lib/velto/server.ts"
}, (opts) => transferNft.__executeServer(opts));
var transferNft = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(transferNft_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (!(await sql`select 1 from nft_ownership where nft_id = ${data.nftId} and owner_id = ${context.userId}`).length) throw new Error("Not your NFT");
	await sql`update nft_ownership set owner_id = ${data.toUserId}, acquired_at = now() where nft_id = ${data.nftId}`;
	await sql`insert into nft_history (id, nft_id, from_id, to_id)
      values (${newId("nh")}, ${data.nftId}, ${context.userId}, ${data.toUserId})`;
	await notify(sql, data.toUserId, "nft", "NFT received", data.nftId, { nftId: data.nftId });
	return { ok: true };
});
var buyPremium_createServerFn_handler = createServerRpc({
	id: "674a1c6fed968d5cedcc21e0e75331ae8ab32064989b6185c56884ca5faf7ff2",
	name: "buyPremium",
	filename: "src/lib/velto/server.ts"
}, (opts) => buyPremium.__executeServer(opts));
var buyPremium = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(buyPremium_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await debitStars(sql, context.userId, 500, "premium", "Velto Premium 30d", data.idempotencyKey);
	await sql`update profiles set is_premium = true, premium_until = now() + interval '30 days' where user_id = ${context.userId}`;
	await grantAchievement(sql, context.userId, "premium");
	return { ok: true };
});
var listNotifications_createServerFn_handler = createServerRpc({
	id: "8b6e6d618fc1143b96fe3f3df5c5e0f85169035b20391fe7d106a4cf58a70106",
	name: "listNotifications",
	filename: "src/lib/velto/server.ts"
}, (opts) => listNotifications.__executeServer(opts));
var listNotifications = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listNotifications_createServerFn_handler, async ({ context }) => {
	return (await (await getSql())`
      select * from notifications where user_id = ${context.userId} order by created_at desc limit 50`).map((r) => ({
		id: String(r.id),
		type: String(r.type),
		title: String(r.title),
		body: String(r.body),
		read: Boolean(r.read),
		createdAt: iso(r.created_at)
	}));
});
var markNotificationsRead_createServerFn_handler = createServerRpc({
	id: "ab59f02c5f614ea0e63ac87365d79d4d91fbf6d969a6d085175d1c48377d85ee",
	name: "markNotificationsRead",
	filename: "src/lib/velto/server.ts"
}, (opts) => markNotificationsRead.__executeServer(opts));
var markNotificationsRead = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(markNotificationsRead_createServerFn_handler, async ({ context }) => {
	await (await getSql())`update notifications set read = true where user_id = ${context.userId}`;
	return { ok: true };
});
var startCall_createServerFn_handler = createServerRpc({
	id: "35a8224a861b98cf5e42344af0e55b2631ab87ebd7bfcebc6a53241b95be49e6",
	name: "startCall",
	filename: "src/lib/velto/server.ts"
}, (opts) => startCall.__executeServer(opts));
var startCall = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(startCall_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const id = newId("call");
	await sql`insert into calls (id, chat_id, kind, initiator_id, callee_id, status)
      values (${id}, ${data.chatId ?? null}, ${data.kind}, ${context.userId}, ${data.calleeId ?? null}, ${"ringing"})`;
	if (data.calleeId) await notify(sql, data.calleeId, "call", "Incoming call", data.kind, { callId: id });
	return { callId: id };
});
var updateCall_createServerFn_handler = createServerRpc({
	id: "66d416df6e32f507f9c09a74496c2ff938cce98377b3972be25e947f6243561b",
	name: "updateCall",
	filename: "src/lib/velto/server.ts"
}, (opts) => updateCall.__executeServer(opts));
var updateCall = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(updateCall_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const call = (await sql`
      select initiator_id, callee_id from calls where id = ${data.callId}`)[0];
	if (!call) throw new Error("Call not found");
	if (call.initiator_id !== context.userId && call.callee_id !== context.userId) throw new Error("Forbidden");
	await sql`update calls set status = ${data.status}, ended_at = case when ${data.status} in ('ended','missed') then now() else ended_at end
      where id = ${data.callId}`;
	return { ok: true };
});
var getCall_createServerFn_handler = createServerRpc({
	id: "c0534d80483160bb2782feb3502f7e4e102ee853bf4dc6f815551b6908759f01",
	name: "getCall",
	filename: "src/lib/velto/server.ts"
}, (opts) => getCall.__executeServer(opts));
var getCall = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(getCall_createServerFn_handler, async ({ context, data }) => {
	const rows = await (await getSql())`select * from calls where id = ${data.callId}`;
	if (!rows[0]) throw new Error("Not found");
	if (String(rows[0].initiator_id) !== context.userId && String(rows[0].callee_id) !== context.userId) throw new Error("Forbidden");
	return {
		id: String(rows[0].id),
		kind: String(rows[0].kind),
		status: String(rows[0].status),
		initiatorId: String(rows[0].initiator_id),
		calleeId: rows[0].callee_id ? String(rows[0].callee_id) : null
	};
});
var listMyInventory_createServerFn_handler = createServerRpc({
	id: "531c57d16804291ae04072f65f84ea0245f8f97ccd379ca6b36279994d1121c3",
	name: "listMyInventory",
	filename: "src/lib/velto/server.ts"
}, (opts) => listMyInventory.__executeServer(opts));
var listMyInventory = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listMyInventory_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const gifts = await sql`
      select ug.*, g.name, g.description, g.image_key, g.cost, g.rarity, g.convertible_to_nft, g.premium_only, g.id as gift_def_id
      from user_gifts ug join gifts g on g.id = ug.gift_id
      where ug.owner_id = ${context.userId} order by ug.created_at desc`;
	const nfts = await sql`
      select n.*, c.name as collection_name, o.owner_id from nft_ownership o
      join nfts n on n.id = o.nft_id join nft_collections c on c.id = n.collection_id
      where o.owner_id = ${context.userId}`;
	const achievements = await sql`
      select key, unlocked_at::text as unlocked_at from achievements where user_id = ${context.userId}`;
	return {
		gifts: gifts.map((r) => ({
			id: String(r.id),
			gift: mapGift({
				...r,
				id: r.gift_def_id
			}),
			fromId: r.from_id ? String(r.from_id) : null,
			displayed: Boolean(r.displayed),
			createdAt: iso(r.created_at)
		})),
		nfts: nfts.map(mapNft),
		achievements
	};
});
var votePoll_createServerFn_handler = createServerRpc({
	id: "e327f046ef0e78431a2d8730de1aeab8f9eb3914275f2762bcb631c29a878e05",
	name: "votePoll",
	filename: "src/lib/velto/server.ts"
}, (opts) => votePoll.__executeServer(opts));
var votePoll = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(votePoll_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const poll = (await sql`select id from polls where message_id = ${data.messageId}`)[0];
	if (!poll) throw new Error("Poll not found");
	await sql`insert into poll_votes (poll_id, user_id, option_index)
      values (${poll.id}, ${context.userId}, ${data.optionIndex})
      on conflict (poll_id, user_id) do update set option_index = ${data.optionIndex}`;
	return { ok: true };
});
var ownerStats_createServerFn_handler = createServerRpc({
	id: "787ff7f7c72616000994a849da5b941927af238b5c48ebe87e47d25e640d6ec3",
	name: "ownerStats",
	filename: "src/lib/velto/server.ts"
}, (opts) => ownerStats.__executeServer(opts));
var ownerStats = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(ownerStats_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await requireOwner(sql, context.userId);
	const users = await sql`select count(*)::int as n from profiles where is_bot = false`;
	const online = await sql`select count(*)::int as n from profiles where is_bot = false and last_seen > now() - interval '45 seconds'`;
	const messages = await sql`select count(*)::int as n from messages`;
	const groups = await sql`select count(*)::int as n from chats where type = 'group'`;
	const channels = await sql`select count(*)::int as n from chats where type = 'channel'`;
	const stories = await sql`select count(*)::int as n from stories`;
	const calls = await sql`select count(*)::int as n from calls`;
	const starsIssued = await sql`select coalesce(sum(amount),0) as n from star_transactions where kind in ('grant','bonus','owner')`;
	const starsCirculating = await sql`select coalesce(sum(balance),0) as n from stars_wallets`;
	const gifts = await sql`select count(*)::int as n from user_gifts`;
	const nfts = await sql`select count(*)::int as n from nft_ownership`;
	const premium = await sql`select count(*)::int as n from profiles where is_premium = true`;
	const actions = await sql`select * from owner_actions order by created_at desc limit 30`;
	const people = await sql`select * from profiles where is_bot = false order by created_at desc limit 40`;
	return {
		users: num(users[0]?.n),
		online: num(online[0]?.n),
		messages: num(messages[0]?.n),
		groups: num(groups[0]?.n),
		channels: num(channels[0]?.n),
		stories: num(stories[0]?.n),
		calls: num(calls[0]?.n),
		starsIssued: num(starsIssued[0]?.n),
		starsCirculating: num(starsCirculating[0]?.n),
		gifts: num(gifts[0]?.n),
		nfts: num(nfts[0]?.n),
		premium: num(premium[0]?.n),
		actions: actions.map((a) => ({
			id: String(a.id),
			command: String(a.command),
			createdAt: iso(a.created_at)
		})),
		people: people.map((p) => mapProfile(p))
	};
});
var ownerCommand_createServerFn_handler = createServerRpc({
	id: "e318f5bbe8938e2aa4de5f9102d7c9af4a227f7637f426d03d6f3a157b372d68",
	name: "ownerCommand",
	filename: "src/lib/velto/server.ts"
}, (opts) => ownerCommand.__executeServer(opts));
var ownerCommand = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(ownerCommand_createServerFn_handler, async ({ context, data }) => {
	return { reply: await runOwnerCommand(await getSql(), context.userId, data.command) };
});
var ownerModerate_createServerFn_handler = createServerRpc({
	id: "2e487fc2979c39f92c05302b214431d296ce835085d672e30362f0b946606d97",
	name: "ownerModerate",
	filename: "src/lib/velto/server.ts"
}, (opts) => ownerModerate.__executeServer(opts));
var ownerModerate = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(ownerModerate_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await requireOwner(sql, context.userId);
	if (data.action === "block") await sql`insert into blocks (user_id, blocked_id) values (${context.userId}, ${data.userId}) on conflict do nothing`;
	else if (data.action === "unblock") await sql`delete from blocks where user_id = ${context.userId} and blocked_id = ${data.userId}`;
	else await sql`update profiles set is_verified = true where user_id = ${data.userId}`;
	await sql`insert into owner_actions (id, actor_id, command, payload)
      values (${newId("oa")}, ${context.userId}, ${data.action}, ${JSON.stringify({ userId: data.userId })}::jsonb)`;
	return { ok: true };
});
var listActivity_createServerFn_handler = createServerRpc({
	id: "5b3d8f9be519ad33ed8951faf4805388863ec9e46f287fb6243fb8ab3c993c70",
	name: "listActivity",
	filename: "src/lib/velto/server.ts"
}, (opts) => listActivity.__executeServer(opts));
var listActivity = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listActivity_createServerFn_handler, async ({ context }) => {
	return (await (await getSql())`
      select * from star_transactions
      where from_user = ${context.userId} or to_user = ${context.userId}
      order by created_at desc limit 20`).map((t) => ({
		id: String(t.id),
		kind: String(t.kind),
		amount: num(t.amount),
		createdAt: iso(t.created_at)
	}));
});
//#endregion
export { addContact_createServerFn_handler, blockUser_createServerFn_handler, bootstrapSession_createServerFn_handler, buyGift_createServerFn_handler, buyPremium_createServerFn_handler, claimDaily_createServerFn_handler, convertGiftNft_createServerFn_handler, createDm_createServerFn_handler, createGroup_createServerFn_handler, createStory_createServerFn_handler, deleteHistory_createServerFn_handler, deleteMessage_createServerFn_handler, editMessage_createServerFn_handler, getCall_createServerFn_handler, getChat_createServerFn_handler, getPublicProfile_createServerFn_handler, getWallet_createServerFn_handler, globalSearch_createServerFn_handler, heartbeat_createServerFn_handler, joinByUsername_createServerFn_handler, kickMember_createServerFn_handler, listActivity_createServerFn_handler, listCatalog_createServerFn_handler, listChats_createServerFn_handler, listContacts_createServerFn_handler, listMessages_createServerFn_handler, listMyInventory_createServerFn_handler, listNotifications_createServerFn_handler, listStoriesFeed_createServerFn_handler, markNotificationsRead_createServerFn_handler, markUnread_createServerFn_handler, muteChat_createServerFn_handler, ownerCommand_createServerFn_handler, ownerModerate_createServerFn_handler, ownerStats_createServerFn_handler, pinChat_createServerFn_handler, pinMessage_createServerFn_handler, reactMessage_createServerFn_handler, sendMessage_createServerFn_handler, sendStars_createServerFn_handler, setMemberRole_createServerFn_handler, setTyping_createServerFn_handler, startCall_createServerFn_handler, storyViewers_createServerFn_handler, transferNft_createServerFn_handler, updateCall_createServerFn_handler, updateChat_createServerFn_handler, updateProfile_createServerFn_handler, viewStory_createServerFn_handler, votePoll_createServerFn_handler };
