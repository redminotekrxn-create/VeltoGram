import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn, t as authClient } from "./client-B40BzJxt.mjs";
import { t as GROK_PROVIDERS } from "./server-CZEeSYPY.mjs";
import { a as dict, i as detectLang, n as VeltoMark } from "./i18n-CBDR4ZJe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-OKDRvZzQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	const navigate = useNavigate();
	const [mode, setMode] = (0, import_react.useState)("in");
	const [lang] = (0, import_react.useState)(detectLang());
	const d = dict(lang);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function submit(e) {
		e.preventDefault();
		setError(null);
		setBusy(true);
		try {
			if (mode === "up") {
				const { error: err } = await authClient.signUp.email({
					email,
					password,
					name: name || email.split("@")[0] || "Traveler"
				});
				if (err) throw new Error(err.message);
			} else {
				const { error: err } = await authClient.signIn.email({
					email,
					password
				});
				if (err) throw new Error(err.message);
			}
			navigate({ to: "/" });
		} catch (err) {
			setError(err instanceof Error ? err.message : "Failed");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative grid min-h-dvh place-items-center overflow-hidden px-5 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-[-20%] left-[-10%] size-[28rem] rounded-full bg-accent/20 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-[-20%] bottom-[-10%] size-[24rem] rounded-full bg-star/10 blur-3xl" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "glass-strong relative w-full max-w-md rounded-[var(--radius-2xl)] p-6 sm:p-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex flex-col items-center gap-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VeltoMark, { className: "size-14" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-semibold tracking-[-0.05em]",
						children: d.app
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: d.tagline
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [
					GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => signIn(p.providerId, { callbackURL: "/" }),
						className: "glass-btn h-12 rounded-[var(--radius-md)] font-medium",
						children: p.label === "Google" ? d.continueGoogle : d.continueX
					}, p.providerId)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 py-1 text-xs tracking-wide text-subtle uppercase",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border" }),
							d.or,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 grid grid-cols-2 gap-1 rounded-[var(--radius-md)] bg-fg/5 p-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `h-9 rounded-[10px] text-sm font-medium ${mode === "in" ? "accent-btn" : ""}`,
							onClick: () => setMode("in"),
							children: d.signIn
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `h-9 rounded-[10px] text-sm font-medium ${mode === "up" ? "accent-btn" : ""}`,
							onClick: () => setMode("up"),
							children: d.createAccount
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex flex-col gap-2",
						onSubmit: submit,
						children: [
							mode === "up" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: name,
								onChange: (e) => setName(e.target.value),
								placeholder: d.firstName,
								className: "h-12 rounded-[var(--radius-md)] border border-border bg-fg/5 px-4 text-fg outline-none placeholder:text-subtle"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								type: "email",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								placeholder: d.email,
								className: "h-12 rounded-[var(--radius-md)] border border-border bg-fg/5 px-4 text-fg outline-none placeholder:text-subtle"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								type: "password",
								minLength: 8,
								value: password,
								onChange: (e) => setPassword(e.target.value),
								placeholder: d.password,
								className: "h-12 rounded-[var(--radius-md)] border border-border bg-fg/5 px-4 text-fg outline-none placeholder:text-subtle"
							}),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-danger",
								children: error
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								disabled: busy,
								className: "accent-btn mt-1 h-12 rounded-[var(--radius-md)] font-semibold",
								children: busy ? "…" : mode === "up" ? d.createAccount : d.signIn
							})
						]
					})
				]
			})]
		})]
	});
}
//#endregion
export { Login as component };
