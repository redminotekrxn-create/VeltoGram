import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-CJQCePbV.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function iso(value) {
	if (value instanceof Date) return value.toISOString();
	if (typeof value === "string") return value;
	return (/* @__PURE__ */ new Date()).toISOString();
}
function num(value) {
	if (typeof value === "number" && Number.isFinite(value)) return value;
	if (typeof value === "string") return Number(value) || 0;
	if (typeof value === "bigint") return Number(value);
	return 0;
}
function slugify(input) {
	return input.toLowerCase().replace(/[^a-z0-9_]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 24) || "user";
}
//#endregion
export { slugify as i, iso as n, num as r, cn as t };
