//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CqGJoabf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/api/auth/$"
		],
		preloads: ["/assets/index-CS8xu5vA.js", "/assets/react-SIfiwpqq.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CS8xu5vA.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-INisBvXl.js",
			"/assets/server-D-d8x0b9.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/i18n-yiFcgwdA.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-CwemcKfF.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/i18n-yiFcgwdA.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
