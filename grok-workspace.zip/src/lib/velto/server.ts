import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { iso, num } from "@/lib/utils";
import {
  addXp,
  creditStars,
  debitStars,
  displayName,
  findOrCreateDm,
  GUIDE_ID,
  grantAchievement,
  loadProfile,
  LOUNGE_CHAT,
  mapChatRow,
  mapGift,
  mapMessage,
  mapNft,
  mapProfile,
  newId,
  NEWS_CHAT,
  notify,
  OWNER_BOT_ID,
  OWNER_ID_KEY,
  rateLimit,
  readOwnerId,
  requireMember,
  requireOwner,
  uniqueUsername,
  validateMedia,
} from "./helpers";
import type {
  ChatListItem,
  GiftCatalogItem,
  Message,
  NftItem,
  NotificationItem,
  OwnedGift,
  Profile,
  SessionPayload,
  StarTx,
  StoryItem,
  Wallet,
} from "./types";

function asUser(ctx: { userId: string }) {
  return ctx.userId;
}

export const bootstrapSession = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<SessionPayload> => {
    const sql = await getSql();
    const userId = asUser(context);
    rateLimit(`boot:${userId}`, 20, 10_000);

    let profile = await loadProfile(sql, userId);
    if (!profile) {
      const ownerId = await readOwnerId(sql);
      const isFirst = !ownerId;
      const username = await uniqueUsername(sql, `velto_${userId.slice(-6)}`);
      await sql`insert into profiles (user_id, username, first_name, is_owner, is_verified)
        values (${userId}, ${username}, ${"Traveler"}, ${isFirst}, ${isFirst})`;
      if (isFirst) {
        await sql`insert into app_settings (key, value) values (${OWNER_ID_KEY}, ${userId})
          on conflict (key) do nothing`;
      }
      await sql`insert into stars_wallets (user_id, balance) values (${userId}, 0) on conflict do nothing`;
      await creditStars(sql, userId, 80, "grant", "Welcome bonus", `welcome:${userId}`);
      await grantAchievement(sql, userId, "joined");
      profile = await loadProfile(sql, userId);
    }

    const ownerId = await readOwnerId(sql);
    const isOwner = ownerId === userId;
    if (profile && profile.isOwner !== isOwner) {
      await sql`update profiles set is_owner = ${isOwner} where user_id = ${userId}`;
      profile = { ...profile, isOwner };
    }

    await sql`insert into chat_members (chat_id, user_id, role)
      values (${NEWS_CHAT}, ${userId}, ${"subscriber"}) on conflict do nothing`;
    await sql`insert into chat_members (chat_id, user_id, role)
      values (${LOUNGE_CHAT}, ${userId}, ${"member"}) on conflict do nothing`;

    const guideChat = await findOrCreateDm(sql, userId, GUIDE_ID);
    const existingGuide = await sql`select 1 from messages where chat_id = ${guideChat} limit 1`;
    if (!existingGuide.length) {
      await sql`insert into messages (id, chat_id, sender_id, type, body, status)
        values (${newId("msg")}, ${guideChat}, ${GUIDE_ID}, ${"text"},
        ${"Welcome to VeltoGram. Chats, Stories, Stars, gifts, and NFTs live here. Open Contacts to find people, or send a gift from the Stars tab."}, ${"read"})`;
    }

    if (isOwner) {
      const botChat = await findOrCreateDm(sql, userId, OWNER_BOT_ID);
      const existingBot = await sql`select 1 from messages where chat_id = ${botChat} limit 1`;
      if (!existingBot.length) {
        await sql`insert into messages (id, chat_id, sender_id, type, body, status)
          values (${newId("msg")}, ${botChat}, ${OWNER_BOT_ID}, ${"text"},
          ${"Owner Bot online. Restricted to OWNER_ID. Try /help"}, ${"read"})`;
      }
    }

    await sql`update profiles set last_seen = now(), updated_at = now() where user_id = ${userId}`;
    profile = (await loadProfile(sql, userId))!;

    const walletRows = await sql<{ balance: number | string }>`select balance from stars_wallets where user_id = ${userId}`;
    const today = new Date().toISOString().slice(0, 10);
    const claimed = await sql`select 1 from daily_bonuses where user_id = ${userId} and day = ${today}::date`;

    return {
      profile,
      isOwner,
      wallet: { balance: num(walletRows[0]?.balance), dailyClaimed: claimed.length > 0 },
      needsOnboarding: profile.firstName === "Traveler" || profile.username.startsWith("velto_"),
    };
  });

export const heartbeat = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await sql`update profiles set last_seen = now() where user_id = ${context.userId}`;
    return { ok: true };
  });

export const updateProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: Record<string, unknown>) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const userId = context.userId;
    rateLimit(`prof:${userId}`, 20, 10_000);
    const cur = await loadProfile(sql, userId);
    if (!cur) throw new Error("No profile");

    let username = cur.username;
    if (typeof data.username === "string") {
      const next = data.username.trim().toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 24);
      if (next.length < 3) throw new Error("Username too short");
      if (next !== cur.username) {
        const taken = await sql`select 1 from profiles where username = ${next} and user_id <> ${userId}`;
        if (taken.length) throw new Error("Username is taken");
        username = next;
      }
    }

    const firstName = typeof data.firstName === "string" ? data.firstName.trim().slice(0, 40) : cur.firstName;
    const lastName = typeof data.lastName === "string" ? data.lastName.trim().slice(0, 40) : cur.lastName;
    const bio = typeof data.bio === "string" ? data.bio.trim().slice(0, 180) : cur.bio;
    const phone = typeof data.phone === "string" ? data.phone.trim().slice(0, 24) : cur.phone;
    const avatarUrl =
      typeof data.avatarUrl === "string" ? validateMedia(data.avatarUrl, 500_000) : cur.avatarUrl;
    const avatarFrame = typeof data.avatarFrame === "string" ? data.avatarFrame : cur.avatarFrame;
    const profileColor = typeof data.profileColor === "string" ? data.profileColor : cur.profileColor;
    const profileBg = typeof data.profileBg === "string" ? data.profileBg : cur.profileBg;
    const nameStyle = typeof data.nameStyle === "string" ? data.nameStyle : cur.nameStyle;
    const emojiStatus = typeof data.emojiStatus === "string" ? data.emojiStatus.slice(0, 8) : cur.emojiStatus;
    const statusText = typeof data.statusText === "string" ? data.statusText.slice(0, 40) : cur.statusText;
    const language = typeof data.language === "string" ? data.language : cur.language;
    const theme = typeof data.theme === "string" ? data.theme : cur.theme;
    const accent = typeof data.accent === "string" ? data.accent : cur.accent;

    await sql`update profiles set
      username = ${username}, first_name = ${firstName}, last_name = ${lastName}, bio = ${bio},
      phone = ${phone}, avatar_url = ${avatarUrl}, avatar_frame = ${avatarFrame},
      profile_color = ${profileColor}, profile_bg = ${profileBg}, name_style = ${nameStyle},
      emoji_status = ${emojiStatus}, status_text = ${statusText}, language = ${language},
      theme = ${theme}, accent = ${accent}, updated_at = now()
      where user_id = ${userId}`;
    return loadProfile(sql, userId);
  });

export const getPublicProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { userId?: string; username?: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = data.userId
      ? await sql<Record<string, unknown>>`select * from profiles where user_id = ${data.userId}`
      : await sql<Record<string, unknown>>`select * from profiles where username = ${data.username ?? ""}`;
    if (!rows[0]) throw new Error("User not found");
    const profile = mapProfile(rows[0]);
    const blocked = await sql`select 1 from blocks where user_id = ${profile.userId} and blocked_id = ${context.userId}`;
    if (blocked.length) throw new Error("User not found");
    const gifts = await sql<Record<string, unknown>>`
      select ug.*, g.name, g.description, g.image_key, g.cost, g.rarity, g.convertible_to_nft, g.premium_only, g.id as gift_def_id
      from user_gifts ug join gifts g on g.id = ug.gift_id
      where ug.owner_id = ${profile.userId} and ug.displayed = true
      order by ug.created_at desc limit 24`;
    const nfts = await sql<Record<string, unknown>>`
      select n.*, c.name as collection_name, o.owner_id
      from nft_ownership o join nfts n on n.id = o.nft_id
      join nft_collections c on c.id = n.collection_id
      where o.owner_id = ${profile.userId}`;
    const isContact = await sql`select 1 from contacts where user_id = ${context.userId} and contact_id = ${profile.userId}`;
    return {
      profile,
      gifts: gifts.map((r) => ({
        id: String(r.id),
        gift: mapGift({ ...r, id: r.gift_def_id }),
        fromId: r.from_id ? String(r.from_id) : null,
        displayed: true,
        createdAt: iso(r.created_at),
      })) as OwnedGift[],
      nfts: nfts.map(mapNft),
      isContact: isContact.length > 0,
      isMe: profile.userId === context.userId,
    };
  });

export const listChats = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ChatListItem[]> => {
    const sql = await getSql();
    const ownerId = await readOwnerId(sql);
    const rows = await sql<Record<string, unknown>>`
      select c.*, cm.role, cm.pinned, cm.muted, cm.unread_count,
        m.body as last_text, m.type as last_type, m.created_at as last_at, m.sender_id as last_sender_id
      from chat_members cm
      join chats c on c.id = cm.chat_id
      left join lateral (
        select body, type, created_at, sender_id from messages
        where chat_id = c.id and (scheduled_at is null or scheduled_at <= now())
        order by created_at desc limit 1
      ) m on true
      where cm.user_id = ${context.userId}
      order by cm.pinned desc, coalesce(m.created_at, c.created_at) desc`;

    const out: ChatListItem[] = [];
    for (const row of rows) {
      const type = String(row.type);
      if (type === "bot" && String(row.id).includes(OWNER_BOT_ID) && ownerId !== context.userId) {
        continue;
      }
      let peer: Profile | null = null;
      if (type === "dm" || type === "bot") {
        const members = await sql<{ user_id: string }>`select user_id from chat_members where chat_id = ${String(row.id)}`;
        const other = members.find((m) => m.user_id !== context.userId)?.user_id;
        if (other) peer = await loadProfile(sql, other);
      }
      const countRows = await sql<{ n: number }>`select count(*)::int as n from chat_members where chat_id = ${String(row.id)}`;
      out.push(mapChatRow(row, peer, num(countRows[0]?.n)));
    }
    return out;
  });

export const getChat = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { chatId: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await requireMember(sql, data.chatId, context.userId);
    const rows = await sql<Record<string, unknown>>`select * from chats where id = ${data.chatId}`;
    if (!rows[0]) throw new Error("Chat not found");
    const members = await sql<{ user_id: string; role: string }>`
      select user_id, role from chat_members where chat_id = ${data.chatId}`;
    const profiles: Profile[] = [];
    for (const m of members) {
      const p = await loadProfile(sql, m.user_id);
      if (p) profiles.push(p);
    }
    const pinned = await sql<Record<string, unknown>>`
      select * from messages where chat_id = ${data.chatId} and is_pinned = true order by created_at desc limit 8`;
    return {
      chat: rows[0],
      members: profiles.map((p) => ({
        ...p,
        role: members.find((m) => m.user_id === p.userId)?.role ?? "member",
      })),
      pinned: pinned.map((r) => mapMessage(r, null, [])),
    };
  });

async function attachReactions(sql: Awaited<ReturnType<typeof getSql>>, msgs: Record<string, unknown>[], me: string) {
  if (!msgs.length) return [] as Message[];
  const ids = msgs.map((m) => String(m.id));
  const placeholders = ids.map((_, i) => `$${i + 1}`).join(",");
  const reacts = await sql.query<{ message_id: string; emoji: string; user_id: string }>(
    `select message_id, emoji, user_id from message_reactions where message_id in (${placeholders})`,
    ids,
  );
  const byMsg = new Map<string, { emoji: string; count: number; mine: boolean }[]>();
  for (const r of reacts) {
    const list = byMsg.get(r.message_id) ?? [];
    const existing = list.find((x) => x.emoji === r.emoji);
    if (existing) {
      existing.count += 1;
      existing.mine = existing.mine || r.user_id === me;
    } else list.push({ emoji: r.emoji, count: 1, mine: r.user_id === me });
    byMsg.set(r.message_id, list);
  }
  const senders = new Map<string, Profile>();
  const out: Message[] = [];
  for (const row of msgs) {
    const sid = String(row.sender_id);
    if (!senders.has(sid)) {
      const p = await loadProfile(sql, sid);
      if (p) senders.set(sid, p);
    }
    out.push(mapMessage(row, senders.get(sid) ?? null, byMsg.get(String(row.id)) ?? []));
  }
  return out;
}

export const listMessages = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { chatId: string; before?: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await requireMember(sql, data.chatId, context.userId);
    const rows = data.before
      ? await sql<Record<string, unknown>>`
          select * from messages where chat_id = ${data.chatId}
            and created_at < ${data.before}::timestamptz
            and (scheduled_at is null or scheduled_at <= now() or sender_id = ${context.userId})
          order by created_at desc limit 40`
      : await sql<Record<string, unknown>>`
          select * from messages where chat_id = ${data.chatId}
            and (scheduled_at is null or scheduled_at <= now() or sender_id = ${context.userId})
          order by created_at desc limit 40`;
    await sql`update chat_members set unread_count = 0, last_read_at = now()
      where chat_id = ${data.chatId} and user_id = ${context.userId}`;
    await sql`update messages set status = 'read'
      where chat_id = ${data.chatId} and sender_id <> ${context.userId} and status <> 'read'`;
    const chat = await sql<{ type: string }>`select type from chats where id = ${data.chatId}`;
    if (chat[0]?.type === "channel") {
      const ids = rows.map((r) => String(r.id));
      if (ids.length) {
        await sql.query(
          `update messages set views = views + 1 where id in (${ids.map((_, i) => `$${i + 1}`).join(",")})`,
          ids,
        );
      }
    }
    const messages = (await attachReactions(sql, rows, context.userId)).reverse();
    const typing = await sql<{ user_id: string }>`
      select user_id from typing where chat_id = ${data.chatId}
        and user_id <> ${context.userId} and updated_at > now() - interval '4 seconds'`;
    const typingProfiles: Profile[] = [];
    for (const t of typing) {
      const p = await loadProfile(sql, t.user_id);
      if (p) typingProfiles.push(p);
    }
    return { messages, typing: typingProfiles };
  });

async function runOwnerCommand(
  sql: Awaited<ReturnType<typeof getSql>>,
  userId: string,
  text: string,
): Promise<string> {
  await requireOwner(sql, userId);
  const parts = text.trim().split(/\s+/);
  const cmd = (parts[0] ?? "").toLowerCase();
  const arg = parts.slice(1).join(" ");
  await sql`insert into owner_actions (id, actor_id, command, payload)
    values (${newId("oa")}, ${userId}, ${cmd}, ${JSON.stringify({ arg })}::jsonb)`;

  if (cmd === "/help") {
    return "Commands:\n/stars N\n/gift common|rare|epic|legendary|mythic\n/nft random\n/premium\n/balance\n/inventory\n/stats";
  }
  if (cmd === "/stars") {
    const n = Math.max(1, Math.min(1_000_000, Number(arg) || 0));
    await creditStars(sql, userId, n, "owner", "Owner Bot grant", newId("idm"), OWNER_BOT_ID);
    return `Granted ${n} Stars.`;
  }
  if (cmd === "/gift") {
    const rarity = (arg || "rare").toLowerCase();
    const gift = await sql<Record<string, unknown>>`select * from gifts where rarity = ${rarity} order by random() limit 1`;
    if (!gift[0]) return "No gift of that rarity.";
    const inst = newId("ug");
    await sql`insert into user_gifts (id, gift_id, owner_id, from_id) values (${inst}, ${String(gift[0].id)}, ${userId}, ${OWNER_BOT_ID})`;
    return `Granted ${String(gift[0].name)} (${rarity}).`;
  }
  if (cmd === "/nft") {
    const free = await sql<Record<string, unknown>>`
      select n.* from nfts n left join nft_ownership o on o.nft_id = n.id
      where o.nft_id is null order by random() limit 1`;
    if (!free[0]) return "No unowned NFT left in the catalog.";
    const nftId = String(free[0].id);
    await sql`insert into nft_ownership (nft_id, owner_id) values (${nftId}, ${userId})`;
    await sql`insert into nft_history (id, nft_id, from_id, to_id) values (${newId("nh")}, ${nftId}, ${OWNER_BOT_ID}, ${userId})`;
    return `Transferred ${String(free[0].name)} (${nftId}).`;
  }
  if (cmd === "/premium") {
    await sql`update profiles set is_premium = true, premium_until = now() + interval '30 days' where user_id = ${userId}`;
    return "Velto Premium activated for 30 days.";
  }
  if (cmd === "/balance") {
    const w = await sql<{ balance: number | string }>`select balance from stars_wallets where user_id = ${userId}`;
    return `Balance: ${num(w[0]?.balance)} Stars.`;
  }
  if (cmd === "/inventory") {
    const g = await sql<{ n: number }>`select count(*)::int as n from user_gifts where owner_id = ${userId}`;
    const n = await sql<{ n: number }>`select count(*)::int as n from nft_ownership where owner_id = ${userId}`;
    return `Gifts: ${num(g[0]?.n)} · NFT: ${num(n[0]?.n)}`;
  }
  if (cmd === "/stats") {
    const users = await sql<{ n: number }>`select count(*)::int as n from profiles where is_bot = false`;
    const msgs = await sql<{ n: number }>`select count(*)::int as n from messages`;
    const stars = await sql<{ n: number | string }>`select coalesce(sum(balance),0) as n from stars_wallets`;
    return `Users ${num(users[0]?.n)} · Messages ${num(msgs[0]?.n)} · Stars in wallets ${num(stars[0]?.n)}`;
  }
  return "Unknown command. /help";
}

export const sendMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: {
    chatId: string;
    type?: string;
    body?: string;
    mediaUrl?: string;
    mediaMeta?: Record<string, unknown>;
    replyToId?: string;
    spoiler?: boolean;
    scheduledAt?: string;
    expiresInSec?: number;
  }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const userId = context.userId;
    rateLimit(`msg:${userId}`, 50, 10_000);
    const member = await requireMember(sql, data.chatId, userId);
    const chat = (await sql<{ type: string; owner_id: string | null }>`select type, owner_id from chats where id = ${data.chatId}`)[0];
    if (!chat) throw new Error("Chat not found");
    if (chat.type === "channel" && member.role !== "owner" && member.role !== "admin") {
      throw new Error("Only admins can post in this channel");
    }
    const mediaUrl = validateMedia(data.mediaUrl ?? null);
    const body = (data.body ?? "").slice(0, 4000);
    const type = data.type ?? (mediaUrl ? "photo" : "text");
    if (!body && !mediaUrl && type === "text") throw new Error("Empty message");

    if (chat.type === "bot" && data.chatId.includes(OWNER_BOT_ID) && body.startsWith("/")) {
      await requireOwner(sql, userId);
      const id = newId("msg");
      await sql`insert into messages (id, chat_id, sender_id, type, body, status)
        values (${id}, ${data.chatId}, ${userId}, ${"text"}, ${body}, ${"read"})`;
      const reply = await runOwnerCommand(sql, userId, body);
      await sql`insert into messages (id, chat_id, sender_id, type, body, status)
        values (${newId("msg")}, ${data.chatId}, ${OWNER_BOT_ID}, ${"text"}, ${reply}, ${"read"})`;
      return { ok: true, id };
    }

    const id = newId("msg");
    const expires = data.expiresInSec
      ? new Date(Date.now() + data.expiresInSec * 1000).toISOString()
      : null;
    await sql`insert into messages (id, chat_id, sender_id, type, body, media_url, media_meta, reply_to_id, is_spoiler, scheduled_at, expires_at, status)
      values (${id}, ${data.chatId}, ${userId}, ${type}, ${body || null}, ${mediaUrl},
        ${JSON.stringify(data.mediaMeta ?? {})}::jsonb, ${data.replyToId ?? null}, ${Boolean(data.spoiler)},
        ${data.scheduledAt ?? null}, ${expires}, ${"sent"})`;

    if (type === "poll" && data.mediaMeta) {
      await sql`insert into polls (id, message_id, question, options, quiz, correct_index)
        values (${newId("poll")}, ${id}, ${String(data.mediaMeta.question ?? "")},
          ${JSON.stringify(data.mediaMeta.options ?? [])}::jsonb, ${Boolean(data.mediaMeta.quiz)},
          ${typeof data.mediaMeta.correctIndex === "number" ? data.mediaMeta.correctIndex : null})`;
    }

    await sql`update chat_members set unread_count = unread_count + 1
      where chat_id = ${data.chatId} and user_id <> ${userId}`;
    await addXp(sql, userId, 1);

    const others = await sql<{ user_id: string }>`select user_id from chat_members where chat_id = ${data.chatId} and user_id <> ${userId}`;
    const me = await loadProfile(sql, userId);
    for (const o of others) {
      if (o.user_id.startsWith("sys-")) continue;
      await notify(sql, o.user_id, "message", displayName(me!), body || type, { chatId: data.chatId });
    }
    return { ok: true, id };
  });

export const editMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { id: string; body: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const body = data.body.slice(0, 4000);
    const res = await sql`update messages set body = ${body}, is_edited = true, edited_at = now()
      where id = ${data.id} and sender_id = ${context.userId} returning id`;
    if (!res.length) throw new Error("Cannot edit");
    return { ok: true };
  });

export const deleteMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { id: string; chatId: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const member = await requireMember(sql, data.chatId, context.userId);
    const canMod = member.role === "owner" || member.role === "admin";
    if (canMod) {
      await sql`delete from messages where id = ${data.id} and chat_id = ${data.chatId}`;
    } else {
      await sql`delete from messages where id = ${data.id} and chat_id = ${data.chatId} and sender_id = ${context.userId}`;
    }
    return { ok: true };
  });

export const reactMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { id: string; emoji: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const emoji = data.emoji.slice(0, 8);
    const existing = await sql<{ emoji: string }>`
      select emoji from message_reactions where message_id = ${data.id} and user_id = ${context.userId}`;
    if (existing[0]?.emoji === emoji) {
      await sql`delete from message_reactions where message_id = ${data.id} and user_id = ${context.userId}`;
    } else {
      await sql`delete from message_reactions where message_id = ${data.id} and user_id = ${context.userId}`;
      await sql`insert into message_reactions (message_id, user_id, emoji) values (${data.id}, ${context.userId}, ${emoji})`;
    }
    return { ok: true };
  });

export const pinMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { id: string; chatId: string; pinned: boolean }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const member = await requireMember(sql, data.chatId, context.userId);
    if (member.role !== "owner" && member.role !== "admin" && member.role !== "member") {
      throw new Error("Cannot pin");
    }
    await sql`update messages set is_pinned = ${data.pinned} where id = ${data.id} and chat_id = ${data.chatId}`;
    return { ok: true };
  });

export const setTyping = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { chatId: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`insert into typing (chat_id, user_id, updated_at) values (${data.chatId}, ${context.userId}, now())
      on conflict (chat_id, user_id) do update set updated_at = now()`;
    return { ok: true };
  });

export const createDm = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { userId: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    if (data.userId === context.userId) throw new Error("Cannot chat with yourself");
    if (data.userId === OWNER_BOT_ID) {
      await requireOwner(sql, context.userId);
    }
    const blocked = await sql`select 1 from blocks where (user_id = ${data.userId} and blocked_id = ${context.userId})
      or (user_id = ${context.userId} and blocked_id = ${data.userId})`;
    if (blocked.length) throw new Error("Unavailable");
    const id = await findOrCreateDm(sql, context.userId, data.userId);
    await sql`insert into contacts (user_id, contact_id) values (${context.userId}, ${data.userId}) on conflict do nothing`;
    return { chatId: id };
  });

export const createGroup = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { title: string; description?: string; memberIds?: string[]; isChannel?: boolean; username?: string; isPublic?: boolean }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const title = data.title.trim().slice(0, 60);
    if (title.length < 2) throw new Error("Name required");
    const id = newId("chat");
    const type = data.isChannel ? "channel" : "group";
    let username: string | null = null;
    if (data.username) {
      username = data.username.toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 24);
      const taken = await sql`select 1 from chats where username = ${username}`;
      if (taken.length) throw new Error("Username taken");
    }
    await sql`insert into chats (id, type, title, username, description, owner_id, is_public, invite_code)
      values (${id}, ${type}, ${title}, ${username}, ${(data.description ?? "").slice(0, 300)},
        ${context.userId}, ${data.isPublic !== false}, ${newId("inv").slice(-10)})`;
    await sql`insert into chat_members (chat_id, user_id, role) values (${id}, ${context.userId}, ${"owner"})`;
    for (const mid of data.memberIds ?? []) {
      if (mid === context.userId) continue;
      await sql`insert into chat_members (chat_id, user_id, role) values (${id}, ${mid}, ${data.isChannel ? "subscriber" : "member"}) on conflict do nothing`;
      await notify(sql, mid, "invite", title, `You were added to ${title}`, { chatId: id });
    }
    await sql`insert into messages (id, chat_id, sender_id, type, body, status)
      values (${newId("msg")}, ${id}, ${context.userId}, ${"system"}, ${`${title} created`}, ${"read"})`;
    return { chatId: id };
  });

export const updateChat = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { chatId: string; title?: string; description?: string; avatarUrl?: string; isPublic?: boolean }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const member = await requireMember(sql, data.chatId, context.userId);
    if (member.role !== "owner" && member.role !== "admin") throw new Error("Forbidden");
    const avatar = typeof data.avatarUrl === "string" ? validateMedia(data.avatarUrl, 400_000) : undefined;
    await sql`update chats set
      title = coalesce(${data.title ?? null}, title),
      description = coalesce(${data.description ?? null}, description),
      is_public = coalesce(${data.isPublic ?? null}, is_public),
      avatar_url = coalesce(${avatar ?? null}, avatar_url)
      where id = ${data.chatId}`;
    return { ok: true };
  });

export const setMemberRole = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { chatId: string; userId: string; role: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = await requireMember(sql, data.chatId, context.userId);
    if (me.role !== "owner" && me.role !== "admin") throw new Error("Forbidden");
    if (data.role === "owner") throw new Error("Cannot transfer this way");
    await sql`update chat_members set role = ${data.role} where chat_id = ${data.chatId} and user_id = ${data.userId}`;
    return { ok: true };
  });

export const kickMember = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { chatId: string; userId: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = await requireMember(sql, data.chatId, context.userId);
    if (me.role !== "owner" && me.role !== "admin") throw new Error("Forbidden");
    await sql`delete from chat_members where chat_id = ${data.chatId} and user_id = ${data.userId} and role <> 'owner'`;
    return { ok: true };
  });

export const pinChat = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { chatId: string; pinned: boolean }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update chat_members set pinned = ${data.pinned} where chat_id = ${data.chatId} and user_id = ${context.userId}`;
    return { ok: true };
  });

export const muteChat = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { chatId: string; muted: boolean }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update chat_members set muted = ${data.muted} where chat_id = ${data.chatId} and user_id = ${context.userId}`;
    return { ok: true };
  });

export const markUnread = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { chatId: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update chat_members set unread_count = greatest(unread_count, 1)
      where chat_id = ${data.chatId} and user_id = ${context.userId}`;
    return { ok: true };
  });

export const deleteHistory = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { chatId: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const member = await requireMember(sql, data.chatId, context.userId);
    if (member.role === "owner") {
      await sql`delete from messages where chat_id = ${data.chatId}`;
    } else {
      await sql`delete from messages where chat_id = ${data.chatId} and sender_id = ${context.userId}`;
    }
    return { ok: true };
  });

export const joinByUsername = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { username: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const u = data.username.replace(/^@/, "");
    const chat = await sql<{ id: string; type: string; is_public: boolean }>`
      select id, type, is_public from chats where username = ${u}`;
    if (!chat[0] || !chat[0].is_public) throw new Error("Not found");
    const role = chat[0].type === "channel" ? "subscriber" : "member";
    await sql`insert into chat_members (chat_id, user_id, role) values (${chat[0].id}, ${context.userId}, ${role}) on conflict do nothing`;
    return { chatId: chat[0].id };
  });

export const globalSearch = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { q: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const q = `%${data.q.trim().slice(0, 40)}%`;
    if (data.q.trim().length < 1) {
      return { users: [], chats: [], gifts: [], nfts: [], messages: [] };
    }
    const users = await sql<Record<string, unknown>>`
      select * from profiles
      where (username ilike ${q} or first_name ilike ${q} or last_name ilike ${q})
        and user_id <> ${context.userId}
      order by is_verified desc, username asc limit 12`;
    const chats = await sql<Record<string, unknown>>`
      select * from chats where is_public = true and (title ilike ${q} or username ilike ${q}) limit 8`;
    const gifts = await sql<Record<string, unknown>>`select * from gifts where name ilike ${q} limit 8`;
    const nfts = await sql<Record<string, unknown>>`
      select n.*, c.name as collection_name, o.owner_id from nfts n
      join nft_collections c on c.id = n.collection_id
      left join nft_ownership o on o.nft_id = n.id
      where n.name ilike ${q} or n.id ilike ${q} limit 8`;
    const messages = await sql<Record<string, unknown>>`
      select m.id, m.body, m.chat_id, m.created_at from messages m
      join chat_members cm on cm.chat_id = m.chat_id and cm.user_id = ${context.userId}
      where m.body ilike ${q} order by m.created_at desc limit 8`;
    return {
      users: users.map((r) => mapProfile(r)),
      chats,
      gifts: gifts.map(mapGift),
      nfts: nfts.map(mapNft),
      messages: messages.map((m) => ({
        id: String(m.id),
        body: String(m.body ?? ""),
        chatId: String(m.chat_id),
        createdAt: iso(m.created_at),
      })),
    };
  });

export const listContacts = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<{ contact_id: string }>`select contact_id from contacts where user_id = ${context.userId}`;
    const people: Profile[] = [];
    for (const r of rows) {
      const p = await loadProfile(sql, r.contact_id);
      if (p) people.push(p);
    }
    const suggested = await sql<Record<string, unknown>>`
      select * from profiles
      where is_bot = false and user_id <> ${context.userId}
        and user_id not in (select contact_id from contacts where user_id = ${context.userId})
      order by last_seen desc limit 8`;
    return { contacts: people, suggested: suggested.map((r) => mapProfile(r)) };
  });

export const addContact = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { userId: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`insert into contacts (user_id, contact_id) values (${context.userId}, ${data.userId}) on conflict do nothing`;
    return { ok: true };
  });

export const blockUser = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { userId: string; block: boolean }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    if (data.block) {
      await sql`insert into blocks (user_id, blocked_id) values (${context.userId}, ${data.userId}) on conflict do nothing`;
      await sql`delete from contacts where user_id = ${context.userId} and contact_id = ${data.userId}`;
    } else {
      await sql`delete from blocks where user_id = ${context.userId} and blocked_id = ${data.userId}`;
    }
    return { ok: true };
  });

export const listStoriesFeed = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const mine = await sql<Record<string, unknown>>`
      select * from stories where user_id = ${context.userId} and archived = false
        and expires_at > now() order by created_at desc`;
    const others = await sql<Record<string, unknown>>`
      select s.* from stories s
      where s.user_id <> ${context.userId} and s.archived = false and s.expires_at > now()
        and s.user_id not in (select blocked_id from blocks where user_id = ${context.userId})
      order by s.created_at desc limit 40`;
    async function toItem(row: Record<string, unknown>): Promise<StoryItem | null> {
      const profile = await loadProfile(sql, String(row.user_id));
      if (!profile) return null;
      const viewed = await sql`select 1 from story_views where story_id = ${String(row.id)} and viewer_id = ${context.userId}`;
      const vc = await sql<{ n: number }>`select count(*)::int as n from story_views where story_id = ${String(row.id)}`;
      return {
        id: String(row.id),
        userId: String(row.user_id),
        type: String(row.type),
        mediaUrl: row.media_url ? String(row.media_url) : null,
        body: row.body ? String(row.body) : null,
        music: row.music ? String(row.music) : null,
        createdAt: iso(row.created_at),
        expiresAt: iso(row.expires_at),
        viewed: viewed.length > 0,
        viewCount: num(vc[0]?.n),
        profile,
      };
    }
    const myItems = (await Promise.all(mine.map(toItem))).filter(Boolean) as StoryItem[];
    const otherItems = (await Promise.all(others.map(toItem))).filter(Boolean) as StoryItem[];
    return { mine: myItems, others: otherItems };
  });

export const createStory = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { type: string; body?: string; mediaUrl?: string; music?: string; privacy?: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    rateLimit(`story:${context.userId}`, 8, 60_000);
    const media = validateMedia(data.mediaUrl ?? null, 700_000);
    const id = newId("st");
    await sql`insert into stories (id, user_id, type, media_url, body, music, privacy, expires_at)
      values (${id}, ${context.userId}, ${data.type}, ${media}, ${(data.body ?? "").slice(0, 200)},
        ${data.music ?? null}, ${data.privacy ?? "all"}, now() + interval '24 hours')`;
    await grantAchievement(sql, context.userId, "story");
    return { id };
  });

export const viewStory = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { id: string; reaction?: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`insert into story_views (story_id, viewer_id, reaction)
      values (${data.id}, ${context.userId}, ${data.reaction ?? null})
      on conflict (story_id, viewer_id) do update set reaction = coalesce(${data.reaction ?? null}, story_views.reaction)`;
    return { ok: true };
  });

export const storyViewers = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { id: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const st = await sql<{ user_id: string }>`select user_id from stories where id = ${data.id}`;
    if (!st[0] || st[0].user_id !== context.userId) throw new Error("Forbidden");
    const rows = await sql<{ viewer_id: string; reaction: string | null }>`
      select viewer_id, reaction from story_views where story_id = ${data.id}`;
    const people: { profile: Profile; reaction: string | null }[] = [];
    for (const r of rows) {
      const p = await loadProfile(sql, r.viewer_id);
      if (p) people.push({ profile: p, reaction: r.reaction });
    }
    return people;
  });

export const getWallet = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<{ wallet: Wallet; txs: StarTx[] }> => {
    const sql = await getSql();
    const w = await sql<{ balance: number | string }>`select balance from stars_wallets where user_id = ${context.userId}`;
    const today = new Date().toISOString().slice(0, 10);
    const claimed = await sql`select 1 from daily_bonuses where user_id = ${context.userId} and day = ${today}::date`;
    const txs = await sql<Record<string, unknown>>`
      select * from star_transactions
      where from_user = ${context.userId} or to_user = ${context.userId}
      order by created_at desc limit 40`;
    return {
      wallet: { balance: num(w[0]?.balance), dailyClaimed: claimed.length > 0 },
      txs: txs.map((t) => ({
        id: String(t.id),
        fromUser: t.from_user ? String(t.from_user) : null,
        toUser: t.to_user ? String(t.to_user) : null,
        amount: num(t.amount),
        kind: String(t.kind),
        memo: t.memo ? String(t.memo) : null,
        createdAt: iso(t.created_at),
      })),
    };
  });

export const sendStars = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { toUserId: string; amount: number; memo?: string; idempotencyKey: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    rateLimit(`stars:${context.userId}`, 15, 10_000);
    const amount = Math.floor(Number(data.amount));
    if (!Number.isFinite(amount) || amount <= 0) throw new Error("Invalid amount");
    if (data.toUserId === context.userId) throw new Error("Cannot send to yourself");
    const tx = await debitStars(
      sql,
      context.userId,
      amount,
      "send",
      (data.memo ?? "Stars").slice(0, 80),
      data.idempotencyKey.slice(0, 80),
      data.toUserId,
    );
    if (!tx.duplicate) {
      const me = await loadProfile(sql, context.userId);
      await notify(sql, data.toUserId, "stars", "Stars received", `${displayName(me!)} sent you ${amount} Stars`, {
        txId: tx.id,
      });
      const chatId = await findOrCreateDm(sql, context.userId, data.toUserId);
      await sql`insert into messages (id, chat_id, sender_id, type, body, media_meta, status)
        values (${newId("msg")}, ${chatId}, ${context.userId}, ${"stars"}, ${`${amount} Stars`},
          ${JSON.stringify({ amount, txId: tx.id })}::jsonb, ${"sent"})`;
    }
    return tx;
  });

export const claimDaily = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const today = new Date().toISOString().slice(0, 10);
    const exists = await sql`select 1 from daily_bonuses where user_id = ${context.userId} and day = ${today}::date`;
    if (exists.length) throw new Error("Already claimed");
    await sql`insert into daily_bonuses (user_id, day, amount) values (${context.userId}, ${today}::date, 15)`;
    await creditStars(sql, context.userId, 15, "bonus", "Daily bonus", `daily:${context.userId}:${today}`);
    return { amount: 15 };
  });

export const listCatalog = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async () => {
    const sql = await getSql();
    const gifts = await sql<Record<string, unknown>>`select * from gifts order by cost asc`;
    const nfts = await sql<Record<string, unknown>>`
      select n.*, c.name as collection_name, o.owner_id from nfts n
      join nft_collections c on c.id = n.collection_id
      left join nft_ownership o on o.nft_id = n.id`;
    const collections = await sql<{ id: string; name: string; description: string; limited: boolean }>`
      select id, name, description, limited from nft_collections`;
    const packs = await sql<{ id: string; name: string; premium: boolean }>`select id, name, premium from sticker_packs`;
    const stickers = await sql<{ id: string; pack_id: string; emoji: string; image_key: string }>`
      select id, pack_id, emoji, image_key from stickers`;
    return {
      gifts: gifts.map(mapGift) as GiftCatalogItem[],
      nfts: nfts.map(mapNft) as NftItem[],
      collections,
      packs,
      stickers,
    };
  });

export const buyGift = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { giftId: string; toUserId: string; idempotencyKey: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    rateLimit(`gift:${context.userId}`, 20, 10_000);
    const gift = (await sql<Record<string, unknown>>`select * from gifts where id = ${data.giftId}`)[0];
    if (!gift) throw new Error("Gift not found");
    const g = mapGift(gift);
    const me = await loadProfile(sql, context.userId);
    if (g.premiumOnly && !me?.isPremium) throw new Error("Premium required");
    const tx = await debitStars(sql, context.userId, g.cost, "gift", g.name, data.idempotencyKey, null);
    if (tx.duplicate) return tx;
    const inst = newId("ug");
    await sql`insert into user_gifts (id, gift_id, owner_id, from_id)
      values (${inst}, ${g.id}, ${data.toUserId}, ${context.userId})`;
    const chatId = await findOrCreateDm(sql, context.userId, data.toUserId);
    await sql`insert into messages (id, chat_id, sender_id, type, body, media_meta, status)
      values (${newId("msg")}, ${chatId}, ${context.userId}, ${"gift"}, ${g.name},
        ${JSON.stringify({ giftId: g.id, imageKey: g.imageKey, rarity: g.rarity, inst })}::jsonb, ${"sent"})`;
    await notify(sql, data.toUserId, "gift", "New gift", `${displayName(me!)} sent ${g.name}`, { inst });
    await grantAchievement(sql, context.userId, "gifter");
    return { ...tx, instanceId: inst };
  });

export const convertGiftNft = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { instanceId: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const row = (await sql<Record<string, unknown>>`
      select ug.*, g.convertible_to_nft, g.name, g.image_key, g.rarity
      from user_gifts ug join gifts g on g.id = ug.gift_id
      where ug.id = ${data.instanceId} and ug.owner_id = ${context.userId}`)[0];
    if (!row) throw new Error("Gift not found");
    if (!row.convertible_to_nft) throw new Error("This gift cannot become an NFT");
    if (row.converted_nft_id) throw new Error("Already converted");
    const nftId = `VG-GIFT-${data.instanceId.slice(-8).toUpperCase()}`;
    await sql`insert into nfts (id, collection_id, name, description, image_key, rarity, traits)
      values (${nftId}, ${"col-glass"}, ${String(row.name)}, ${"Converted gift NFT"}, ${String(row.image_key)},
        ${String(row.rarity)}, ${JSON.stringify({ from: "gift" })}::jsonb)`;
    await sql`insert into nft_ownership (nft_id, owner_id) values (${nftId}, ${context.userId})`;
    await sql`insert into nft_history (id, nft_id, from_id, to_id) values (${newId("nh")}, ${nftId}, ${null}, ${context.userId})`;
    await sql`update user_gifts set converted_nft_id = ${nftId} where id = ${data.instanceId}`;
    return { nftId };
  });

export const transferNft = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { nftId: string; toUserId: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const own = await sql`select 1 from nft_ownership where nft_id = ${data.nftId} and owner_id = ${context.userId}`;
    if (!own.length) throw new Error("Not your NFT");
    await sql`update nft_ownership set owner_id = ${data.toUserId}, acquired_at = now() where nft_id = ${data.nftId}`;
    await sql`insert into nft_history (id, nft_id, from_id, to_id)
      values (${newId("nh")}, ${data.nftId}, ${context.userId}, ${data.toUserId})`;
    await notify(sql, data.toUserId, "nft", "NFT received", data.nftId, { nftId: data.nftId });
    return { ok: true };
  });

export const buyPremium = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { idempotencyKey: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await debitStars(sql, context.userId, 500, "premium", "Velto Premium 30d", data.idempotencyKey);
    await sql`update profiles set is_premium = true, premium_until = now() + interval '30 days' where user_id = ${context.userId}`;
    await grantAchievement(sql, context.userId, "premium");
    return { ok: true };
  });

export const listNotifications = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<NotificationItem[]> => {
    const sql = await getSql();
    const rows = await sql<Record<string, unknown>>`
      select * from notifications where user_id = ${context.userId} order by created_at desc limit 50`;
    return rows.map((r) => ({
      id: String(r.id),
      type: String(r.type),
      title: String(r.title),
      body: String(r.body),
      read: Boolean(r.read),
      createdAt: iso(r.created_at),
    }));
  });

export const markNotificationsRead = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await sql`update notifications set read = true where user_id = ${context.userId}`;
    return { ok: true };
  });

export const startCall = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { chatId?: string; calleeId?: string; kind: "audio" | "video" | "group" }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = newId("call");
    await sql`insert into calls (id, chat_id, kind, initiator_id, callee_id, status)
      values (${id}, ${data.chatId ?? null}, ${data.kind}, ${context.userId}, ${data.calleeId ?? null}, ${"ringing"})`;
    if (data.calleeId) {
      await notify(sql, data.calleeId, "call", "Incoming call", data.kind, { callId: id });
    }
    return { callId: id };
  });

export const updateCall = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { callId: string; status: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const call = (await sql<{ initiator_id: string; callee_id: string | null }>`
      select initiator_id, callee_id from calls where id = ${data.callId}`)[0];
    if (!call) throw new Error("Call not found");
    if (call.initiator_id !== context.userId && call.callee_id !== context.userId) throw new Error("Forbidden");
    await sql`update calls set status = ${data.status}, ended_at = case when ${data.status} in ('ended','missed') then now() else ended_at end
      where id = ${data.callId}`;
    return { ok: true };
  });

export const getCall = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { callId: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<Record<string, unknown>>`select * from calls where id = ${data.callId}`;
    if (!rows[0]) throw new Error("Not found");
    if (String(rows[0].initiator_id) !== context.userId && String(rows[0].callee_id) !== context.userId) {
      throw new Error("Forbidden");
    }
    return {
      id: String(rows[0].id),
      kind: String(rows[0].kind),
      status: String(rows[0].status),
      initiatorId: String(rows[0].initiator_id),
      calleeId: rows[0].callee_id ? String(rows[0].callee_id) : null,
    };
  });

export const listMyInventory = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const gifts = await sql<Record<string, unknown>>`
      select ug.*, g.name, g.description, g.image_key, g.cost, g.rarity, g.convertible_to_nft, g.premium_only, g.id as gift_def_id
      from user_gifts ug join gifts g on g.id = ug.gift_id
      where ug.owner_id = ${context.userId} order by ug.created_at desc`;
    const nfts = await sql<Record<string, unknown>>`
      select n.*, c.name as collection_name, o.owner_id from nft_ownership o
      join nfts n on n.id = o.nft_id join nft_collections c on c.id = n.collection_id
      where o.owner_id = ${context.userId}`;
    const achievements = await sql<{ key: string; unlocked_at: string }>`
      select key, unlocked_at::text as unlocked_at from achievements where user_id = ${context.userId}`;
    return {
      gifts: gifts.map((r) => ({
        id: String(r.id),
        gift: mapGift({ ...r, id: r.gift_def_id }),
        fromId: r.from_id ? String(r.from_id) : null,
        displayed: Boolean(r.displayed),
        createdAt: iso(r.created_at),
      })) as OwnedGift[],
      nfts: nfts.map(mapNft),
      achievements,
    };
  });

export const votePoll = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { messageId: string; optionIndex: number }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const poll = (await sql<{ id: string }>`select id from polls where message_id = ${data.messageId}`)[0];
    if (!poll) throw new Error("Poll not found");
    await sql`insert into poll_votes (poll_id, user_id, option_index)
      values (${poll.id}, ${context.userId}, ${data.optionIndex})
      on conflict (poll_id, user_id) do update set option_index = ${data.optionIndex}`;
    return { ok: true };
  });

export const ownerStats = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await requireOwner(sql, context.userId);
    const users = await sql<{ n: number }>`select count(*)::int as n from profiles where is_bot = false`;
    const online = await sql<{ n: number }>`select count(*)::int as n from profiles where is_bot = false and last_seen > now() - interval '45 seconds'`;
    const messages = await sql<{ n: number }>`select count(*)::int as n from messages`;
    const groups = await sql<{ n: number }>`select count(*)::int as n from chats where type = 'group'`;
    const channels = await sql<{ n: number }>`select count(*)::int as n from chats where type = 'channel'`;
    const stories = await sql<{ n: number }>`select count(*)::int as n from stories`;
    const calls = await sql<{ n: number }>`select count(*)::int as n from calls`;
    const starsIssued = await sql<{ n: number | string }>`select coalesce(sum(amount),0) as n from star_transactions where kind in ('grant','bonus','owner')`;
    const starsCirculating = await sql<{ n: number | string }>`select coalesce(sum(balance),0) as n from stars_wallets`;
    const gifts = await sql<{ n: number }>`select count(*)::int as n from user_gifts`;
    const nfts = await sql<{ n: number }>`select count(*)::int as n from nft_ownership`;
    const premium = await sql<{ n: number }>`select count(*)::int as n from profiles where is_premium = true`;
    const actions = await sql<Record<string, unknown>>`select * from owner_actions order by created_at desc limit 30`;
    const people = await sql<Record<string, unknown>>`select * from profiles where is_bot = false order by created_at desc limit 40`;
    return {
      users: num(users[0]?.n),
      online: num(online[0]?.n),
      messages: num(messages[0]?.n),
      groups: num(groups[0]?.n),
      channels: num(channels[0]?.n),
      stories: num(stories[0]?.n),
      calls: num(calls[0]?.n),
      starsIssued: num(starsIssued[0]?.n),
      starsCirculating: num(starsCirculating[0]?.n),
      gifts: num(gifts[0]?.n),
      nfts: num(nfts[0]?.n),
      premium: num(premium[0]?.n),
      actions: actions.map((a) => ({
        id: String(a.id),
        command: String(a.command),
        createdAt: iso(a.created_at),
      })),
      people: people.map((p) => mapProfile(p)),
    };
  });

export const ownerCommand = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { command: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const reply = await runOwnerCommand(sql, context.userId, data.command);
    return { reply };
  });

export const ownerModerate = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { userId: string; action: "block" | "unblock" | "verify" }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await requireOwner(sql, context.userId);
    if (data.action === "block") {
      await sql`insert into blocks (user_id, blocked_id) values (${context.userId}, ${data.userId}) on conflict do nothing`;
    } else if (data.action === "unblock") {
      await sql`delete from blocks where user_id = ${context.userId} and blocked_id = ${data.userId}`;
    } else {
      await sql`update profiles set is_verified = true where user_id = ${data.userId}`;
    }
    await sql`insert into owner_actions (id, actor_id, command, payload)
      values (${newId("oa")}, ${context.userId}, ${data.action}, ${JSON.stringify({ userId: data.userId })}::jsonb)`;
    return { ok: true };
  });

export const listActivity = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<Record<string, unknown>>`
      select * from star_transactions
      where from_user = ${context.userId} or to_user = ${context.userId}
      order by created_at desc limit 20`;
    return rows.map((t) => ({
      id: String(t.id),
      kind: String(t.kind),
      amount: num(t.amount),
      createdAt: iso(t.created_at),
    }));
  });
