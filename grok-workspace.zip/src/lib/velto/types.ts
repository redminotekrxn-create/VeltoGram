export type JsonValue = string | number | boolean | null | JsonValue[] | { [key: string]: JsonValue };

export type ChatType = "dm" | "group" | "channel" | "bot";
export type Rarity = "common" | "rare" | "epic" | "legendary" | "mythic";
export type ThemeName = "light" | "dark" | "amoled";
export type AccentName = "teal" | "ice" | "sand" | "rose";

export type Profile = {
  userId: string;
  username: string;
  firstName: string;
  lastName: string;
  phone: string | null;
  bio: string;
  avatarUrl: string | null;
  avatarFrame: string;
  profileColor: string;
  profileBg: string;
  nameStyle: string;
  emojiStatus: string | null;
  statusText: string | null;
  isBot: boolean;
  isVerified: boolean;
  isPremium: boolean;
  premiumUntil: string | null;
  isOwner: boolean;
  accountLevel: number;
  xp: number;
  lastSeen: string;
  isOnline: boolean;
  language: string;
  theme: ThemeName;
  accent: AccentName;
  createdAt: string;
};

export type ChatListItem = {
  id: string;
  type: ChatType;
  title: string;
  username: string | null;
  description: string | null;
  avatarUrl: string | null;
  isPublic: boolean;
  role: string;
  pinned: boolean;
  muted: boolean;
  unread: number;
  lastText: string | null;
  lastType: string | null;
  lastAt: string | null;
  lastSenderId: string | null;
  peer: Profile | null;
  memberCount: number;
  isOwnerBot: boolean;
};

export type Message = {
  id: string;
  chatId: string;
  senderId: string;
  type: string;
  body: string | null;
  mediaUrl: string | null;
  mediaMeta: { [key: string]: JsonValue } | null;
  replyToId: string | null;
  forwardedFrom: string | null;
  isEdited: boolean;
  isPinned: boolean;
  isSpoiler: boolean;
  views: number;
  status: string;
  createdAt: string;
  sender: Profile | null;
  reactions: { emoji: string; count: number; mine: boolean }[];
};

export type StoryItem = {
  id: string;
  userId: string;
  type: string;
  mediaUrl: string | null;
  body: string | null;
  music: string | null;
  createdAt: string;
  expiresAt: string;
  viewed: boolean;
  viewCount: number;
  profile: Profile;
};

export type GiftCatalogItem = {
  id: string;
  name: string;
  description: string;
  imageKey: string;
  cost: number;
  rarity: Rarity;
  convertibleToNft: boolean;
  premiumOnly: boolean;
};

export type OwnedGift = {
  id: string;
  gift: GiftCatalogItem;
  fromId: string | null;
  displayed: boolean;
  createdAt: string;
};

export type NftItem = {
  id: string;
  collectionId: string;
  collectionName: string;
  name: string;
  description: string;
  imageKey: string;
  rarity: Rarity;
  traits: { [key: string]: string };
  price: number | null;
  ownerId: string | null;
};

export type Wallet = {
  balance: number;
  dailyClaimed: boolean;
};

export type StarTx = {
  id: string;
  fromUser: string | null;
  toUser: string | null;
  amount: number;
  kind: string;
  memo: string | null;
  createdAt: string;
};

export type NotificationItem = {
  id: string;
  type: string;
  title: string;
  body: string;
  read: boolean;
  createdAt: string;
};

export type SessionPayload = {
  profile: Profile;
  isOwner: boolean;
  wallet: Wallet;
  needsOnboarding: boolean;
};
