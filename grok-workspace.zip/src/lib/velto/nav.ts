import { create } from "zustand";

export type Screen =
  | "chats"
  | "chat"
  | "stories"
  | "contacts"
  | "stars"
  | "profile"
  | "settings"
  | "owner"
  | "search"
  | "create"
  | "user"
  | "call"
  | "shop"
  | "nft"
  | "notifications"
  | "install"
  | "info";

type CallState = {
  id: string;
  kind: "audio" | "video" | "group";
  peerName: string;
  peerId?: string;
  inbound?: boolean;
} | null;

type Nav = {
  screen: Screen;
  chatId?: string;
  userId?: string;
  storyIndex: number;
  call: CallState;
  composerReply?: { id: string; body: string };
  go: (patch: Partial<Omit<Nav, "go" | "back">> & { screen?: Screen }) => void;
  back: () => void;
};

export const useNav = create<Nav>((set, get) => ({
  screen: "chats",
  storyIndex: 0,
  call: null,
  go: (patch) => set({ ...get(), ...patch }),
  back: () => {
    const s = get().screen;
    if (s === "chat" || s === "user" || s === "create" || s === "search") set({ screen: "chats", chatId: undefined });
    else if (s === "owner" || s === "install" || s === "info" || s === "notifications" || s === "settings")
      set({ screen: "profile" });
    else if (s === "shop" || s === "nft") set({ screen: "stars" });
    else set({ screen: "chats" });
  },
}));
