import type { Sql } from "@/lib/db";
import { iso, num, slugify } from "@/lib/utils";
import type { ChatListItem, GiftCatalogItem, Message, NftItem, Profile, Rarity, JsonValue } from "./types";

export const OWNER_ID_KEY = "OWNER_ID";
export const GUIDE_ID = "sys-velto";
export const OWNER_BOT_ID = "sys-owner-bot";
export const NEWS_CHAT = "chat-velto-news";
export const LOUNGE_CHAT = "chat-velto-lounge";

const buckets = new Map<string, { n: number; t: number }>();

export function rateLimit(key: string, max = 40, windowMs = 10_000) {
  const now = Date.now();
  const cur = buckets.get(key);
  if (!cur || now - cur.t > windowMs) {
    buckets.set(key, { n: 1, t: now });
    return;
  }
  cur.n += 1;
  if (cur.n > max) throw new Error("Too many requests. Slow down.");
}

export function newId(prefix = "vg"): string {
  return `${prefix}_${crypto.randomUUID().replace(/-/g, "").slice(0, 22)}`;
}

export function asBool(v: unknown): boolean {
  return v === true || v === "t" || v === "true";
}

export function parseJson<T>(v: unknown, fallback: T): T {
  if (v && typeof v === "object") return v as T;
  if (typeof v === "string") {
    try {
      return JSON.parse(v) as T;
    } catch {
      return fallback;
    }
  }
  return fallback;
}

export function jsonObject(v: unknown): { [key: string]: JsonValue } | null {
  const parsed = parseJson<{ [key: string]: JsonValue } | null>(v, null);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
  return parsed;
}

export function mapProfile(row: Record<string, unknown>, now = Date.now()): Profile {
  const lastSeen = iso(row.last_seen);
  const lastMs = Date.parse(lastSeen);
  return {
    userId: String(row.user_id),
    username: String(row.username),
    firstName: String(row.first_name ?? ""),
    lastName: String(row.last_name ?? ""),
    phone: row.phone ? String(row.phone) : null,
    bio: String(row.bio ?? ""),
    avatarUrl: row.avatar_url ? String(row.avatar_url) : null,
    avatarFrame: String(row.avatar_frame ?? "none"),
    profileColor: String(row.profile_color ?? "#2DD4BF"),
    profileBg: String(row.profile_bg ?? "aurora"),
    nameStyle: String(row.name_style ?? "default"),
    emojiStatus: row.emoji_status ? String(row.emoji_status) : null,
    statusText: row.status_text ? String(row.status_text) : null,
    isBot: asBool(row.is_bot),
    isVerified: asBool(row.is_verified),
    isPremium: asBool(row.is_premium),
    premiumUntil: row.premium_until ? iso(row.premium_until) : null,
    isOwner: asBool(row.is_owner),
    accountLevel: num(row.account_level) || 1,
    xp: num(row.xp),
    lastSeen,
    isOnline: Number.isFinite(lastMs) ? now - lastMs < 45_000 : false,
    language: String(row.language ?? "en"),
    theme: (row.theme as Profile["theme"]) || "dark",
    accent: (row.accent as Profile["accent"]) || "teal",
    createdAt: iso(row.created_at),
  };
}

export function displayName(p: Pick<Profile, "firstName" | "lastName" | "username">): string {
  const n = `${p.firstName} ${p.lastName}`.trim();
  return n || p.username;
}

export function mapGift(row: Record<string, unknown>): GiftCatalogItem {
  return {
    id: String(row.id),
    name: String(row.name),
    description: String(row.description),
    imageKey: String(row.image_key),
    cost: num(row.cost),
    rarity: String(row.rarity) as Rarity,
    convertibleToNft: asBool(row.convertible_to_nft),
    premiumOnly: asBool(row.premium_only),
  };
}

export function mapNft(row: Record<string, unknown>): NftItem {
  return {
    id: String(row.id),
    collectionId: String(row.collection_id),
    collectionName: String(row.collection_name ?? ""),
    name: String(row.name),
    description: String(row.description),
    imageKey: String(row.image_key),
    rarity: String(row.rarity) as Rarity,
    traits: parseJson<{ [key: string]: string }>(row.traits, {}),
    price: row.price == null ? null : num(row.price),
    ownerId: row.owner_id ? String(row.owner_id) : null,
  };
}

export function mapMessage(
  row: Record<string, unknown>,
  sender: Profile | null,
  reactions: Message["reactions"],
): Message {
  return {
    id: String(row.id),
    chatId: String(row.chat_id),
    senderId: String(row.sender_id),
    type: String(row.type),
    body: row.body ? String(row.body) : null,
    mediaUrl: row.media_url ? String(row.media_url) : null,
    mediaMeta: jsonObject(row.media_meta),
    replyToId: row.reply_to_id ? String(row.reply_to_id) : null,
    forwardedFrom: row.forwarded_from ? String(row.forwarded_from) : null,
    isEdited: asBool(row.is_edited),
    isPinned: asBool(row.is_pinned),
    isSpoiler: asBool(row.is_spoiler),
    views: num(row.views),
    status: String(row.status ?? "sent"),
    createdAt: iso(row.created_at),
    sender,
    reactions,
  };
}

export async function readOwnerId(sql: Sql): Promise<string | null> {
  const rows = await sql<{ value: string }>`select value from app_settings where key = ${OWNER_ID_KEY}`;
  return rows[0]?.value ?? null;
}

export async function requireOwner(sql: Sql, userId: string): Promise<void> {
  const owner = await readOwnerId(sql);
  if (!owner || owner !== userId) {
    throw new Error("Forbidden");
  }
}

export async function loadProfile(sql: Sql, userId: string): Promise<Profile | null> {
  const rows = await sql<Record<string, unknown>>`select * from profiles where user_id = ${userId}`;
  return rows[0] ? mapProfile(rows[0]) : null;
}

export async function uniqueUsername(sql: Sql, raw: string): Promise<string> {
  const base = slugify(raw);
  for (let i = 0; i < 30; i++) {
    const tryName = i === 0 ? base : `${base}${i + 1}`;
    const exists = await sql`select 1 from profiles where username = ${tryName} limit 1`;
    if (!exists.length) return tryName;
  }
  return `${base}_${newId("u").slice(-6)}`;
}

export async function notify(
  sql: Sql,
  userId: string,
  type: string,
  title: string,
  body: string,
  data: Record<string, unknown> = {},
) {
  if (userId.startsWith("sys-")) return;
  await sql`insert into notifications (id, user_id, type, title, body, data)
    values (${newId("nt")}, ${userId}, ${type}, ${title}, ${body}, ${JSON.stringify(data)}::jsonb)`;
}

export async function grantAchievement(sql: Sql, userId: string, key: string) {
  await sql`insert into achievements (user_id, key) values (${userId}, ${key}) on conflict do nothing`;
}

export async function addXp(sql: Sql, userId: string, amount: number) {
  await sql`update profiles set xp = xp + ${amount},
    account_level = greatest(1, least(99, 1 + ((xp + ${amount}) / 120)::int)),
    updated_at = now()
    where user_id = ${userId}`;
}

export async function creditStars(
  sql: Sql,
  toUser: string,
  amount: number,
  kind: string,
  memo: string,
  idempotencyKey: string,
  fromUser: string | null = null,
) {
  if (amount <= 0) throw new Error("Invalid amount");
  const existing = await sql`select id from star_transactions where idempotency_key = ${idempotencyKey}`;
  if (existing.length) return { duplicate: true as const, id: String(existing[0]!.id) };
  const id = newId("vtx");
  await sql`insert into star_transactions (id, from_user, to_user, amount, kind, memo, idempotency_key)
    values (${id}, ${fromUser}, ${toUser}, ${amount}, ${kind}, ${memo}, ${idempotencyKey})`;
  await sql`insert into stars_wallets (user_id, balance) values (${toUser}, ${amount})
    on conflict (user_id) do update set balance = stars_wallets.balance + ${amount}, updated_at = now()`;
  return { duplicate: false as const, id };
}

export async function debitStars(
  sql: Sql,
  fromUser: string,
  amount: number,
  kind: string,
  memo: string,
  idempotencyKey: string,
  toUser: string | null = null,
) {
  if (amount <= 0) throw new Error("Invalid amount");
  const existing = await sql`select id from star_transactions where idempotency_key = ${idempotencyKey}`;
  if (existing.length) return { duplicate: true as const, id: String(existing[0]!.id) };
  const spent = await sql<{ balance: number | string }>`
    update stars_wallets set balance = balance - ${amount}, updated_at = now()
    where user_id = ${fromUser} and balance >= ${amount}
    returning balance`;
  if (!spent.length) throw new Error("Not enough Stars");
  const id = newId("vtx");
  await sql`insert into star_transactions (id, from_user, to_user, amount, kind, memo, idempotency_key)
    values (${id}, ${fromUser}, ${toUser}, ${amount}, ${kind}, ${memo}, ${idempotencyKey})`;
  if (toUser) {
    await sql`insert into stars_wallets (user_id, balance) values (${toUser}, ${amount})
      on conflict (user_id) do update set balance = stars_wallets.balance + ${amount}, updated_at = now()`;
  }
  return { duplicate: false as const, id };
}

export async function requireMember(sql: Sql, chatId: string, userId: string) {
  const rows = await sql<{ role: string; unread_count: number }>`
    select role, unread_count from chat_members where chat_id = ${chatId} and user_id = ${userId}`;
  if (!rows.length) throw new Error("Not a member");
  return rows[0]!;
}

export async function findOrCreateDm(sql: Sql, a: string, b: string): Promise<string> {
  const [x, y] = a < b ? [a, b] : [b, a];
  const id = `dm_${x}_${y}`;
  const exists = await sql`select id from chats where id = ${id}`;
  if (!exists.length) {
    const other = await loadProfile(sql, b);
    const type = other?.isBot ? "bot" : "dm";
    await sql`insert into chats (id, type, owner_id, is_public) values (${id}, ${type}, ${a}, false)`;
    await sql`insert into chat_members (chat_id, user_id, role) values (${id}, ${a}, 'member') on conflict do nothing`;
    await sql`insert into chat_members (chat_id, user_id, role) values (${id}, ${b}, 'member') on conflict do nothing`;
  } else {
    await sql`insert into chat_members (chat_id, user_id, role) values (${id}, ${a}, 'member') on conflict do nothing`;
    await sql`insert into chat_members (chat_id, user_id, role) values (${id}, ${b}, 'member') on conflict do nothing`;
  }
  return id;
}

export function mapChatRow(
  row: Record<string, unknown>,
  peer: Profile | null,
  memberCount: number,
): ChatListItem {
  const type = String(row.type) as ChatListItem["type"];
  const title =
    type === "dm" || type === "bot"
      ? peer
        ? displayName(peer)
        : "Chat"
      : String(row.title ?? "Chat");
  return {
    id: String(row.id),
    type,
    title,
    username: row.username ? String(row.username) : peer?.username ?? null,
    description: row.description ? String(row.description) : null,
    avatarUrl: row.avatar_url ? String(row.avatar_url) : peer?.avatarUrl ?? null,
    isPublic: asBool(row.is_public),
    role: String(row.role ?? "member"),
    pinned: asBool(row.pinned),
    muted: asBool(row.muted),
    unread: num(row.unread_count),
    lastText: row.last_text ? String(row.last_text) : null,
    lastType: row.last_type ? String(row.last_type) : null,
    lastAt: row.last_at ? iso(row.last_at) : null,
    lastSenderId: row.last_sender_id ? String(row.last_sender_id) : null,
    peer,
    memberCount,
    isOwnerBot: type === "bot" && String(row.id).includes(OWNER_BOT_ID),
  };
}

export function validateMedia(dataUrl: string | null | undefined, max = 700_000) {
  if (!dataUrl) return null;
  if (dataUrl.length > max) throw new Error("File too large");
  if (!dataUrl.startsWith("data:")) throw new Error("Invalid file");
  const mime = dataUrl.slice(5, dataUrl.indexOf(";"));
  const allowed = [
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/gif",
    "audio/webm",
    "audio/mp4",
    "audio/ogg",
    "video/mp4",
    "video/webm",
    "application/pdf",
    "text/plain",
  ];
  if (!allowed.includes(mime)) throw new Error("File type not allowed");
  return dataUrl;
}

export { slugify };
