export async function fileToDataUrl(file: File, maxEdge = 960): Promise<string> {
  if (file.type.startsWith("image/") && !file.type.includes("gif")) {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas");
    ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.82);
  }
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Read failed"));
    reader.readAsDataURL(file);
  });
}

export function formatTime(isoStr: string | null | undefined, lang: string) {
  if (!isoStr) return "";
  const d = new Date(isoStr);
  if (Number.isNaN(d.getTime())) return "";
  const diff = Date.now() - d.getTime();
  if (diff < 45_000) return lang === "ru" ? "сейчас" : "now";
  if (diff < 3_600_000) return `${Math.max(1, Math.round(diff / 60000))}m`;
  if (diff < 86_400_000) {
    return d.toLocaleTimeString(lang, { hour: "2-digit", minute: "2-digit" });
  }
  return d.toLocaleDateString(lang, { month: "short", day: "numeric" });
}

export function lastSeenLabel(isoStr: string, online: boolean, lang: string, onlineWord: string, lastWord: string) {
  if (online) return onlineWord;
  return `${lastWord} ${formatTime(isoStr, lang)}`;
}
