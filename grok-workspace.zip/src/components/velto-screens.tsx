import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Bell,
  ChevronLeft,
  Download,
  Gem,
  Gift,
  Globe,
  Lock,
  Phone,
  Plus,
  Search,
  Settings,
  Shield,
  Sparkles,
  Video,
  Wallet,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Avatar, GiftArt, NftArt } from "@/components/art";
import { VeltoMark } from "@/components/logo";
import { dict, LANGS, type Lang } from "@/lib/i18n";
import { formatTime } from "@/lib/media";
import { signOut } from "@/lib/auth/client";
import { UserButton } from "@/lib/auth/gates";
import { useNav } from "@/lib/velto/nav";
import {
  addContact,
  blockUser,
  buyGift,
  buyPremium,
  claimDaily,
  convertGiftNft,
  createGroup,
  createStory,
  getPublicProfile,
  getWallet,
  globalSearch,
  listCatalog,
  listContacts,
  listMyInventory,
  listNotifications,
  listStoriesFeed,
  markNotificationsRead,
  ownerCommand,
  ownerModerate,
  ownerStats,
  sendStars,
  startCall,
  updateProfile,
  viewStory,
} from "@/lib/velto/server";
import type { Profile, Rarity, SessionPayload } from "@/lib/velto/types";
import { cn } from "@/lib/utils";

function newKey() {
  return crypto.randomUUID();
}

export function IconBtn({
  children,
  onClick,
  label,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="glass-btn grid size-11 place-items-center rounded-full text-fg"
    >
      {children}
    </button>
  );
}

export function ScreenHeader({ title, onBack }: { title: string; onBack?: () => void }) {
  return (
    <header className="glass sticky top-0 z-20 flex items-center gap-3 px-3 py-3">
      {onBack && (
        <button type="button" onClick={onBack} className="grid size-11 place-items-center rounded-full" aria-label="Back">
          <ChevronLeft className="size-5" />
        </button>
      )}
      <h1 className="font-display text-lg font-semibold tracking-tight">{title}</h1>
    </header>
  );
}

export function SearchScreen({ lang }: { lang: Lang }) {
  const d = dict(lang);
  const nav = useNav();
  const [q, setQ] = useState("");
  const { data } = useQuery({
    queryKey: ["search", q],
    queryFn: () => globalSearch({ data: { q } }),
    enabled: q.trim().length > 0,
  });
  return (
    <div className="flex h-full flex-col">
      <ScreenHeader title={d.search} onBack={() => nav.back()} />
      <div className="p-3">
        <div className="glass flex h-12 items-center gap-2 rounded-full px-4">
          <Search className="size-4 text-muted" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={d.search}
            className="h-full flex-1 bg-transparent outline-none"
          />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-3 pb-24">
        {!data && <p className="px-2 py-6 text-sm text-muted">{d.noResults}</p>}
        {data && (
          <div className="flex flex-col gap-5">
            {data.users.length > 0 && (
              <section>
                <h2 className="mb-2 px-1 text-xs font-medium tracking-wide text-subtle uppercase">{d.users}</h2>
                {data.users.map((u) => (
                  <button
                    key={u.userId}
                    type="button"
                    className="flex w-full items-center gap-3 rounded-[18px] px-2 py-2 hover:bg-fg/5"
                    onClick={() => nav.go({ screen: "user", userId: u.userId })}
                  >
                    <Avatar name={u.firstName || u.username} url={u.avatarUrl} color={u.profileColor} online={u.isOnline} />
                    <div className="text-left">
                      <p className="font-medium">
                        {u.firstName} {u.lastName}
                      </p>
                      <p className="text-sm text-muted">@{u.username}</p>
                    </div>
                  </button>
                ))}
              </section>
            )}
            {data.chats.length > 0 && (
              <section>
                <h2 className="mb-2 px-1 text-xs font-medium tracking-wide text-subtle uppercase">{d.chats}</h2>
                {data.chats.map((c) => (
                  <p key={String(c.id)} className="px-2 py-2 text-sm">
                    {String(c.title)} {c.username ? `@${String(c.username)}` : ""}
                  </p>
                ))}
              </section>
            )}
            {data.gifts.length > 0 && (
              <section className="grid grid-cols-3 gap-2">
                {data.gifts.map((g) => (
                  <GiftArt key={g.id} imageKey={g.imageKey} rarity={g.rarity} />
                ))}
              </section>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export function ContactsScreen({ lang }: { lang: Lang }) {
  const d = dict(lang);
  const nav = useNav();
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["contacts"], queryFn: () => listContacts() });
  return (
    <div className="flex h-full flex-col">
      <header className="px-5 pt-6 pb-3">
        <h1 className="font-display text-2xl font-semibold tracking-tight">{d.contacts}</h1>
      </header>
      <div className="flex-1 overflow-y-auto px-3 pb-28">
        <p className="px-2 pt-2 pb-1 text-xs tracking-wide text-subtle uppercase">{d.suggested}</p>
        {(data?.suggested ?? []).map((u) => (
          <PersonRow key={u.userId} u={u} onOpen={() => nav.go({ screen: "user", userId: u.userId })} />
        ))}
        <p className="px-2 pt-4 pb-1 text-xs tracking-wide text-subtle uppercase">{d.contacts}</p>
        {(data?.contacts ?? []).length === 0 && <p className="px-2 py-4 text-sm text-muted">{d.emptyContacts}</p>}
        {(data?.contacts ?? []).map((u) => (
          <PersonRow
            key={u.userId}
            u={u}
            onOpen={() => nav.go({ screen: "user", userId: u.userId })}
            onAdd={async () => {
              await addContact({ data: { userId: u.userId } });
              qc.invalidateQueries({ queryKey: ["contacts"] });
            }}
          />
        ))}
      </div>
    </div>
  );
}

function PersonRow({ u, onOpen, onAdd }: { u: Profile; onOpen: () => void; onAdd?: () => void }) {
  return (
    <div className="flex items-center gap-3 rounded-[18px] px-2 py-2">
      <button type="button" className="flex min-w-0 flex-1 items-center gap-3" onClick={onOpen}>
        <Avatar name={u.firstName || u.username} url={u.avatarUrl} color={u.profileColor} frame={u.avatarFrame} online={u.isOnline} />
        <div className="min-w-0 text-left">
          <p className="truncate font-medium">
            {u.firstName} {u.lastName} {u.isVerified && <span className="text-accent">✓</span>}
          </p>
          <p className="truncate text-sm text-muted">@{u.username}</p>
        </div>
      </button>
      {onAdd && (
        <button type="button" onClick={onAdd} className="glass-btn rounded-full px-3 py-2 text-xs">
          +
        </button>
      )}
    </div>
  );
}

export function UserScreen({ lang, me }: { lang: Lang; me: SessionPayload }) {
  const d = dict(lang);
  const nav = useNav();
  const userId = nav.userId ?? "";
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["user", userId],
    queryFn: () => getPublicProfile({ data: { userId } }),
    enabled: Boolean(userId),
  });
  const [tab, setTab] = useState<"gifts" | "nft">("gifts");
  if (!data) return <div className="p-8 text-sm text-muted">…</div>;
  const p = data.profile;
  return (
    <div className="flex h-full flex-col overflow-y-auto pb-28">
      <ScreenHeader title={p.username} onBack={() => nav.back()} />
      <div className="relative mx-4 mt-2 overflow-hidden rounded-[28px] p-6">
        <div
          className="absolute inset-0 opacity-80"
          style={{
            background:
              p.profileBg === "ink"
                ? "radial-gradient(circle at 20% 0%, #134e4a, #07080c 70%)"
                : "radial-gradient(circle at 20% 0%, color-mix(in oklab, var(--vg-accent) 45%, transparent), var(--vg-bg-elevated) 70%)",
          }}
        />
        <div className="relative flex flex-col items-center gap-3 text-center">
          <Avatar name={p.firstName || p.username} url={p.avatarUrl} color={p.profileColor} frame={p.avatarFrame} size={92} online={p.isOnline} />
          <div>
            <h2 className={cn("font-display text-2xl font-semibold", p.nameStyle === "wide" && "tracking-[0.18em]")}>
              {p.firstName} {p.lastName}
            </h2>
            <p className="text-sm text-muted">
              @{p.username} {p.isVerified ? "· verified" : ""} {p.isPremium ? "· Premium" : ""}
            </p>
          </div>
          {p.bio && <p className="max-w-sm text-sm text-fg/80">{p.bio}</p>}
          <p className="text-xs text-subtle">
            {d.level} {p.accountLevel} · {p.xp} XP
          </p>
          {!data.isMe && (
            <div className="mt-2 flex flex-wrap justify-center gap-2">
              <button
                type="button"
                className="accent-btn rounded-full px-4 py-2 text-sm font-medium"
                onClick={() => nav.go({ screen: "chat", chatId: undefined, userId: p.userId })}
              >
                {d.write}
              </button>
              <IconBtn label={d.call} onClick={async () => {
                const c = await startCall({ data: { calleeId: p.userId, kind: "audio" } });
                nav.go({ screen: "call", call: { id: c.callId, kind: "audio", peerName: p.firstName, peerId: p.userId } });
              }}>
                <Phone className="size-4" />
              </IconBtn>
              <IconBtn label={d.videoCall} onClick={async () => {
                const c = await startCall({ data: { calleeId: p.userId, kind: "video" } });
                nav.go({ screen: "call", call: { id: c.callId, kind: "video", peerName: p.firstName, peerId: p.userId } });
              }}>
                <Video className="size-4" />
              </IconBtn>
              <button
                type="button"
                className="glass-btn rounded-full px-4 py-2 text-sm"
                onClick={() => addContact({ data: { userId: p.userId } })}
              >
                {d.addContact}
              </button>
            </div>
          )}
        </div>
      </div>
      <div className="mx-4 mt-4 flex gap-1 rounded-[16px] bg-fg/5 p-1">
        <button type="button" className={cn("flex-1 rounded-[12px] py-2 text-sm", tab === "gifts" && "accent-btn")} onClick={() => setTab("gifts")}>
          {d.gifts}
        </button>
        <button type="button" className={cn("flex-1 rounded-[12px] py-2 text-sm", tab === "nft" && "accent-btn")} onClick={() => setTab("nft")}>
          {d.nft}
        </button>
      </div>
      {tab === "gifts" && (
        <div className="mt-3 grid grid-cols-3 gap-2 px-4">
          {data.gifts.map((g) => (
            <GiftArt key={g.id} imageKey={g.gift.imageKey} rarity={g.gift.rarity} />
          ))}
        </div>
      )}
      {tab === "nft" && (
        <div className="mt-3 grid grid-cols-2 gap-3 px-4">
          {data.nfts.map((n) => (
            <NftArt key={n.id} imageKey={n.imageKey} rarity={n.rarity} className="h-36" />
          ))}
        </div>
      )}
      {!data.isMe && (
        <button
          type="button"
          className="mx-4 mt-6 text-sm text-danger"
          onClick={async () => {
            await blockUser({ data: { userId: p.userId, block: true } });
            qc.invalidateQueries({ queryKey: ["chats"] });
            nav.go({ screen: "chats" });
          }}
        >
          {d.blocked}
        </button>
      )}
      {me.isOwner && !data.isMe && (
        <button
          type="button"
          className="mx-4 mt-2 text-sm text-accent"
          onClick={() => ownerModerate({ data: { userId: p.userId, action: "verify" } })}
        >
          Verify
        </button>
      )}
    </div>
  );
}

export function StoriesScreen({ lang, me }: { lang: Lang; me: SessionPayload }) {
  const d = dict(lang);
  const { data, refetch } = useQuery({ queryKey: ["stories"], queryFn: () => listStoriesFeed(), refetchInterval: 8000 });
  const [viewer, setViewer] = useState<{ ids: string[]; i: number } | null>(null);
  const [draft, setDraft] = useState("");
  const all = [...(data?.mine ?? []), ...(data?.others ?? [])];
  const grouped = useMemo(() => {
    const map = new Map<string, typeof all>();
    for (const s of all) {
      const arr = map.get(s.userId) ?? [];
      arr.push(s);
      map.set(s.userId, arr);
    }
    return [...map.entries()];
  }, [all]);

  const current = viewer ? all.find((s) => s.id === viewer.ids[viewer.i]) : null;

  return (
    <div className="flex h-full flex-col">
      <header className="px-5 pt-6 pb-3">
        <h1 className="font-display text-2xl font-semibold">{d.stories}</h1>
      </header>
      <div className="flex gap-3 overflow-x-auto px-4 pb-3 no-scrollbar">
        <button
          type="button"
          className="flex w-16 shrink-0 flex-col items-center gap-1"
          onClick={async () => {
            const text = draft || "Hello from VeltoGram";
            await createStory({ data: { type: "text", body: text } });
            setDraft("");
            refetch();
          }}
        >
          <div className="grid size-16 place-items-center rounded-full border border-dashed border-accent text-accent">
            <Plus className="size-5" />
          </div>
          <span className="text-[11px] text-muted">{d.createStory}</span>
        </button>
        {grouped.map(([uid, items]) => {
          const first = items[0]!;
          return (
            <button
              key={uid}
              type="button"
              className="flex w-16 shrink-0 flex-col items-center gap-1"
              onClick={() => setViewer({ ids: items.map((x) => x.id), i: 0 })}
            >
              <div className={cn("rounded-full p-0.5", items.every((x) => x.viewed) ? "bg-fg/15" : "bg-linear-to-br from-accent to-star")}>
                <Avatar name={first.profile.firstName || first.profile.username} url={first.profile.avatarUrl} color={first.profile.profileColor} size={60} />
              </div>
              <span className="w-full truncate text-[11px] text-muted">{uid === me.profile.userId ? "You" : first.profile.firstName}</span>
            </button>
          );
        })}
      </div>
      <div className="px-4">
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={d.textStory}
          className="glass h-24 w-full resize-none rounded-[20px] p-3 outline-none"
        />
      </div>
      {current && (
        <div className="fixed inset-0 z-50 flex flex-col bg-black/90" onClick={() => setViewer(null)}>
          <div className="h-1 w-full bg-white/20">
            <div className="h-full bg-accent" style={{ width: `${((viewer!.i + 1) / viewer!.ids.length) * 100}%` }} />
          </div>
          <div className="flex flex-1 flex-col items-center justify-center p-6 text-center">
            {current.mediaUrl ? (
              <img src={current.mediaUrl} alt="" className="max-h-[70vh] rounded-[24px]" />
            ) : (
              <p className="font-display text-3xl font-semibold text-white">{current.body}</p>
            )}
            <p className="mt-4 text-sm text-white/70">{current.profile.firstName}</p>
          </div>
          <div className="flex justify-center gap-3 p-4">
            {["✦", "♡", "★"].map((e) => (
              <button
                key={e}
                type="button"
                className="glass-btn rounded-full px-4 py-2 text-white"
                onClick={async (ev) => {
                  ev.stopPropagation();
                  await viewStory({ data: { id: current.id, reaction: e } });
                }}
              >
                {e}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export function StarsScreen({ lang }: { lang: Lang }) {
  const d = dict(lang);
  const nav = useNav();
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["wallet"], queryFn: () => getWallet(), refetchInterval: 6000 });
  const { data: catalog } = useQuery({ queryKey: ["catalog"], queryFn: () => listCatalog() });
  const { data: inv } = useQuery({ queryKey: ["inventory"], queryFn: () => listMyInventory() });
  const [tab, setTab] = useState<"wallet" | "gifts" | "nft">("wallet");
  const claim = useMutation({
    mutationFn: () => claimDaily(),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["wallet"] }),
  });
  const premium = useMutation({
    mutationFn: () => buyPremium({ data: { idempotencyKey: newKey() } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["wallet"] });
      qc.invalidateQueries({ queryKey: ["session"] });
    },
  });

  return (
    <div className="flex h-full flex-col overflow-y-auto pb-28">
      <header className="px-5 pt-6 pb-3">
        <h1 className="font-display text-2xl font-semibold">{d.wallet}</h1>
      </header>
      <div className="mx-4 glass-strong rounded-[28px] p-5">
        <p className="text-sm text-muted">{d.balance}</p>
        <p className="mt-1 font-display text-4xl font-semibold tracking-tight text-star">{data?.wallet.balance ?? 0}</p>
        <p className="text-xs text-subtle">Velto Stars</p>
        <div className="mt-4 flex gap-2">
          <button
            type="button"
            disabled={data?.wallet.dailyClaimed || claim.isPending}
            onClick={() => claim.mutate()}
            className="accent-btn flex-1 rounded-full py-2.5 text-sm font-medium disabled:opacity-40"
          >
            {data?.wallet.dailyClaimed ? d.claimed : d.claimDaily}
          </button>
          <button type="button" onClick={() => premium.mutate()} className="glass-btn flex-1 rounded-full py-2.5 text-sm">
            {d.buyPremium}
          </button>
        </div>
      </div>
      <div className="mx-4 mt-4 flex gap-1 rounded-[16px] bg-fg/5 p-1">
        {(["wallet", "gifts", "nft"] as const).map((k) => (
          <button key={k} type="button" className={cn("flex-1 rounded-[12px] py-2 text-sm", tab === k && "accent-btn")} onClick={() => setTab(k)}>
            {k === "wallet" ? d.history : k === "gifts" ? d.gifts : d.nft}
          </button>
        ))}
      </div>
      {tab === "wallet" && (
        <ul className="mt-3 space-y-1 px-4">
          {(data?.txs ?? []).map((tx) => (
            <li key={tx.id} className="flex items-center justify-between rounded-[16px] px-3 py-3">
              <div>
                <p className="text-sm font-medium">{tx.kind}</p>
                <p className="text-xs text-subtle">{formatTime(tx.createdAt, lang)} · {tx.id.slice(0, 14)}</p>
              </div>
              <span className="font-medium text-star">{tx.amount}</span>
            </li>
          ))}
        </ul>
      )}
      {tab === "gifts" && (
        <div className="mt-3 grid grid-cols-2 gap-3 px-4">
          {(catalog?.gifts ?? []).map((g) => (
            <div key={g.id} className="glass rounded-[24px] p-3">
              <GiftArt imageKey={g.imageKey} rarity={g.rarity} />
              <p className="mt-2 font-medium">{g.name}</p>
              <p className="text-xs text-muted">{d[g.rarity as keyof typeof d] ?? g.rarity} · {g.cost} ★</p>
            </div>
          ))}
        </div>
      )}
      {tab === "nft" && (
        <div className="mt-3 grid grid-cols-2 gap-3 px-4">
          {(catalog?.nfts ?? []).map((n) => (
            <div key={n.id} className="glass rounded-[24px] p-3">
              <NftArt imageKey={n.imageKey} rarity={n.rarity} className="h-32" />
              <p className="mt-2 text-sm font-medium">{n.name}</p>
              <p className="text-[11px] text-subtle">{n.id}</p>
            </div>
          ))}
        </div>
      )}
      {(inv?.gifts.length ?? 0) > 0 && (
        <div className="px-4 pt-4">
          <h3 className="mb-2 text-sm text-muted">{d.collection}</h3>
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {inv!.gifts.map((g) => (
              <button
                key={g.id}
                type="button"
                className="w-20 shrink-0"
                onClick={() => g.gift.convertibleToNft && convertGiftNft({ data: { instanceId: g.id } }).then(() => qc.invalidateQueries({ queryKey: ["inventory"] }))}
              >
                <GiftArt imageKey={g.gift.imageKey} rarity={g.gift.rarity} />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export function ProfileScreen({ lang, session, setLang }: { lang: Lang; session: SessionPayload; setLang: (l: Lang) => void }) {
  const d = dict(lang);
  const nav = useNav();
  const p = session.profile;
  const qc = useQueryClient();
  const { data: notes } = useQuery({ queryKey: ["notes"], queryFn: () => listNotifications(), refetchInterval: 8000 });
  return (
    <div className="flex h-full flex-col overflow-y-auto pb-28">
      <header className="flex items-center justify-between px-5 pt-6 pb-3">
        <h1 className="font-display text-2xl font-semibold">{d.profile}</h1>
        <IconBtn label={d.settings} onClick={() => nav.go({ screen: "settings" })}>
          <Settings className="size-5" />
        </IconBtn>
      </header>
      <button type="button" className="mx-4 glass flex items-center gap-4 rounded-[24px] p-4 text-left" onClick={() => nav.go({ screen: "user", userId: p.userId })}>
        <Avatar name={p.firstName || p.username} url={p.avatarUrl} color={p.profileColor} frame={p.avatarFrame} size={64} />
        <div className="min-w-0">
          <p className="font-display text-lg font-semibold">
            {p.firstName} {p.lastName}
          </p>
          <p className="text-sm text-muted">@{p.username}</p>
          <p className="text-xs text-subtle">
            {d.level} {p.accountLevel} {p.isPremium ? "· Premium" : ""} {session.isOwner ? "· Owner" : ""}
          </p>
        </div>
      </button>
      <div className="mt-4 grid grid-cols-2 gap-2 px-4">
        <QuickTile icon={<Wallet className="size-4" />} label={d.wallet} onClick={() => nav.go({ screen: "stars" })} />
        <QuickTile icon={<Gift className="size-4" />} label={d.gifts} onClick={() => nav.go({ screen: "stars" })} />
        <QuickTile icon={<Gem className="size-4" />} label={d.nft} onClick={() => nav.go({ screen: "stars" })} />
        <QuickTile icon={<Bell className="size-4" />} label={d.notifications} onClick={() => { markNotificationsRead(); nav.go({ screen: "notifications" }); }} />
        <QuickTile icon={<Download className="size-4" />} label={d.install} onClick={() => nav.go({ screen: "install" })} />
        <QuickTile icon={<Globe className="size-4" />} label={d.language} onClick={() => nav.go({ screen: "settings" })} />
        {session.isOwner && (
          <QuickTile icon={<Shield className="size-4" />} label={d.ownerPanel} onClick={() => nav.go({ screen: "owner" })} />
        )}
        <QuickTile icon={<Sparkles className="size-4" />} label={d.about} onClick={() => nav.go({ screen: "info" })} />
      </div>
      <div className="mt-6 px-5">
        <p className="mb-2 text-xs tracking-wide text-subtle uppercase">{d.language}</p>
        <div className="flex flex-wrap gap-1.5">
          {LANGS.map((l) => (
            <button
              key={l.id}
              type="button"
              onClick={() => {
                setLang(l.id);
                updateProfile({ data: { language: l.id } }).then(() => qc.invalidateQueries({ queryKey: ["session"] }));
              }}
              className={cn("rounded-full px-3 py-1.5 text-xs", lang === l.id ? "accent-btn" : "glass-btn")}
            >
              {l.label}
            </button>
          ))}
        </div>
      </div>
      <div className="mt-6 px-5">
        <UserButton />
        {(notes ?? []).filter((n) => !n.read).length > 0 && (
          <p className="mt-2 text-xs text-accent">{(notes ?? []).filter((n) => !n.read).length} new</p>
        )}
      </div>
    </div>
  );
}

function QuickTile({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="glass flex items-center gap-2 rounded-[20px] px-3 py-3 text-left text-sm">
      {icon}
      <span>{label}</span>
    </button>
  );
}

export function SettingsScreen({ lang, session }: { lang: Lang; session: SessionPayload }) {
  const d = dict(lang);
  const nav = useNav();
  const qc = useQueryClient();
  const p = session.profile;
  const [form, setForm] = useState({
    firstName: p.firstName,
    lastName: p.lastName,
    username: p.username,
    bio: p.bio,
    phone: p.phone ?? "",
    statusText: p.statusText ?? "",
  });
  return (
    <div className="flex h-full flex-col overflow-y-auto pb-28">
      <ScreenHeader title={d.settings} onBack={() => nav.back()} />
      <form
        className="flex flex-col gap-3 px-4 pt-3"
        onSubmit={async (e) => {
          e.preventDefault();
          await updateProfile({ data: form });
          qc.invalidateQueries({ queryKey: ["session"] });
          nav.go({ screen: "profile" });
        }}
      >
        {(["firstName", "lastName", "username", "phone", "bio", "statusText"] as const).map((k) => (
          <label key={k} className="text-xs text-muted">
            {d[k] ?? k}
            <input
              value={form[k]}
              onChange={(e) => setForm({ ...form, [k]: e.target.value })}
              className="glass mt-1 h-12 w-full rounded-[16px] px-3 text-sm text-fg outline-none"
            />
          </label>
        ))}
        <p className="text-xs tracking-wide text-subtle uppercase">{d.theme}</p>
        <div className="flex gap-2">
          {(["dark", "light", "amoled"] as const).map((th) => (
            <button
              key={th}
              type="button"
              className={cn("glass-btn flex-1 rounded-full py-2 text-sm", p.theme === th && "accent-btn")}
              onClick={() => updateProfile({ data: { theme: th } }).then(() => qc.invalidateQueries({ queryKey: ["session"] }))}
            >
              {d[th]}
            </button>
          ))}
        </div>
        <p className="text-xs tracking-wide text-subtle uppercase">{d.accent}</p>
        <div className="flex gap-2">
          {(["teal", "ice", "sand", "rose"] as const).map((a) => (
            <button
              key={a}
              type="button"
              className={cn("h-10 flex-1 rounded-full", p.accent === a ? "ring-2 ring-fg" : "")}
              style={{ background: a === "teal" ? "#2dd4bf" : a === "ice" ? "#7dd3fc" : a === "sand" ? "#e8c36a" : "#fb7185" }}
              onClick={() => updateProfile({ data: { accent: a } }).then(() => qc.invalidateQueries({ queryKey: ["session"] }))}
            />
          ))}
        </div>
        <button type="submit" className="accent-btn mt-2 h-12 rounded-[16px] font-medium">
          {d.save}
        </button>
        <button type="button" className="h-12 text-sm text-danger" onClick={() => signOut("/login")}>
          {d.signOut}
        </button>
      </form>
    </div>
  );
}

export function OwnerScreen({ lang }: { lang: Lang }) {
  const d = dict(lang);
  const nav = useNav();
  const { data, refetch } = useQuery({ queryKey: ["owner"], queryFn: () => ownerStats() });
  const [cmd, setCmd] = useState("/stats");
  const [out, setOut] = useState("");
  if (!data) return <div className="p-6 text-sm text-muted">…</div>;
  const cards = [
    [d.users, data.users],
    [d.online, data.online],
    [d.chats, data.messages],
    [d.groups, data.groups],
    [d.channels, data.channels],
    [d.stories, data.stories],
    [d.stars, data.starsCirculating],
    [d.gifts, data.gifts],
    [d.nft, data.nfts],
    [d.premium, data.premium],
  ];
  return (
    <div className="flex h-full flex-col overflow-y-auto pb-28">
      <ScreenHeader title={d.ownerPanel} onBack={() => nav.back()} />
      <div className="grid grid-cols-2 gap-2 px-4 pt-2">
        {cards.map(([k, v]) => (
          <div key={String(k)} className="glass rounded-[20px] p-3">
            <p className="text-xs text-muted">{k}</p>
            <p className="font-display text-xl font-semibold">{v}</p>
          </div>
        ))}
      </div>
      <form
        className="mt-4 flex gap-2 px-4"
        onSubmit={async (e) => {
          e.preventDefault();
          const r = await ownerCommand({ data: { command: cmd } });
          setOut(r.reply);
          refetch();
        }}
      >
        <input value={cmd} onChange={(e) => setCmd(e.target.value)} className="glass h-11 flex-1 rounded-full px-4 text-sm outline-none" />
        <button type="submit" className="accent-btn rounded-full px-4 text-sm">
          {d.grant}
        </button>
      </form>
      {out && <pre className="mx-4 mt-3 whitespace-pre-wrap rounded-[16px] bg-fg/5 p-3 text-xs">{out}</pre>}
      <ul className="mt-4 px-4">
        {data.people.map((p) => (
          <li key={p.userId} className="flex items-center justify-between py-2">
            <button type="button" className="text-left" onClick={() => nav.go({ screen: "user", userId: p.userId })}>
              <p className="text-sm font-medium">
                {p.firstName} @{p.username}
              </p>
              <p className="text-xs text-subtle">{p.userId.slice(0, 16)}</p>
            </button>
            <button type="button" className="text-xs text-accent" onClick={() => ownerModerate({ data: { userId: p.userId, action: "verify" } })}>
              {d.verified}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function CreateScreen({ lang }: { lang: Lang }) {
  const d = dict(lang);
  const nav = useNav();
  const qc = useQueryClient();
  const [mode, setMode] = useState<"group" | "channel">("group");
  const [title, setTitle] = useState("");
  const [username, setUsername] = useState("");
  const [description, setDescription] = useState("");
  const [isPublic, setIsPublic] = useState(true);
  return (
    <div className="flex h-full flex-col">
      <ScreenHeader title={mode === "group" ? d.newGroup : d.newChannel} onBack={() => nav.back()} />
      <div className="mx-4 mt-2 flex gap-1 rounded-[16px] bg-fg/5 p-1">
        <button type="button" className={cn("flex-1 rounded-[12px] py-2 text-sm", mode === "group" && "accent-btn")} onClick={() => setMode("group")}>
          {d.newGroup}
        </button>
        <button type="button" className={cn("flex-1 rounded-[12px] py-2 text-sm", mode === "channel" && "accent-btn")} onClick={() => setMode("channel")}>
          {d.newChannel}
        </button>
      </div>
      <form
        className="flex flex-col gap-3 p-4"
        onSubmit={async (e) => {
          e.preventDefault();
          const r = await createGroup({
            data: { title, username: username || undefined, description, isChannel: mode === "channel", isPublic },
          });
          qc.invalidateQueries({ queryKey: ["chats"] });
          nav.go({ screen: "chat", chatId: r.chatId });
        }}
      >
        <input required value={title} onChange={(e) => setTitle(e.target.value)} placeholder={d.firstName} className="glass h-12 rounded-[16px] px-4 outline-none" />
        <input value={username} onChange={(e) => setUsername(e.target.value)} placeholder={d.username} className="glass h-12 rounded-[16px] px-4 outline-none" />
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder={d.description} className="glass h-24 rounded-[16px] p-4 outline-none" />
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={isPublic} onChange={(e) => setIsPublic(e.target.checked)} />
          {d.publicCh}
        </label>
        <button type="submit" className="accent-btn h-12 rounded-[16px] font-medium">
          {d.create}
        </button>
      </form>
    </div>
  );
}

export function InstallScreen({ lang }: { lang: Lang }) {
  const d = dict(lang);
  const nav = useNav();
  return (
    <div className="flex h-full flex-col overflow-y-auto pb-28">
      <ScreenHeader title={d.install} onBack={() => nav.back()} />
      <div className="mx-4 mt-4 glass-strong rounded-[28px] p-6 text-center">
        <VeltoMark className="mx-auto size-16" />
        <h2 className="mt-3 font-display text-2xl font-semibold">VeltoGram</h2>
        <p className="mt-2 text-sm text-muted">{d.installHint}</p>
        <a href="/downloads/veltogram.apk" download className="accent-btn mt-5 inline-flex h-12 items-center justify-center rounded-full px-6 font-medium">
          {d.downloadApk}
        </a>
        <p className="mt-4 text-xs text-subtle">{d.addToHome}: Chrome → menu → Add to Home screen</p>
      </div>
    </div>
  );
}

export function InfoScreen({ lang }: { lang: Lang }) {
  const d = dict(lang);
  const nav = useNav();
  return (
    <div className="flex h-full flex-col overflow-y-auto px-5 pb-28">
      <ScreenHeader title={d.about} onBack={() => nav.back()} />
      <VeltoMark className="mt-4 size-14" />
      <h2 className="mt-2 font-display text-2xl font-semibold">VeltoGram 1.0</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Fast messenger with chats, groups, channels, Stories, Velto Stars, gifts, NFT collectibles, Premium, and a
        locked Owner Bot. Liquid Glass interface. Not affiliated with Telegram or Apple.
      </p>
      <h3 className="mt-6 font-medium">{d.whatsNew}</h3>
      <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-muted">
        <li>Realtime-style messaging with delivery states</li>
        <li>Stars wallet with idempotent ledger</li>
        <li>Owner Panel + Owner Bot (OWNER_ID server check)</li>
        <li>Fifteen languages, AMOLED, custom accents</li>
      </ul>
    </div>
  );
}

export function NotificationsScreen({ lang }: { lang: Lang }) {
  const d = dict(lang);
  const nav = useNav();
  const { data } = useQuery({ queryKey: ["notes"], queryFn: () => listNotifications() });
  return (
    <div className="flex h-full flex-col">
      <ScreenHeader title={d.notifications} onBack={() => nav.back()} />
      <ul className="flex-1 overflow-y-auto px-4 pb-24">
        {(data ?? []).map((n) => (
          <li key={n.id} className="border-b border-border py-3">
            <p className="text-sm font-medium">{n.title}</p>
            <p className="text-sm text-muted">{n.body}</p>
            <p className="text-xs text-subtle">{formatTime(n.createdAt, lang)}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function CallScreen() {
  const nav = useNav();
  const call = nav.call;
  const [muted, setMuted] = useState(false);
  const [cam, setCam] = useState(call?.kind !== "audio");
  const [stream, setStream] = useState<MediaStream | null>(null);

  useEffect(() => {
    if (!call || call.kind === "audio") return;
    let local: MediaStream | null = null;
    navigator.mediaDevices
      ?.getUserMedia({ video: true, audio: true })
      .then((s) => {
        local = s;
        setStream(s);
      })
      .catch(() => undefined);
    return () => local?.getTracks().forEach((t) => t.stop());
  }, [call?.id, call?.kind]);

  if (!call) return null;
  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#05070a] text-white">
      <video
        autoPlay
        muted
        ref={(el) => {
          if (el && stream) el.srcObject = stream;
        }}
        className={cn("absolute inset-0 size-full object-cover", cam ? "opacity-80" : "opacity-0")}
      />
      <div className="relative z-10 flex flex-1 flex-col items-center justify-center gap-3">
        <Avatar name={call.peerName} size={96} />
        <p className="font-display text-2xl">{call.peerName}</p>
        <p className="text-sm text-white/60">{call.kind === "video" ? "Video" : "Voice"}</p>
      </div>
      <div className="relative z-10 flex justify-center gap-4 pb-12">
        <button type="button" className="glass-btn size-14 rounded-full" onClick={() => setMuted((m) => !m)}>
          {muted ? <Lock className="mx-auto size-5" /> : <Phone className="mx-auto size-5" />}
        </button>
        <button type="button" className="glass-btn size-14 rounded-full" onClick={() => setCam((c) => !c)}>
          <Video className="mx-auto size-5" />
        </button>
        <button
          type="button"
          className="size-16 rounded-full bg-danger text-white"
          onClick={() => {
            stream?.getTracks().forEach((t) => t.stop());
            nav.go({ screen: "chats", call: null });
          }}
        >
          <Phone className="mx-auto size-6 rotate-135" />
        </button>
      </div>
    </div>
  );
}

export function GiftPicker({
  toUserId,
  onClose,
}: {
  toUserId: string;
  onClose: () => void;
}) {
  const { data } = useQuery({ queryKey: ["catalog"], queryFn: () => listCatalog() });
  const qc = useQueryClient();
  return (
    <div className="absolute inset-x-0 bottom-0 z-30 glass-strong max-h-[55%] overflow-y-auto rounded-t-[28px] p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="font-medium">Gifts</p>
        <button type="button" onClick={onClose}>
          Close
        </button>
      </div>
      <div className="grid grid-cols-3 gap-2">
        {(data?.gifts ?? []).map((g) => (
          <button
            key={g.id}
            type="button"
            className="text-left"
            onClick={async () => {
              await buyGift({ data: { giftId: g.id, toUserId, idempotencyKey: newKey() } });
              qc.invalidateQueries({ queryKey: ["wallet"] });
              qc.invalidateQueries({ queryKey: ["messages"] });
              onClose();
            }}
          >
            <GiftArt imageKey={g.imageKey} rarity={g.rarity as Rarity} />
            <p className="mt-1 truncate text-xs">{g.name}</p>
            <p className="text-[11px] text-star">{g.cost} ★</p>
          </button>
        ))}
      </div>
    </div>
  );
}

export function Onboarding({ session }: { session: SessionPayload }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({
    firstName: session.profile.firstName === "Traveler" ? "" : session.profile.firstName,
    lastName: session.profile.lastName,
    username: session.profile.username.startsWith("velto_") ? "" : session.profile.username,
  });
  const [err, setErr] = useState<string | null>(null);
  const d = dict(session.profile.language as Lang);
  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-black/50 p-5">
      <form
        className="glass-strong w-full max-w-md rounded-[28px] p-6"
        onSubmit={async (e) => {
          e.preventDefault();
          setErr(null);
          try {
            await updateProfile({ data: form });
            qc.invalidateQueries({ queryKey: ["session"] });
          } catch (ex) {
            setErr(ex instanceof Error ? ex.message : "Error");
          }
        }}
      >
        <h2 className="font-display text-xl font-semibold">{d.onboardingTitle}</h2>
        <p className="mt-1 text-sm text-muted">{d.onboardingHint}</p>
        <input className="glass mt-4 h-12 w-full rounded-[16px] px-4" placeholder={d.firstName} value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} />
        <input className="glass mt-2 h-12 w-full rounded-[16px] px-4" placeholder={d.lastName} value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} />
        <input className="glass mt-2 h-12 w-full rounded-[16px] px-4" placeholder={d.username} value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
        {err && <p className="mt-2 text-sm text-danger">{err}</p>}
        <button type="submit" className="accent-btn mt-4 h-12 w-full rounded-[16px] font-medium">
          {d.continue}
        </button>
      </form>
    </div>
  );
}

export function StarsSendSheet({ toUserId, onClose }: { toUserId: string; onClose: () => void }) {
  const [amount, setAmount] = useState("50");
  const qc = useQueryClient();
  return (
    <div className="absolute inset-x-0 bottom-0 z-30 glass-strong rounded-t-[28px] p-5">
      <p className="font-medium">Send Stars</p>
      <input value={amount} onChange={(e) => setAmount(e.target.value)} type="number" className="glass mt-3 h-12 w-full rounded-[16px] px-4" />
      <button
        type="button"
        className="accent-btn mt-3 h-12 w-full rounded-[16px]"
        onClick={async () => {
          await sendStars({ data: { toUserId, amount: Number(amount), idempotencyKey: newKey() } });
          qc.invalidateQueries({ queryKey: ["wallet"] });
          qc.invalidateQueries({ queryKey: ["messages"] });
          onClose();
        }}
      >
        Send
      </button>
    </div>
  );
}
