import { cn } from "@/lib/utils";
import type { Rarity } from "@/lib/velto/types";

const rarityTone: Record<Rarity, string> = {
  common: "from-zinc-400/30 to-zinc-600/10",
  rare: "from-teal-300/40 to-cyan-700/20",
  epic: "from-sky-300/40 to-indigo-800/20",
  legendary: "from-amber-200/50 to-orange-800/20",
  mythic: "from-rose-300/45 to-red-900/25",
};

export function GiftArt({ imageKey, rarity, className }: { imageKey: string; rarity: Rarity; className?: string }) {
  return (
    <div
      className={cn(
        "relative aspect-square overflow-hidden rounded-[22px] bg-linear-to-br",
        rarityTone[rarity],
        className,
      )}
    >
      <div className="absolute inset-0 opacity-40" style={{ background: "radial-gradient(circle at 30% 20%, white, transparent 45%)" }} />
      <svg viewBox="0 0 80 80" className="relative size-full p-3">
        {imageKey === "spark" && <path d="M40 8 L46 32 L70 40 L46 48 L40 72 L34 48 L10 40 L34 32 Z" fill="#e8c36a" />}
        {imageKey === "orb" && <circle cx="40" cy="40" r="22" fill="none" stroke="#7ee7d4" strokeWidth="3" />}
        {imageKey === "comet" && (
          <>
            <path d="M12 62 L48 26" stroke="#7ee7d4" strokeWidth="3" strokeLinecap="round" />
            <circle cx="54" cy="20" r="8" fill="#2dd4bf" />
          </>
        )}
        {imageKey === "lynx" && (
          <path d="M22 58 L28 28 L40 36 L52 28 L58 58 Z" fill="none" stroke="#9bb0ac" strokeWidth="3" />
        )}
        {imageKey === "aurora" && (
          <path d="M10 50 C25 20, 55 20, 70 50" fill="none" stroke="#5ee1b0" strokeWidth="4" />
        )}
        {imageKey === "cube" && (
          <path d="M40 14 L66 28 L40 42 L14 28 Z M14 28 L14 52 L40 66 L40 42 M66 28 L66 52 L40 66" fill="none" stroke="#7dd3fc" strokeWidth="2.5" />
        )}
        {imageKey === "phoenix" && (
          <path d="M40 66 C20 40, 24 18, 40 28 C56 18, 60 40, 40 66" fill="#fb7185" opacity="0.9" />
        )}
        {imageKey === "crown" && <path d="M16 50 L20 24 L32 40 L40 18 L48 40 L60 24 L64 50 Z" fill="#e8c36a" />}
        {imageKey === "origin" && (
          <>
            <circle cx="40" cy="40" r="18" fill="none" stroke="#e8c36a" strokeWidth="2" />
            <circle cx="40" cy="40" r="6" fill="#2dd4bf" />
          </>
        )}
        {imageKey === "eclipse" && (
          <>
            <circle cx="40" cy="40" r="20" fill="#2dd4bf" />
            <circle cx="48" cy="36" r="16" fill="#0b0d12" />
          </>
        )}
        {!["spark","orb","comet","lynx","aurora","cube","phoenix","crown","origin","eclipse"].includes(imageKey) && (
          <circle cx="40" cy="40" r="16" fill="#2dd4bf" />
        )}
      </svg>
    </div>
  );
}

export function NftArt({ imageKey, rarity, className }: { imageKey: string; rarity: Rarity; className?: string }) {
  return (
    <div className={cn("relative overflow-hidden rounded-[24px] bg-linear-to-br p-4", rarityTone[rarity], className)}>
      <svg viewBox="0 0 100 100" className="size-full">
        <rect x="8" y="8" width="84" height="84" rx="18" fill="none" stroke="currentColor" strokeOpacity="0.35" />
        {imageKey === "pulse-v" && <path d="M30 28 L50 78 L70 28" fill="none" stroke="#2dd4bf" strokeWidth="6" strokeLinecap="round" />}
        {imageKey === "relay" && <circle cx="50" cy="50" r="22" fill="none" stroke="#7ee7d4" strokeWidth="4" />}
        {imageKey === "seed" && <circle cx="50" cy="50" r="10" fill="#e8c36a" />}
        {imageKey === "lens" && <ellipse cx="50" cy="50" rx="28" ry="16" fill="none" stroke="#7dd3fc" strokeWidth="4" />}
        {imageKey === "tide" && <path d="M16 60 C36 40, 64 80, 84 50" fill="none" stroke="#2dd4bf" strokeWidth="5" />}
        {imageKey === "vein" && <path d="M20 80 L50 20 L80 80" fill="none" stroke="#e8c36a" strokeWidth="4" />}
        {imageKey === "nlynx" && <path d="M30 70 L38 34 L50 46 L62 34 L70 70 Z" fill="none" stroke="#fb7185" strokeWidth="4" />}
        {imageKey === "moth" && <path d="M50 78 L50 30 M50 44 C20 20, 20 70, 50 58 C80 70, 80 20, 50 44" fill="none" stroke="#e8c36a" strokeWidth="3" />}
      </svg>
    </div>
  );
}

export function StickerArt({ imageKey }: { imageKey: string }) {
  return (
    <svg viewBox="0 0 64 64" className="size-14">
      <circle cx="32" cy="32" r="28" fill="color-mix(in oklab, var(--vg-accent) 18%, transparent)" />
      {imageKey.includes("hello") && <path d="M20 38 Q32 48 44 38" fill="none" stroke="currentColor" strokeWidth="3" />}
      {imageKey.includes("ok") && <path d="M22 34 L30 42 L44 24" fill="none" stroke="currentColor" strokeWidth="3" />}
      {imageKey.includes("love") && <path d="M32 44 C18 34 20 22 32 28 C44 22 46 34 32 44" fill="var(--vg-accent)" />}
      {imageKey.includes("wow") && <circle cx="32" cy="38" r="6" fill="none" stroke="currentColor" strokeWidth="3" />}
      {imageKey.includes("sad") && <path d="M22 42 Q32 32 42 42" fill="none" stroke="currentColor" strokeWidth="3" />}
      {imageKey.includes("cool") && <path d="M18 30 H28 M36 30 H46" stroke="currentColor" strokeWidth="3" />}
      {imageKey.includes("fire") && <path d="M32 48 C22 36 28 22 32 18 C36 22 42 36 32 48" fill="#fb7185" />}
      {imageKey.includes("night") && <circle cx="34" cy="28" r="10" fill="#e8c36a" />}
      {imageKey.includes("ion") && <path d="M22 20 L32 48 L42 20" fill="none" stroke="#2dd4bf" strokeWidth="3" />}
      {imageKey.includes("crown") && <path d="M16 40 L20 22 L32 34 L44 22 L48 40 Z" fill="#e8c36a" />}
      <circle cx="22" cy="26" r="3" fill="currentColor" />
      <circle cx="42" cy="26" r="3" fill="currentColor" />
    </svg>
  );
}

export function Avatar({
  name,
  url,
  color,
  frame,
  size = 44,
  online,
}: {
  name: string;
  url?: string | null;
  color?: string;
  frame?: string;
  size?: number;
  online?: boolean;
}) {
  const letter = (name || "?").charAt(0).toUpperCase();
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <div
        className={cn(
          "grid size-full place-items-center overflow-hidden rounded-full font-display font-semibold",
          frame === "orbit" && "ring-2 ring-accent ring-offset-2 ring-offset-bg",
          frame === "crown" && "ring-2 ring-star ring-offset-2 ring-offset-bg",
        )}
        style={{ background: url ? undefined : color || "#2DD4BF", color: "#04221c", fontSize: size * 0.38 }}
      >
        {url ? <img src={url} alt="" className="size-full object-cover" /> : letter}
      </div>
      {online && (
        <span className="absolute right-0 bottom-0 size-2.5 rounded-full bg-success ring-2 ring-bg" />
      )}
    </div>
  );
}
