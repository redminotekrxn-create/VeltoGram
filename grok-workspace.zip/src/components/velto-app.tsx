import { QueryClient, QueryClientProvider, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Bookmark,
  Check,
  CheckCheck,
  MessageCircle,
  Mic,
  MoreVertical,
  Paperclip,
  Phone,
  Plus,
  Search,
  Send,
  Smile,
  Sparkles,
  Star,
  Users,
  Video,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Toaster, toast } from "sonner";
import { Avatar, GiftArt, StickerArt } from "@/components/art";
import { VeltoWordmark } from "@/components/logo";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { dict, isRtl, type Lang } from "@/lib/i18n";
import { fileToDataUrl, formatTime, lastSeenLabel } from "@/lib/media";
import { cn } from "@/lib/utils";
import { useNav } from "@/lib/velto/nav";
import {
  bootstrapSession,
  createDm,
  deleteMessage,
  editMessage,
  heartbeat,
  listCatalog,
  listChats,
  listMessages,
  pinChat,
  pinMessage,
  reactMessage,
  sendMessage,
  setTyping,
  startCall,
} from "@/lib/velto/server";
import type { ChatListItem, Message, SessionPayload } from "@/lib/velto/types";
import {
  CallScreen,
  ContactsScreen,
  CreateScreen,
  GiftPicker,
  InfoScreen,
  InstallScreen,
  NotificationsScreen,
  Onboarding,
  OwnerScreen,
  ProfileScreen,
  SearchScreen,
  SettingsScreen,
  StarsScreen,
  StarsSendSheet,
  StoriesScreen,
  UserScreen,
} from "./velto-screens";

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: true } },
});

export function VeltoApp() {
  return (
    <QueryClientProvider client={queryClient}>
      <Toaster theme="dark" position="top-center" />
      <Gate />
    </QueryClientProvider>
  );
}

function Gate() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <Splash />;
  if (!user) return <RedirectToSignIn />;
  return <Boot />;
}

function Splash() {
  return (
    <div className="grid min-h-dvh place-items-center">
      <div className="h-24 w-40 animate-pulse rounded-[28px] bg-fg/10" />
    </div>
  );
}

function Boot() {
  const { data, isPending, error } = useQuery({
    queryKey: ["session"],
    queryFn: () => bootstrapSession(),
    retry: 1,
  });
  if (isPending) return <Splash />;
  if (error || !data) return <RedirectToSignIn />;
  return <Shell session={data} />;
}

function Shell({ session }: { session: SessionPayload }) {
  const lang = (session.profile.language as Lang) || "en";
  const nav = useNav();
  const qc = useQueryClient();
  const [langOverride, setLangOverride] = useState<Lang | null>(null);
  const effectiveLang = langOverride ?? lang;

  useEffect(() => {
    document.documentElement.dataset.theme = session.profile.theme;
    document.documentElement.dataset.accent = session.profile.accent;
    document.documentElement.lang = effectiveLang;
    document.documentElement.dir = isRtl(effectiveLang) ? "rtl" : "ltr";
  }, [session.profile.theme, session.profile.accent, effectiveLang]);

  useEffect(() => {
    const t = window.setInterval(() => {
      heartbeat().catch(() => undefined);
    }, 20000);
    heartbeat().catch(() => undefined);
    return () => window.clearInterval(t);
  }, []);

  const { data: chats } = useQuery({
    queryKey: ["chats"],
    queryFn: () => listChats(),
    refetchInterval: 3000,
  });

  useEffect(() => {
    if (nav.screen === "chat" && !nav.chatId && nav.userId) {
      createDm({ data: { userId: nav.userId } }).then((r) => {
        nav.go({ screen: "chat", chatId: r.chatId });
        qc.invalidateQueries({ queryKey: ["chats"] });
      });
    }
  }, [nav.screen, nav.chatId, nav.userId]);

  const d = dict(effectiveLang);
  const tabs = [
    { id: "chats" as const, label: d.chats, icon: MessageCircle },
    { id: "stories" as const, label: d.stories, icon: Sparkles },
    { id: "contacts" as const, label: d.contacts, icon: Users },
    { id: "stars" as const, label: d.stars, icon: Star },
    { id: "profile" as const, label: d.profile, icon: Bookmark },
  ];

  const showNav = ["chats", "stories", "contacts", "stars", "profile"].includes(nav.screen);

  return (
    <div className="relative mx-auto flex h-dvh max-w-6xl overflow-hidden">
      <aside className={cn("hidden h-full w-[380px] shrink-0 border-r border-border md:flex md:flex-col", nav.screen === "chat" && "md:flex")}>
        <ChatList chats={chats ?? []} lang={effectiveLang} />
      </aside>
      <main className="relative flex min-w-0 flex-1 flex-col">
        <div className="flex min-h-0 flex-1 flex-col">
          {nav.screen === "chats" && (
            <div className="md:hidden h-full">
              <ChatList chats={chats ?? []} lang={effectiveLang} />
            </div>
          )}
          {nav.screen === "chats" && (
            <div className="hidden h-full md:grid place-items-center text-muted">
              <div className="text-center">
                <VeltoWordmark />
                <p className="mt-3 text-sm">{d.emptyChats}</p>
              </div>
            </div>
          )}
          {nav.screen === "chat" && nav.chatId && (
            <ChatThread session={session} chatId={nav.chatId} chats={chats ?? []} lang={effectiveLang} />
          )}
          {nav.screen === "stories" && <StoriesScreen lang={effectiveLang} me={session} />}
          {nav.screen === "contacts" && <ContactsScreen lang={effectiveLang} />}
          {nav.screen === "stars" && <StarsScreen lang={effectiveLang} />}
          {nav.screen === "profile" && (
            <ProfileScreen lang={effectiveLang} session={session} setLang={setLangOverride} />
          )}
          {nav.screen === "settings" && <SettingsScreen lang={effectiveLang} session={session} />}
          {nav.screen === "owner" && session.isOwner && <OwnerScreen lang={effectiveLang} />}
          {nav.screen === "search" && <SearchScreen lang={effectiveLang} />}
          {nav.screen === "create" && <CreateScreen lang={effectiveLang} />}
          {nav.screen === "user" && <UserScreen lang={effectiveLang} me={session} />}
          {nav.screen === "install" && <InstallScreen lang={effectiveLang} />}
          {nav.screen === "info" && <InfoScreen lang={effectiveLang} />}
          {nav.screen === "notifications" && <NotificationsScreen lang={effectiveLang} />}
        </div>
        {showNav && (
          <nav className="glass absolute inset-x-3 bottom-3 z-20 flex h-16 items-center justify-around rounded-full px-2 md:left-auto md:right-6 md:w-[380px]">
            {tabs.map((tab) => {
              const active = nav.screen === tab.id;
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => nav.go({ screen: tab.id, chatId: undefined })}
                  className={cn(
                    "flex h-12 min-w-12 flex-col items-center justify-center rounded-full px-3 text-[10px] transition-transform duration-150",
                    active ? "text-accent" : "text-muted",
                  )}
                >
                  <Icon className={cn("size-5", active && "fill-accent/20")} />
                  <span className="mt-0.5 font-medium">{tab.label}</span>
                </button>
              );
            })}
          </nav>
        )}
      </main>
      {nav.call && <CallScreen />}
      {session.needsOnboarding && <Onboarding session={session} />}
    </div>
  );
}

function ChatList({
  chats,
  lang,
}: {
  chats: ChatListItem[];
  lang: Lang;
}) {
  const d = dict(lang);
  const nav = useNav();
  const [q, setQ] = useState("");
  const filtered = chats.filter((c) => c.title.toLowerCase().includes(q.toLowerCase()) || (c.username ?? "").includes(q.toLowerCase()));
  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center justify-between gap-2 px-4 pt-5 pb-2">
        <VeltoWordmark />
        <div className="flex gap-1.5">
          <button type="button" aria-label={d.search} className="glass-btn grid size-11 place-items-center rounded-full" onClick={() => nav.go({ screen: "search" })}>
            <Search className="size-4" />
          </button>
          <button type="button" aria-label={d.newChat} className="accent-btn grid size-11 place-items-center rounded-full" onClick={() => nav.go({ screen: "create" })}>
            <Plus className="size-4" />
          </button>
        </div>
      </header>
      <StoriesStrip />
      <div className="px-4 pb-2">
        <div className="glass flex h-11 items-center gap-2 rounded-full px-3">
          <Search className="size-4 text-muted" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={d.search} className="h-full flex-1 bg-transparent text-sm outline-none" />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-2 pb-28">
        {filtered.length === 0 && <p className="px-3 py-8 text-sm text-muted">{d.emptyChats}</p>}
        {filtered.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => nav.go({ screen: "chat", chatId: c.id })}
            onContextMenu={(e) => {
              e.preventDefault();
              pinChat({ data: { chatId: c.id, pinned: !c.pinned } });
            }}
            className="flex w-full items-center gap-3 rounded-[20px] px-2 py-2.5 text-left hover:bg-fg/5"
          >
            <Avatar
              name={c.title}
              url={c.avatarUrl}
              color={c.peer?.profileColor}
              frame={c.peer?.avatarFrame}
              online={c.peer?.isOnline}
            />
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className="truncate font-medium">
                  {c.pinned ? "· " : ""}
                  {c.title}
                  {c.peer?.isVerified || c.type === "channel" ? <span className="ml-1 text-accent">✓</span> : null}
                </p>
                <span className="text-[11px] text-subtle">{formatTime(c.lastAt, lang)}</span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <p className="truncate text-sm text-muted">{preview(c, d.typeMessage)}</p>
                {c.unread > 0 && (
                  <span className="grid min-w-5 place-items-center rounded-full bg-accent px-1.5 text-[11px] font-semibold text-accent-fg">
                    {c.unread}
                  </span>
                )}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function StoriesStrip() {
  const { data } = useQuery({ queryKey: ["stories"], queryFn: () => import("@/lib/velto/server").then((m) => m.listStoriesFeed()), refetchInterval: 10000 });
  const nav = useNav();
  const others = data?.others ?? [];
  const seen = new Set<string>();
  const unique = others.filter((s) => (seen.has(s.userId) ? false : (seen.add(s.userId), true)));
  if (unique.length === 0 && (data?.mine.length ?? 0) === 0) return null;
  return (
    <div className="flex gap-3 overflow-x-auto px-4 py-2 no-scrollbar">
      <button type="button" className="flex w-14 shrink-0 flex-col items-center" onClick={() => nav.go({ screen: "stories" })}>
        <div className="grid size-12 place-items-center rounded-full bg-accent/20 text-accent">+</div>
      </button>
      {unique.slice(0, 12).map((s) => (
        <button key={s.userId} type="button" className="flex w-14 shrink-0 flex-col items-center" onClick={() => nav.go({ screen: "stories" })}>
          <div className="rounded-full bg-linear-to-br from-accent to-star p-0.5">
            <Avatar name={s.profile.firstName} url={s.profile.avatarUrl} color={s.profile.profileColor} size={44} />
          </div>
        </button>
      ))}
    </div>
  );
}

function preview(c: ChatListItem, fallback: string) {
  if (c.lastType === "gift") return "Gift";
  if (c.lastType === "stars") return "Stars";
  if (c.lastType === "voice") return "Voice";
  if (c.lastType === "sticker") return "Sticker";
  if (c.lastType === "photo") return "Photo";
  return c.lastText || fallback;
}

function ChatThread({
  session,
  chatId,
  chats,
  lang,
}: {
  session: SessionPayload;
  chatId: string;
  chats: ChatListItem[];
  lang: Lang;
}) {
  const d = dict(lang);
  const nav = useNav();
  const qc = useQueryClient();
  const chat = chats.find((c) => c.id === chatId);
  const { data } = useQuery({
    queryKey: ["messages", chatId],
    queryFn: () => listMessages({ data: { chatId } }),
    refetchInterval: 2000,
  });
  const scroller = useRef<HTMLDivElement>(null);
  const [text, setText] = useState("");
  const [menu, setMenu] = useState<Message | null>(null);
  const [gifts, setGifts] = useState(false);
  const [stars, setStars] = useState(false);
  const [stickers, setStickers] = useState(false);
  const [editing, setEditing] = useState<Message | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const { data: catalog } = useQuery({ queryKey: ["catalog"], queryFn: () => listCatalog() });

  useEffect(() => {
    const el = scroller.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [data?.messages.length]);

  const send = useMutation({
    mutationFn: (payload: Parameters<typeof sendMessage>[0]["data"]) => sendMessage({ data: payload }),
    onSuccess: () => {
      setText("");
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["messages", chatId] });
      qc.invalidateQueries({ queryKey: ["chats"] });
    },
    onError: (e) => toast.error(e.message),
  });

  const peerId = chat?.peer?.userId;

  return (
    <div className="flex h-full flex-col">
      <header className="glass flex items-center gap-2 px-2 py-2">
        <button type="button" className="grid size-11 place-items-center md:hidden" onClick={() => nav.go({ screen: "chats" })}>
          ‹
        </button>
        <button
          type="button"
          className="flex min-w-0 flex-1 items-center gap-3 px-1"
          onClick={() => peerId && nav.go({ screen: "user", userId: peerId })}
        >
          <Avatar name={chat?.title ?? "Chat"} url={chat?.avatarUrl} color={chat?.peer?.profileColor} online={chat?.peer?.isOnline} />
          <div className="min-w-0 text-left">
            <p className="truncate font-medium">{chat?.title ?? "Chat"}</p>
            <p className="truncate text-xs text-muted">
              {data?.typing[0]
                ? d.typing
                : chat?.peer
                  ? lastSeenLabel(chat.peer.lastSeen, chat.peer.isOnline, lang, d.online, d.lastSeen)
                  : chat?.type === "channel"
                    ? `${chat.memberCount} ${d.subscribers}`
                    : `${chat?.memberCount ?? 0} ${d.members}`}
            </p>
          </div>
        </button>
        {peerId && (
          <div className="flex">
            <button
              type="button"
              className="grid size-11 place-items-center"
              onClick={async () => {
                const c = await startCall({ data: { calleeId: peerId, chatId, kind: "audio" } });
                nav.go({ call: { id: c.callId, kind: "audio", peerName: chat?.title ?? "", peerId } });
              }}
            >
              <Phone className="size-4" />
            </button>
            <button
              type="button"
              className="grid size-11 place-items-center"
              onClick={async () => {
                const c = await startCall({ data: { calleeId: peerId, chatId, kind: "video" } });
                nav.go({ call: { id: c.callId, kind: "video", peerName: chat?.title ?? "", peerId } });
              }}
            >
              <Video className="size-4" />
            </button>
          </div>
        )}
        <button
          type="button"
          className="grid size-11 place-items-center"
          onClick={() => pinChat({ data: { chatId, pinned: !chat?.pinned } }).then(() => qc.invalidateQueries({ queryKey: ["chats"] }))}
        >
          <MoreVertical className="size-4" />
        </button>
      </header>

      <div ref={scroller} className="flex-1 space-y-1 overflow-y-auto px-3 py-3">
        {(data?.messages ?? []).map((m) => {
          const mine = m.senderId === session.profile.userId;
          return (
            <article
              key={m.id}
              onDoubleClick={() => reactMessage({ data: { id: m.id, emoji: "♡" } }).then(() => qc.invalidateQueries({ queryKey: ["messages", chatId] }))}
              onContextMenu={(e) => {
                e.preventDefault();
                setMenu(m);
              }}
              className={cn("flex", mine ? "justify-end" : "justify-start")}
            >
              <div
                className={cn(
                  "max-w-[80%] rounded-[22px] px-3.5 py-2.5 text-sm leading-relaxed",
                  mine ? "rounded-br-md" : "rounded-bl-md",
                )}
                style={{ background: mine ? "var(--vg-bubble-out)" : "var(--vg-bubble-in)" }}
              >
                {!mine && chat?.type !== "dm" && (
                  <p className="mb-0.5 text-xs font-medium text-accent">{m.sender?.firstName ?? m.senderId}</p>
                )}
                {m.replyToId && <p className="mb-1 border-l-2 border-accent/50 pl-2 text-xs text-muted">reply</p>}
                {m.type === "photo" && m.mediaUrl && (
                  <img src={m.mediaUrl} alt="" className="mb-1 max-h-64 rounded-[16px]" />
                )}
                {m.type === "sticker" && m.mediaMeta && (
                  <StickerArt imageKey={String((m.mediaMeta as { imageKey?: string }).imageKey ?? "face-hello")} />
                )}
                {m.type === "gift" && m.mediaMeta && (
                  <div className="w-28">
                    <GiftArt
                      imageKey={String((m.mediaMeta as { imageKey?: string }).imageKey ?? "spark")}
                      rarity={(m.mediaMeta as { rarity?: "common" }).rarity ?? "common"}
                    />
                  </div>
                )}
                {m.type === "voice" && m.mediaUrl && <audio controls src={m.mediaUrl} className="max-w-full" />}
                {m.body && <Formatted text={m.body} spoiler={m.isSpoiler} />}
                <div className="mt-1 flex items-center justify-end gap-1 text-[10px] text-subtle">
                  {m.isEdited && <span>{d.edited}</span>}
                  <span>{formatTime(m.createdAt, lang)}</span>
                  {mine && (m.status === "read" ? <CheckCheck className="size-3 text-accent" /> : <Check className="size-3" />)}
                </div>
                {m.reactions.length > 0 && (
                  <div className="mt-1 flex gap-1">
                    {m.reactions.map((r) => (
                      <span key={r.emoji} className="rounded-full bg-fg/10 px-1.5 text-[11px]">
                        {r.emoji} {r.count}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </article>
          );
        })}
      </div>

      {menu && (
        <div className="glass-strong absolute bottom-24 left-4 right-4 z-20 rounded-[24px] p-3">
          <div className="flex flex-wrap gap-2">
            {["♡", "✦", "★", "✓"].map((e) => (
              <button
                key={e}
                type="button"
                className="glass-btn rounded-full px-3 py-2"
                onClick={() => {
                  reactMessage({ data: { id: menu.id, emoji: e } }).then(() => qc.invalidateQueries({ queryKey: ["messages", chatId] }));
                  setMenu(null);
                }}
              >
                {e}
              </button>
            ))}
          </div>
          <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
            <button type="button" onClick={() => { navigator.clipboard.writeText(menu.body ?? ""); setMenu(null); }}>{d.copy}</button>
            <button type="button" onClick={() => { setEditing(menu); setText(menu.body ?? ""); setMenu(null); }}>{d.edit}</button>
            <button type="button" onClick={() => pinMessage({ data: { id: menu.id, chatId, pinned: true } }).then(() => setMenu(null))}>{d.pin}</button>
            <button type="button" className="text-danger" onClick={() => deleteMessage({ data: { id: menu.id, chatId } }).then(() => { qc.invalidateQueries({ queryKey: ["messages", chatId] }); setMenu(null); })}>{d.delete}</button>
          </div>
        </div>
      )}

      {gifts && peerId && <GiftPicker toUserId={peerId} onClose={() => setGifts(false)} />}
      {stars && peerId && <StarsSendSheet toUserId={peerId} onClose={() => setStars(false)} />}
      {stickers && (
        <div className="absolute inset-x-0 bottom-20 z-20 glass-strong max-h-56 overflow-y-auto rounded-t-[24px] p-3">
          <div className="flex flex-wrap gap-2">
            {(catalog?.stickers ?? []).map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => {
                  send.mutate({ chatId, type: "sticker", body: s.emoji, mediaMeta: { imageKey: s.image_key } });
                  setStickers(false);
                }}
              >
                <StickerArt imageKey={s.image_key} />
              </button>
            ))}
          </div>
        </div>
      )}

      <form
        className="glass m-3 flex items-end gap-2 rounded-full p-1.5"
        onSubmit={(e) => {
          e.preventDefault();
          if (editing) {
            editMessage({ data: { id: editing.id, body: text } }).then(() => {
              setEditing(null);
              setText("");
              qc.invalidateQueries({ queryKey: ["messages", chatId] });
            });
            return;
          }
          if (!text.trim()) return;
          send.mutate({ chatId, body: text, type: "text" });
        }}
      >
        <input ref={fileRef} type="file" accept="image/*,audio/*,application/pdf" className="hidden" onChange={async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          const url = await fileToDataUrl(f);
          const type = f.type.startsWith("audio") ? "voice" : f.type.startsWith("image") ? "photo" : "file";
          send.mutate({ chatId, type, mediaUrl: url, body: f.name });
        }} />
        <button type="button" className="grid size-10 place-items-center" onClick={() => fileRef.current?.click()}>
          <Paperclip className="size-4" />
        </button>
        <button type="button" className="grid size-10 place-items-center" onClick={() => setStickers((s) => !s)}>
          <Smile className="size-4" />
        </button>
        <textarea
          rows={1}
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            setTyping({ data: { chatId } }).catch(() => undefined);
          }}
          placeholder={d.typeMessage}
          className="max-h-28 min-h-10 flex-1 resize-none bg-transparent py-2.5 text-sm outline-none"
        />
        {peerId && (
          <button type="button" className="grid size-10 place-items-center text-star" onClick={() => setGifts(true)}>
            <Sparkles className="size-4" />
          </button>
        )}
        {text.trim() ? (
          <button type="submit" className="accent-btn grid size-10 place-items-center rounded-full">
            <Send className="size-4" />
          </button>
        ) : (
          <VoiceBtn onSend={(url) => send.mutate({ chatId, type: "voice", mediaUrl: url })} />
        )}
      </form>
    </div>
  );
}

function VoiceBtn({ onSend }: { onSend: (url: string) => void }) {
  const rec = useRef<MediaRecorder | null>(null);
  const [on, setOn] = useState(false);
  return (
    <button
      type="button"
      className={cn("grid size-10 place-items-center rounded-full", on && "bg-danger text-white")}
      onClick={async () => {
        if (on) {
          rec.current?.stop();
          setOn(false);
          return;
        }
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mr = new MediaRecorder(stream);
        const chunks: Blob[] = [];
        mr.ondataavailable = (e) => chunks.push(e.data);
        mr.onstop = async () => {
          stream.getTracks().forEach((t) => t.stop());
          const blob = new Blob(chunks, { type: "audio/webm" });
          const reader = new FileReader();
          reader.onload = () => onSend(String(reader.result));
          reader.readAsDataURL(blob);
        };
        rec.current = mr;
        mr.start();
        setOn(true);
      }}
    >
      <Mic className="size-4" />
    </button>
  );
}

function Formatted({ text, spoiler }: { text: string; spoiler?: boolean }) {
  const [open, setOpen] = useState(false);
  if (spoiler && !open) {
    return (
      <button type="button" className="rounded bg-fg/20 px-1" onClick={() => setOpen(true)}>
        Hidden
      </button>
    );
  }
  const parts = text.split(/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\|\|[^|]+\|\|)/g);
  return (
    <p className="whitespace-pre-wrap break-words">
      {parts.map((p, i) => {
        if (p.startsWith("**") && p.endsWith("**")) return <strong key={i}>{p.slice(2, -2)}</strong>;
        if (p.startsWith("*") && p.endsWith("*")) return <em key={i}>{p.slice(1, -1)}</em>;
        if (p.startsWith("`") && p.endsWith("`")) return <code key={i}>{p.slice(1, -1)}</code>;
        if (p.startsWith("||") && p.endsWith("||")) return <Spoiler key={i} text={p.slice(2, -2)} />;
        return <span key={i}>{p}</span>;
      })}
    </p>
  );
}

function Spoiler({ text }: { text: string }) {
  const [open, setOpen] = useState(false);
  return (
    <button type="button" className={cn(!open && "rounded bg-fg/30 text-transparent")} onClick={() => setOpen(true)}>
      {text}
    </button>
  );
}
