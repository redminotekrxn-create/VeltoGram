import { cn } from "@/lib/utils";

export function VeltoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("shrink-0", className)} aria-hidden>
      <defs>
        <linearGradient id="vg-g" x1="6" y1="4" x2="26" y2="28" gradientUnits="userSpaceOnUse">
          <stop stopColor="#7ee7d4" />
          <stop offset="1" stopColor="#2dd4bf" />
        </linearGradient>
      </defs>
      <circle cx="16" cy="16" r="13.2" fill="none" stroke="url(#vg-g)" strokeWidth="1.35" opacity="0.55" />
      <circle cx="26.2" cy="9.2" r="1.35" fill="#e8c36a" />
      <path
        d="M9 8.2 L16 23.6 L23 8.2"
        fill="none"
        stroke="url(#vg-g)"
        strokeWidth="2.55"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function VeltoWordmark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <VeltoMark className="size-8" />
      {!compact && (
        <span className="font-display text-[1.15rem] font-semibold tracking-[-0.04em] text-fg">
          Velto<span className="text-accent">Gram</span>
        </span>
      )}
    </div>
  );
}
