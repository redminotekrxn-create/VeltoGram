import { createFileRoute } from "@tanstack/react-router";
import { VeltoApp } from "@/components/velto-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <VeltoApp />;
}
