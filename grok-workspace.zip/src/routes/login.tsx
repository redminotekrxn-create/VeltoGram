import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { detectLang, dict, type Lang } from "@/lib/i18n";
import { VeltoMark } from "@/components/logo";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [lang] = useState<Lang>(detectLang());
  const d = dict(lang);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === "up") {
        const { error: err } = await authClient.signUp.email({
          email,
          password,
          name: name || email.split("@")[0] || "Traveler",
        });
        if (err) throw new Error(err.message);
      } else {
        const { error: err } = await authClient.signIn.email({ email, password });
        if (err) throw new Error(err.message);
      }
      navigate({ to: "/" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="relative grid min-h-dvh place-items-center overflow-hidden px-5 py-10">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute top-[-20%] left-[-10%] size-[28rem] rounded-full bg-accent/20 blur-3xl" />
        <div className="absolute right-[-20%] bottom-[-10%] size-[24rem] rounded-full bg-star/10 blur-3xl" />
      </div>
      <section className="glass-strong relative w-full max-w-md rounded-[var(--radius-2xl)] p-6 sm:p-8">
        <div className="mb-6 flex flex-col items-center gap-3 text-center">
          <VeltoMark className="size-14" />
          <h1 className="font-display text-3xl font-semibold tracking-[-0.05em]">{d.app}</h1>
          <p className="text-sm text-muted">{d.tagline}</p>
        </div>

        {authEnabled ? (
          <div className="flex flex-col gap-3">
            {GROK_PROVIDERS.map((p) => (
              <button
                key={p.providerId}
                type="button"
                onClick={() => signIn(p.providerId, { callbackURL: "/" })}
                className="glass-btn h-12 rounded-[var(--radius-md)] font-medium"
              >
                {p.label === "Google" ? d.continueGoogle : d.continueX}
              </button>
            ))}
            <div className="flex items-center gap-3 py-1 text-xs tracking-wide text-subtle uppercase">
              <span className="h-px flex-1 bg-border" />
              {d.or}
              <span className="h-px flex-1 bg-border" />
            </div>
            <div className="mb-1 grid grid-cols-2 gap-1 rounded-[var(--radius-md)] bg-fg/5 p-1">
              <button
                type="button"
                className={`h-9 rounded-[10px] text-sm font-medium ${mode === "in" ? "accent-btn" : ""}`}
                onClick={() => setMode("in")}
              >
                {d.signIn}
              </button>
              <button
                type="button"
                className={`h-9 rounded-[10px] text-sm font-medium ${mode === "up" ? "accent-btn" : ""}`}
                onClick={() => setMode("up")}
              >
                {d.createAccount}
              </button>
            </div>
            <form className="flex flex-col gap-2" onSubmit={submit}>
              {mode === "up" && (
                <input
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={d.firstName}
                  className="h-12 rounded-[var(--radius-md)] border border-border bg-fg/5 px-4 text-fg outline-none placeholder:text-subtle"
                />
              )}
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={d.email}
                className="h-12 rounded-[var(--radius-md)] border border-border bg-fg/5 px-4 text-fg outline-none placeholder:text-subtle"
              />
              <input
                required
                type="password"
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={d.password}
                className="h-12 rounded-[var(--radius-md)] border border-border bg-fg/5 px-4 text-fg outline-none placeholder:text-subtle"
              />
              {error && <p className="text-sm text-danger">{error}</p>}
              <button type="submit" disabled={busy} className="accent-btn mt-1 h-12 rounded-[var(--radius-md)] font-semibold">
                {busy ? "…" : mode === "up" ? d.createAccount : d.signIn}
              </button>
            </form>
          </div>
        ) : (
          <p className="text-center text-sm text-muted">Sign-in is disabled.</p>
        )}
      </section>
    </main>
  );
}
