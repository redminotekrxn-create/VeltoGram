#!/usr/bin/env bash
set -euo pipefail
ROOT=/workspace/artifacts/apk
BT=/tmp/android-sdk/bt/android-14
JAR=/tmp/android-sdk/plat/android-34/android.jar
OUT=/workspace/public/downloads
WORKDIR=/tmp/vg-apk-build
rm -rf "$WORKDIR"
mkdir -p "$WORKDIR" "$OUT" "$ROOT/res/mipmap-hdpi" "$ROOT/res/mipmap-mdpi" "$ROOT/res/mipmap-xhdpi"

python3 - <<'PY'
import struct, zlib, math, pathlib

def png(w, h, pixel):
    def chunk(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw.extend(pixel(x, y, w, h))
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(bytes(raw), 9)) + chunk(b'IEND', b'')

def pixel(x, y, w, h):
    cx, cy = w/2, h/2
    dx, dy = x - cx, y - cy
    r = math.hypot(dx, dy) / (w * 0.42)
    bg = (7, 8, 12)
    if r > 1:
        return bg
    # ring
    ring = abs(math.hypot(dx, dy) - w*0.40) < w*0.03
    # V
    t = (y - h*0.22) / (h*0.62)
    left = w*0.30 + t * (w*0.20)
    right = w*0.70 - t * (w*0.20)
    on_v = abs(x-left) < w*0.045 or abs(x-right) < w*0.045
    on_v = on_v and 0 <= t <= 1
    spark = math.hypot(x - w*0.78, y - h*0.28) < w*0.045
    if spark:
        return (232, 195, 106)
    if ring or on_v:
        return (45, 212, 191)
    return (18, 24, 32)

for size, name in [(48, 'mdpi'), (72, 'hdpi'), (96, 'xhdpi')]:
    p = pathlib.Path(f'/workspace/artifacts/apk/res/mipmap-{name}/ic_launcher.png')
    p.write_bytes(png(size, size, pixel))
print('icons ok')
PY

cd "$WORKDIR"
"$BT/aapt2" compile --dir "$ROOT/res" -o compiled.zip
mkdir -p gen classes
"$BT/aapt2" link \
  -o packed.apk \
  -I "$JAR" \
  --manifest "$ROOT/AndroidManifest.xml" \
  --java gen \
  --auto-add-overlay \
  -A "$ROOT/assets" \
  compiled.zip

find gen -name 'R.java'
javac --release 11 -cp "$JAR" -d classes \
  $(find "$ROOT/src" -name '*.java') \
  $(find gen -name '*.java')

"$BT/d8" --lib "$JAR" --min-api 24 --output . $(find classes -name '*.class')

python3 - <<'PY'
import zipfile
src = "/tmp/vg-apk-build/packed.apk"
dst = "/tmp/vg-apk-build/with-dex.apk"
with zipfile.ZipFile(src, "r") as zin, zipfile.ZipFile(dst, "w") as zout:
    for item in zin.infolist():
        zout.writestr(item, zin.read(item.filename))
    zout.write("/tmp/vg-apk-build/classes.dex", "classes.dex")
print("dex added")
PY

"$BT/zipalign" -f 4 with-dex.apk aligned.apk

if [ ! -f /workspace/artifacts/apk/keystore.jks ]; then
  keytool -genkey -v -keystore /workspace/artifacts/apk/keystore.jks -storepass veltogram \
    -keypass veltogram -alias velto -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=VeltoGram, OU=Velto, O=VeltoGram, L=Almaty, ST=Almaty, C=KZ"
fi

"$BT/apksigner" sign --ks /workspace/artifacts/apk/keystore.jks --ks-pass pass:veltogram \
  --key-pass pass:veltogram --out "$OUT/veltogram.apk" aligned.apk
"$BT/apksigner" verify "$OUT/veltogram.apk"
ls -lh "$OUT/veltogram.apk"
cp "$OUT/veltogram.apk" /workspace/artifacts/apk/veltogram.apk
