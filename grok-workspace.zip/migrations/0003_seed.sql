-- Catalog + official VeltoGram presence (no human accounts)

insert into profiles (user_id, username, first_name, last_name, bio, is_bot, is_verified, is_premium, avatar_frame, profile_color, profile_bg)
values
  ('sys-velto', 'veltogram', 'VeltoGram', '', 'Official VeltoGram guide. Tips, safety, and product news.', true, true, true, 'orbit', '#2DD4BF', 'aurora'),
  ('sys-owner-bot', 'ownerbot', 'Owner', 'Bot', 'Restricted system bot. Commands execute only for OWNER_ID.', true, true, true, 'crown', '#E8C36A', 'ink')
on conflict (user_id) do nothing;

insert into stars_wallets (user_id, balance) values
  ('sys-velto', 0),
  ('sys-owner-bot', 0)
on conflict (user_id) do nothing;

insert into chats (id, type, title, username, description, owner_id, is_public, invite_code, settings)
values
  ('chat-velto-news', 'channel', 'Velto News', 'veltonews', 'Official product channel. Features, economy, and seasonal drops.', 'sys-velto', true, 'velto-news', '{"comments":true}'),
  ('chat-velto-lounge', 'group', 'Velto Lounge', 'veltolounge', 'Public living room for the VeltoGram community.', 'sys-velto', true, 'velto-lounge', '{"reactions":true}')
on conflict (id) do nothing;

insert into chat_members (chat_id, user_id, role)
values
  ('chat-velto-news', 'sys-velto', 'owner'),
  ('chat-velto-lounge', 'sys-velto', 'owner')
on conflict do nothing;

insert into messages (id, chat_id, sender_id, type, body, status)
values
  ('msg-news-1', 'chat-velto-news', 'sys-velto', 'text', 'VeltoGram is live. Fast messaging, Stories, Stars, gifts, and NFT collectibles — one identity.', 'read'),
  ('msg-news-2', 'chat-velto-news', 'sys-velto', 'text', 'Velto Stars power gifts, Premium, and collectibles. Every transfer has a unique id and cannot be replayed.', 'read'),
  ('msg-news-3', 'chat-velto-news', 'sys-velto', 'text', 'Liquid Glass UI, AMOLED mode, and fifteen languages ship in this build. Customize your profile from the Profile tab.', 'read'),
  ('msg-lounge-1', 'chat-velto-lounge', 'sys-velto', 'text', 'Welcome to Velto Lounge. Say hello, share a gift, or drop a Story.', 'read')
on conflict (id) do nothing;

insert into gifts (id, name, description, image_key, cost, rarity, convertible_to_nft, premium_only)
values
  ('gift-spark', 'Spark', 'A small pulse of light. Everyday thanks.', 'spark', 15, 'common', false, false),
  ('gift-orb', 'Glass Orb', 'A captured highlight from the Velto sky.', 'orb', 40, 'common', false, false),
  ('gift-comet', 'Comet', 'A fast streak for people who reply instantly.', 'comet', 90, 'rare', false, false),
  ('gift-lynx', 'Lynx Mask', 'Quiet, sharp, nocturnal.', 'lynx', 140, 'rare', true, false),
  ('gift-aurora', 'Aurora Ribbon', 'Northern light folded into silk.', 'aurora', 220, 'epic', true, false),
  ('gift-cube', 'Prism Cube', 'Six faces of slow color.', 'cube', 260, 'epic', true, false),
  ('gift-phoenix', 'Phoenix Pin', 'Rebirth mark. Burns twice.', 'phoenix', 480, 'legendary', true, false),
  ('gift-crown', 'Ion Crown', 'Reserved for moments that matter.', 'crown', 720, 'legendary', true, true),
  ('gift-origin', 'Origin Shard', 'First-light fragment. Almost none exist.', 'origin', 1200, 'mythic', true, true),
  ('gift-eclipse', 'Eclipse Halo', 'A dark ring around a living star.', 'eclipse', 1600, 'mythic', true, true)
on conflict (id) do nothing;

insert into nft_collections (id, name, description, cover_key, limited)
values
  ('col-orbit', 'Orbit Protocol', 'Founding collection of VeltoGram. Geometric relics from the first network pulse.', 'orbit', true),
  ('col-glass', 'Liquid Glass', 'Sculptures of light trapped in frost.', 'glass', false),
  ('col-myth', 'Night Myths', 'Rare figures from the Velto sky catalog.', 'myth', true)
on conflict (id) do nothing;

insert into nfts (id, collection_id, name, description, image_key, rarity, traits, price)
values
  ('VG-NFT-0001', 'col-orbit', 'Pulse V', 'The first V-mark ever minted inside VeltoGram.', 'pulse-v', 'legendary', '{"gen":1,"ring":"ion"}', 900),
  ('VG-NFT-0002', 'col-orbit', 'Relay Node', 'A still from the original routing mesh.', 'relay', 'epic', '{"gen":1,"mesh":"alpha"}', 420),
  ('VG-NFT-0003', 'col-orbit', 'Signal Seed', 'Tiny origin spark used in network tests.', 'seed', 'rare', '{"gen":1}', 180),
  ('VG-NFT-0004', 'col-glass', 'Frost Lens', 'A lens that only focuses on kind messages.', 'lens', 'rare', '{"finish":"frost"}', 210),
  ('VG-NFT-0005', 'col-glass', 'Tide Panel', 'A sheet of moving glass.', 'tide', 'epic', '{"finish":"tide"}', 390),
  ('VG-NFT-0006', 'col-glass', 'Mirror Vein', 'Reflects the viewer''s accent color.', 'vein', 'legendary', '{"finish":"mirror"}', 850),
  ('VG-NFT-0007', 'col-myth', 'Night Lynx', 'Guardian of silent chats.', 'nlynx', 'epic', '{"myth":"lynx"}', 500),
  ('VG-NFT-0008', 'col-myth', 'Solar Moth', 'Drawn to Premium light.', 'moth', 'mythic', '{"myth":"moth"}', 1400)
on conflict (id) do nothing;

insert into sticker_packs (id, name, premium)
values
  ('pack-orbit', 'Orbit Faces', false),
  ('pack-glass', 'Glass Moods', false),
  ('pack-premium', 'Ion Line', true)
on conflict (id) do nothing;

insert into stickers (id, pack_id, emoji, image_key)
values
  ('st-o1', 'pack-orbit', 'hello', 'face-hello'),
  ('st-o2', 'pack-orbit', 'ok', 'face-ok'),
  ('st-o3', 'pack-orbit', 'love', 'face-love'),
  ('st-o4', 'pack-orbit', 'wow', 'face-wow'),
  ('st-o5', 'pack-orbit', 'sad', 'face-sad'),
  ('st-g1', 'pack-glass', 'cool', 'glass-cool'),
  ('st-g2', 'pack-glass', 'fire', 'glass-fire'),
  ('st-g3', 'pack-glass', 'night', 'glass-night'),
  ('st-p1', 'pack-premium', 'ion', 'ion-mark'),
  ('st-p2', 'pack-premium', 'crown', 'ion-crown')
on conflict (id) do nothing;
