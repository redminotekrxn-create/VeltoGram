-- VeltoGram core schema

create table if not exists app_settings (
  key text primary key,
  value text not null
);

create table if not exists profiles (
  user_id text primary key,
  username text unique not null,
  first_name text not null default '',
  last_name text not null default '',
  phone text,
  bio text not null default '',
  avatar_url text,
  avatar_frame text not null default 'none',
  profile_color text not null default '#2DD4BF',
  profile_bg text not null default 'aurora',
  name_style text not null default 'default',
  emoji_status text,
  status_text text,
  is_bot boolean not null default false,
  is_verified boolean not null default false,
  is_premium boolean not null default false,
  premium_until timestamptz,
  is_owner boolean not null default false,
  account_level int not null default 1,
  xp int not null default 0,
  last_seen timestamptz not null default now(),
  language text not null default 'en',
  theme text not null default 'dark',
  accent text not null default 'teal',
  privacy jsonb not null default '{"lastSeen":"everyone","calls":"everyone","stories":"everyone","gifts":"everyone"}',
  notification_settings jsonb not null default '{"messages":true,"mentions":true,"reactions":true,"gifts":true,"stars":true,"stories":true,"channels":true,"calls":true}',
  pin_hash text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists blocks (
  user_id text not null,
  blocked_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, blocked_id)
);

create table if not exists contacts (
  user_id text not null,
  contact_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, contact_id)
);

create table if not exists chats (
  id text primary key,
  type text not null,
  title text,
  username text unique,
  description text,
  avatar_url text,
  owner_id text,
  is_public boolean not null default true,
  invite_code text unique,
  settings jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create table if not exists chat_members (
  chat_id text not null,
  user_id text not null,
  role text not null default 'member',
  muted boolean not null default false,
  pinned boolean not null default false,
  unread_count int not null default 0,
  last_read_at timestamptz,
  notifications text not null default 'all',
  joined_at timestamptz not null default now(),
  primary key (chat_id, user_id)
);

create table if not exists messages (
  id text primary key,
  chat_id text not null,
  sender_id text not null,
  type text not null default 'text',
  body text,
  media_url text,
  media_meta jsonb,
  reply_to_id text,
  forwarded_from text,
  is_edited boolean not null default false,
  is_pinned boolean not null default false,
  is_spoiler boolean not null default false,
  scheduled_at timestamptz,
  expires_at timestamptz,
  views int not null default 0,
  status text not null default 'sent',
  created_at timestamptz not null default now(),
  edited_at timestamptz
);

create index if not exists messages_chat_created_idx on messages (chat_id, created_at desc);
create index if not exists chat_members_user_idx on chat_members (user_id);

create table if not exists message_reactions (
  message_id text not null,
  user_id text not null,
  emoji text not null,
  created_at timestamptz not null default now(),
  primary key (message_id, user_id)
);

create table if not exists typing (
  chat_id text not null,
  user_id text not null,
  updated_at timestamptz not null default now(),
  primary key (chat_id, user_id)
);

create table if not exists drafts (
  user_id text not null,
  chat_id text not null,
  body text not null default '',
  updated_at timestamptz not null default now(),
  primary key (user_id, chat_id)
);

create table if not exists stories (
  id text primary key,
  user_id text not null,
  type text not null,
  media_url text,
  body text,
  music text,
  privacy text not null default 'all',
  allow_replies boolean not null default true,
  allow_reactions boolean not null default true,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  archived boolean not null default false
);

create table if not exists story_views (
  story_id text not null,
  viewer_id text not null,
  reaction text,
  created_at timestamptz not null default now(),
  primary key (story_id, viewer_id)
);

create table if not exists story_replies (
  id text primary key,
  story_id text not null,
  user_id text not null,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists stars_wallets (
  user_id text primary key,
  balance bigint not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists star_transactions (
  id text primary key,
  from_user text,
  to_user text,
  amount bigint not null,
  kind text not null,
  memo text,
  idempotency_key text unique not null,
  created_at timestamptz not null default now()
);

create table if not exists gifts (
  id text primary key,
  name text not null,
  description text not null,
  image_key text not null,
  cost int not null,
  rarity text not null,
  convertible_to_nft boolean not null default false,
  premium_only boolean not null default false
);

create table if not exists user_gifts (
  id text primary key,
  gift_id text not null,
  owner_id text not null,
  from_id text,
  displayed boolean not null default true,
  converted_nft_id text,
  created_at timestamptz not null default now()
);

create table if not exists nft_collections (
  id text primary key,
  name text not null,
  description text not null,
  cover_key text not null,
  limited boolean not null default false
);

create table if not exists nfts (
  id text primary key,
  collection_id text not null,
  name text not null,
  description text not null,
  image_key text not null,
  rarity text not null,
  traits jsonb not null default '{}',
  price int
);

create table if not exists nft_ownership (
  nft_id text primary key,
  owner_id text not null,
  acquired_at timestamptz not null default now()
);

create table if not exists nft_history (
  id text primary key,
  nft_id text not null,
  from_id text,
  to_id text not null,
  created_at timestamptz not null default now()
);

create table if not exists notifications (
  id text primary key,
  user_id text not null,
  type text not null,
  title text not null,
  body text not null,
  data jsonb,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists notifications_user_idx on notifications (user_id, created_at desc);

create table if not exists owner_actions (
  id text primary key,
  actor_id text not null,
  command text not null,
  payload jsonb,
  created_at timestamptz not null default now()
);

create table if not exists calls (
  id text primary key,
  chat_id text,
  kind text not null,
  initiator_id text not null,
  callee_id text,
  status text not null,
  created_at timestamptz not null default now(),
  ended_at timestamptz
);

create table if not exists sticker_packs (
  id text primary key,
  name text not null,
  premium boolean not null default false
);

create table if not exists stickers (
  id text primary key,
  pack_id text not null,
  emoji text,
  image_key text not null
);

create table if not exists polls (
  id text primary key,
  message_id text not null unique,
  question text not null,
  options jsonb not null,
  quiz boolean not null default false,
  correct_index int,
  created_at timestamptz not null default now()
);

create table if not exists poll_votes (
  poll_id text not null,
  user_id text not null,
  option_index int not null,
  primary key (poll_id, user_id)
);

create table if not exists achievements (
  user_id text not null,
  key text not null,
  unlocked_at timestamptz not null default now(),
  primary key (user_id, key)
);

create table if not exists daily_bonuses (
  user_id text not null,
  day date not null,
  amount int not null,
  primary key (user_id, day)
);

create table if not exists activity_log (
  id text primary key,
  user_id text not null,
  action text not null,
  meta jsonb,
  created_at timestamptz not null default now()
);

create table if not exists user_files (
  id text primary key,
  user_id text not null,
  chat_id text,
  name text not null,
  mime text not null,
  size_bytes int not null,
  data_url text not null,
  created_at timestamptz not null default now()
);

create table if not exists favorite_stickers (
  user_id text not null,
  sticker_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, sticker_id)
);
